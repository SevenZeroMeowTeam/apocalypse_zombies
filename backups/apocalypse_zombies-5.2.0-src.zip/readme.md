# Apocalypse Zombies

Forge 1.20.1 的末日僵尸模组。僵尸按全局等级与尸潮波次逐阶进化；月相改写夜晚的规则；
尸潮分五波压境、由精英领队；四只特殊敌对生物各有一套独立技能与骨骼动画；另配套 GeckoLib 驱动的枪械。

| | |
|---|---|
| **当前版本** | `5.2.0` |
| **Minecraft** | 1.20.1 |
| **Forge** | 47.4.0+（开发机运行实例 47.4.27） |
| **GeckoLib** | 4.8.4 —— **硬依赖**（`mandatory=true`），由玩家自行安装，本模组不捆绑 |
| **JDK** | 17 |
| **许可** | 代码 GPL-3.0-or-later；含 TaCZ 借用内容的开发包另受 CC BY-NC-ND 4.0 约束 |

第三方署名与三条许可约束见 [`NOTICE.md`](NOTICE.md)；建模与贴图标准见 [`美术规范.md`](美术规范.md)。
**开发手册见 [`docs/wiki/`](docs/wiki/README.md)**（环境、代码地图、建模流程、工具脚本手册、出货与 CI）。

---

## 构建

```bash
./gradlew build                                  # 开发包（含借用的音效与转录动画）
./gradlew clean build cleanJar borrowedPack      # 三件产物一起出
```

产物都落在 `build/libs/`：

| 产物 | 含 TaCZ 借用内容 | 用途 |
|---|---|---|
| `apocalypse_zombies-<ver>.jar` | **有** | 开发 / 自用。**不得商用、不得公开分发** |
| `apocalypse_zombies-<ver>-clean.jar` | 无 | 分发用。动画为完全原创的手工版 |
| `apocalypse_zombies-borrowed-assets.zip` | 有 | 本地资源包，装进 `resourcepacks/` 把借来的音效与动画覆盖回去 |

### 部署到本地实例

```bash
cp build/libs/apocalypse_zombies-<ver>.jar \
   "F:/.minecraft/versions/1.20.1-Forge_47.4.26/mods/"
```

**Forge 没有热重载**：换包必须等客户端**完全退出**再重开才生效。游戏运行中替换 `mods/` 里的 jar，
进程持有的仍是旧包。出货一律走 `tools/_deploy_<ver>.py`（自升版号 → 构建 → mods.toml / 资产三向对账
→ 探锁部署 → 其余模组 md5 逐个断「原样在位」）。

> 换版本号后**必须删掉 mods 目录里的旧 jar**，同名模组存在两份会让游戏启动即崩。
> 备份一律改成非 `.jar` 后缀（如 `.jar.old.bak`），Forge 只扫 `.jar`，留着旧版本号的文件不会被加载。

> 若构建**卡在配置阶段**——日志停在 `The daemon has started executing the build.` 之后不再增长、
> `build/` 几分钟内没有新文件——那是 ForgeGradle 在插件 apply 阶段做联网探测时被 socket 阻塞，
> `--offline` / `--no-daemon` 都管不到它（它们只作用于 Gradle 自己的依赖解析层）。
> 用一个必定被拒的代理让该探测立刻失败即可（本机实测：挂 10 分钟零进展 → **25 秒 BUILD SUCCESSFUL**）：
>
> ```bash
> JAVA_TOOL_OPTIONS="-Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=1 -Dhttp.proxyHost=127.0.0.1 -Dhttp.proxyPort=1" \
>   ./gradlew build --offline --console=plain
> ```
>
> `JAVA_TOOL_OPTIONS` 会被所有 JVM（含 forked daemon）继承；命令行 `-Dorg.gradle.jvmargs="..."` 无效。

---

## 功能

### 僵尸进化（6 阶）

`COMMON` → `REINFORCED` → `ELITE` → `MUTANT` → `TYRANT` → `WARLORD`

- 阶数落在实体 NBT 的 `az_evolution_tier` 上，随世界存续，不因区块卸载丢失。
- 生成不是无条件拉满：波次给「保底阶」（`min(MAX_TIER, waveIndex - 1)`），全局等级给「天花板」
  （`min(MAX_TIER, globalLevel + 1)`），实际取值在两者之间随机 —— 所以早波次不会跳出暴君。
- 另有 `evolution.spawn_with_tier_chance` 决定普通刷怪是否直接带阶出现。
- 带阶僵尸头顶显示阶名与颜色（灰 / 黄 / 金 / 红 / 暗红 / 暗紫）；低阶不挂铭牌，
  是否显示由 `EvolutionTier.showsNamePlate()` 决定。
- 蓝月之夜，带阶僵尸死亡会额外掉落铁锭或金锭（阶越高概率越高）。

### 月相事件（7 种）

| 月相 | 视觉 | 玩法效果 |
|---|---|---|
| `none` | 原版 | — |
| `blood_moon` / `super_blood_moon` | 红月，超级月面更大 | **锁床**：整夜无法入睡（`lunar_events.blood_moon_blocks_sleep` 可关） |
| `yellow_moon` / `super_yellow_moon` | 黄月 | 作物整夜被强制催熟，超级更快 |
| `blue_moon` / `super_blue_moon` | 蓝月 | 全体玩家获得幸运（普通 I / 超级 II），且带阶僵尸死亡额外掉铁/金锭 |

月相由服务端判定并持久化在世界数据里（`ApocalypseData`），客户端通过 `ClientMoonState` 收到后
负责天空色、雾色与月面渲染（`textures/environment/moon_phases.png`）。

### 尸潮（5 波）

四波随机化尸潮依次压境，波次进度与剩余数量显示在 boss bar 上。波次越高，僵尸的起步阶越高。

### 特殊敌对生物（4 种）

**1.1.0 新增。** 全部基于原版敌对生物改造，各带一格技能槽；技能是「前摇 → 命中 → 收招」三段，
命中时刻由 `EliteAbility` 的 `(duration, impactTick)` 定义：

| 实体 ID | 原型 | 技能 | 时长 / 命中 tick | 行为 |
|---|---|---|---|---|
| `screamer_zombie` | 僵尸 | `SCREAM` 尖啸 | 46 / 22 | 给周围尸群挂移动速度 II + 力量 I，并召唤援军 |
| `crusher_zombie` | 僵尸 | `SLAM` 下砸 | 32 / 18 | 范围内造成伤害 + 击退，并挂 60 tick 缓慢 |
| `corroder_zombie` | 僵尸 | `SPIT` 吐酸 | 28 / 15 | 后仰蓄酸 0.75 秒，命中瞬间射出 `acid_projectile` |
| `marksman_skeleton` | 骷髅 | `SNIPE` 蓄力狙击 | 42 / 34 | 蓄力后射出暴击箭 |

- **动画是 Java 侧程序化骨骼动画**，不是 GeckoLib 关键帧文件：`ElitePose` 提供
  `hold` / `strike` / `pulse` 三个姿态量，子类模型实现 `applyCastPose`，再由 `CastPoseBlender`
  插值 —— 所以收招会平滑融回原版姿态，不会硬切。
- 姿态状态走 `SynchedEntityData`（`DATA_ABILITY` / `DATA_ABILITY_TICK`）由服务端同步，
  客户端模型在 `setupAnim` 里读取。
- 四只都有刷怪蛋，创造模式可直接取用测试。

**生成与控制**（1.1.0 接入）：

- 自然生成走**自定义 biome modifier**（`apocalypse_zombies:elite_spawns`），作用于
  `#minecraft:is_overworld`，权重**实时读配置**（默认 3；对照原版四类僵尸各 100，约每 170 只出一只精英）。
- 配套 `SpawnPlacements` 登记 —— 两者缺一不可，只加 biome modifier 会被刷怪器静默跳过。
- **蘑菇岛被显式排除**：`#minecraft:is_overworld` 这个标签包含 `minecraft:mushroom_fields`，
  而它是原版唯一保证不刷怪的群系（玩家当安全屋），所以在生成判定里补了一道否决。
- 精英也随尸潮登场：默认第 3 波起、每两波 +1、封顶 3 只；它们计入 boss bar 总数，也必须清完才算这波结束。

### 美女僵尸 / 士兵僵尸

**1.1.6 起陆续追加**的两只独立精英实体。技能仍是「前摇 → 命中 → 收招」三段，但技能集、骨骼与贴图
各自成篇（面纱 / 长发 / 鬓发 / 拖尾 / 裙摆均为真骨骼）。逐版改动与验收口径见
`art/bride/DELIVERY.md`、`art/bride/PHASE2_DELIVERY.md`、`art/soldier/DELIVERY.md`。

### 生物 AI 增强

开关与数值都在配置的 `[ai]` 段。

- **敌对生物**：共享仇恨（同伴被打会一起上）、包围站位、破门（默认 10%、血月 40%）、更高的跟随范围；
  **1.1.56 起追击速度 ×1.1**（`hostile_speed`，写的是"原版基值 × 倍率"，所以各种怪原本的快慢差别还在）。
- **骷髅**：除原版弓之外会放 **巨箭**（更高伤害、更难躲）。
- **僵尸 / 骷髅 35% 必中**（1.1.56）：攻击前按概率把目标的**受击无敌帧清掉**。
  原版近战几乎不会真的挥空，"打了没伤害"绝大多数是受击冷却造成的 —— 所以必中做成"先清冷却"，
  而不是"无视距离硬打"（后者会让僵尸隔空揍人）。10 tick 节流，且只在贴近时生效。
- **村民**：遇袭会恐慌撤离并**呼叫最近的铁傀儡**；**1.1.56 起 15% 的村民出生时手持铁剑**
  （`villager_arm_chance`），它们不再逃跑，而是迎战。近战走的是本模组自己的
  `VillagerDefendGoal`（1.1.58 修正）—— **不能用原版 `MeleeAttackGoal`**：村民的
  `createAttributes()` 里没有 `ATTACK_DAMAGE`，那个 Goal 一攻击就会抛异常把服务端带崩。
- **铁傀儡**：优先处理威胁村民的怪、跟随范围抬到 48、击退翻倍；**1.1.56 起速度 0.25 → 0.28、
  伤害 15 → 18**。
- **不互相攻击**：本模组阵营的怪之间伤害直接取消（`no_infighting`）；另有 `no_infighting_global`
  可扩到原版怪 —— 默认**关**，因为它会改变原版行为（凋灵、掠夺者与僵尸之间也会安静下来）。

### 武器商（EasyNPC）

本模组自带一份 [Easy NPC](https://www.curseforge.com/minecraft/mc-mods/easy-npc) 的 **NPC 预设**：
`data/easy_npc/api/preset/apocalypse_zombies/weapon_merchant.npc.snbt`。装进游戏后在 EasyNPC 的
预设列表里选**「武器商 Weapon Merchant」**摆下去，**右键就会打开交易界面**。

- 外观是武器匠（大师级），`Invulnerable` + 掉率 0（打不死、不掉落）—— 这两项想改就改。
- **商品与价格在游戏内的 EasyNPC 配置界面里配**（交易数据存在 NPC 实体上，不在预设文件里），
  配好可以存成你自己的预设复用。价格就是交易表右格收什么、收多少。
- **没有弹药物品可卖**：本模组的弹量与弹种都存在物品 NBT 里，靠 `R` 键轮盘切换、不消耗背包。
  要让玩家补给，就卖**装满弹的枪**，或者搭配别的模组（如 TaCZ 的弹匣）。
- 六个可卖物品 ID、字段含义、待实机确认的两点，见 [`docs/EasyNPC-武器商.md`](docs/EasyNPC-武器商.md)。

### 枪械

| 物品 ID | 说明 |
|---|---|
| `awm` | 栓动狙击步枪，.338。**镜片即视场**：抬镜时整枪与双臂不再绘制 |
| `m1_garand` | 半自动步枪，.30-06，8 发漏夹。铁瞄 |
| `mosin_nagant` | 栓动步枪，7.62×54R，固定 5 发盒式弹仓。铁瞄 |
| `uzi` | 冲锋枪，9mm，**全自动**：按住左键连发、松手停火、弹匣打空自动停 |
| `s686` | 金板 S686 上下双管折开式霰弹枪，12 号。**2 发**：每扣一次扳机打 1 发、1 秒一发；潜行扣扳机 = 双管齐射（2 发）。默认装鹿弹（每发 8 颗弹丸），`R` 轮盘可换**独头 / 铝热 / 爆炸** |
| `colt_1878` | 柯尔特 1878 **教练枪**：**并排**双管折开式霰弹枪，12 号，全长 0.93 格（940 mm、管 508 mm / 20 英寸 —— 真枪是教练枪构型，extractor 抽壳不是 ejector 抛壳）。机构与 S686 同族，但两段换弹刻意更慢（3.0 s / 3.6 s），铁瞄 |
| `win94` | 温彻斯特 M1894 **杠杆步枪**（狙击型，1 英寸长筒镜），.45-70，**管状弹仓 5 发**。杠杆循环退壳上膛；换弹不是换弹匣，而是**机匣右侧装填门逐发压进去**：战术换弹补 3 发（2.2 s），空仓补满 5 发后还要再扳一次杠杆上膛（4.4 s） |
| `crossbow` | 十字弩，现代复合结构；右键 = 透明十字瞄准镜 |

- **八把枪打完自动换弹**：弹匣打空立刻换；空匣状态下扣扳机也触发。
- **铁瞄还是镜，由枪自己回答**：`hasScopeOverlay()` / `hidesModelWhileAimed()` 走 `GunItem` 的实现，
  不写死在渲染层 —— 铁瞄枪（M1 / 莫辛 / Uzi / S686 / 柯尔特 1878）照门就是瞄准点，枪必须留在画面里。
- **跑步持枪姿态**（1.1.40）：跑动时枪从瞄准线上下到身侧，八把枪共用一套姿态，见更新日志。
- 持枪时**左键开火**（Uzi 按住连发）、**右键抬镜**、`R` 换弹（1.1.52 起改为**按住弹轮盘、松开装填**，
  见下）、**`Shift + R` 单发补弹（M1 加兰德）**（可在控制里改键，分类「Apocalypse Zombies」）。
- **子弹与方块**（1.1.90）：穿树叶（`bullets.pass_leaves`）、打碎玻璃（`bullets.break_glass`）——
  碎完默认停在玻璃上，`bullets.pass_glass` 可改成碎完继续飞。树叶与玻璃按原版标签 / 声音类型认，
  不写死方块 id（模组树叶、模组玻璃同样认）。
- **服务端权威**：客户端只发请求（`FirePacket` / `ReloadPacket`），「有没有子弹、动作是否占用、
  子弹打中了什么」全部由服务端裁决。
- 弹量存在物品 NBT 的 `Ammo` 里；换弹分两路 —— 满弹匣走战术换弹（保留膛内那发），
  空仓走完整上膛流程，动画与音效也不同。**M1 加兰德有四路**（1.1.47 起按真机机构）：
  空仓走 `reload_empty`、半满走 `reload_tactical`（拉到底保持 → 按左侧卡榫销 → 残夹脱出）、
  补弹走 `Shift + R` 的 `single_load`（只加一发，不动漏夹）；**最后一发自成一路**（1.1.48 起）：
  枪机退到底被挂机爪咬住、空漏夹当场「叮」出井口（`shoot_last`），之后自动接上 `reload_empty`
  —— 那一段起手枪机就已经在后退位，只把新夹压下去。
- 姿态走客户端 `GunAimState` + `GunPose`：站立腰射 / 跑步持枪 / 抬镜三态连续混合；`WeaponArms` 按
  玩家皮肤绘制手臂，跟随各枪 `*GeoModel` 给出手部目标。
- **S686 是折开式（break-action）双管，机制与其余枪不同**：没有自动机、没有拉栓循环、没有弹匣 ——
  枪管组绕铰链折下 38° 露出上下两个弹膛，所以 `bolt` 这条动画在这里的含义是「折开检查再合上」
  （空膛扣扳机跑的就是它，26 ticks），也没有 `shoot_auto` 这样的连发片段。每扣一次扳机打 1 发，
  每发是 **8 颗各自独立命中**的弹丸（每颗按距离分级、都不穿透身体），贴脸 8×4 点、32 格外只剩零头；
  潜行扣扳机则双管齐射（消耗 2 发、16 颗），沿用同一条 `shoot` 动画。换弹按「膛内还有没有弹」分流：
  有弹走 `reload_tactical`（折开、接住那发实弹、补两发、合膛），空枪走 `reload_empty`
  （折开、退壳、上两发、合膛），两条都在片段结束时补满 2 发。
- **柯尔特 1878 教练枪是同一套折开机构的第二种构型**：并排双管（S686 是上下双管）、
  管短一截（0.93 格 vs S686 的 1.22 格）、机匣后上方是**两个外露击锤**，顶上一条顶杆拨片。
  几何与动画是**另一套文件**（`geo/colt_1878.geo.json` / `animations/colt_1878.animation.json`，
  由 `tools/colt_1878_*.js` 程序化生成，见 `art/colt_1878/`），但"怎么开火、怎么换弹、手往哪放"
  这一整套逻辑与枪的型号无关 —— 所以 `Colt1878Item` **继承** `S686Item`，
  只覆盖几项：动作时长（举枪 0.8 s、折开 1.4 s、换弹 3.0 s / 3.6 s，逐条等于本枪动画文件的片段长度）、
  音效时刻表（按本枪胶片的关键帧重排）、伤害类型（`colt_1878_bullet`，死亡信息说的是教练枪）、
  准线（沿用 S686 的量算值，待实测重算）与手感（抬枪 0.13 s、ADS 视场 60°、第一人称缩放 1.32）。
- **弹种与 `R` 键轮盘（1.1.52 起）**：按住 `R` 弹出轮盘、松开装填。选项从正上方顺时针排开，
  光标指哪个高亮哪个；光标移回中心则保持当前高亮 —— 所以「按住 `R` 直接松」装的就是枪上原本那种弹，
  也就是这次改动之前 `R` 的行为。打开任意界面（Esc / 背包）视为**放弃**，不会误装填。轮盘打开时
  释放鼠标（否则光标锁在准星上指不了方向），左键不走火、右键不抬镜。
  弹种记在枪自己的 NBT 里（`Shell`），**不消耗背包物品** —— 与 `Ammo` 的设计一致。

  | 弹种 | 弹丸 | 近 / 中 / 远 | 爆头 | 效果 |
  |---|---|---|---|---|
  | 普通弹 | 8（12 号鹿弹） | 4 / 3 / 2 | ×2 | — |
  | **独头弹** | 1 | **34** / 26 / 18 | **×4** | 散布收到鹿弹的四分之一；**只有霰弹枪有** |
  | 铝热弹 | 按枪 | 不变 | ×2 | 命中敌对生物**点燃 5 秒** |
  | 爆炸弹 | 按枪 | 不变 | ×2 | 命中处炸开：半径 **2.5 格**、中心 **14** 点、向外线性衰减 |

  **铝热弹与爆炸弹是通用弹种**，七把枪都能装，`S686Item` 之外一行都不用改 —— 弹种读写走
  `GunItem` 的三个 default 方法（七把枪共用同一个 NBT 键），而命中效果落在**一处**
  `LivingHurtEvent`（`event/AmmoEffects`）。爆炸与点燃**都只作用于敌对生物**，玩家自己、
  宠物、村民、队友都不在范围内；爆炸不破坏方块。S686 的爆炸弹直接命中只有 6 点（引信），
  换来的是那 2.5 格里的一圈伤害。

- 副手 / 背包 / 开镜状态都有对应封包处理。

### 指令

```
/apocalypse status                     # 当前月相、全局等级、尸潮状态
/apocalypse moon <id>                  # 切换月相（none / blood_moon / super_blood_moon /
                                       #   yellow_moon / super_yellow_moon / blue_moon / super_blue_moon）
/apocalypse moon clear|reset           # 清除月相事件
/apocalypse horde start|stop           # 手动起 / 停尸潮
/apocalypse evolution get|set|upgrade  # 查看 / 设置 / 提升进化等级
/apocalypse tiers                      # 列出全部阶位
```

猫耳娘（找 16 格内属于你的那一只）：

```
/apocalypse catgirl auto               # 开关她的自主模式
/apocalypse catgirl chest [clear]      # 绑定 / 解绑储物点
/apocalypse catgirl craft <物品id> [数量]   # 订做：她掏自己的料做，手续费从你的爱心币扣
/apocalypse catgirl mine <方块id> [数量]    # 一键挖掘订单：她自己走过去就近砸，产物进她库存
                                          # 方块id 两种写法都行：minecraft:diamond_ore 或 diamond_ore
/apocalypse catgirl mine stop              # 中止挖掘订单
/apocalypse catgirl ai <一句话>             # 本机模型听懂人话（/apocalypse catgirl ai status 自检）
/apocalypse catgirl recipes [命名空间]      # 她会做的配方（调试用）
```

挖掘订单的数量上限走配置 `cat_girl.mine_max_blocks`（**默认 64，范围 1~64**，这也是「一键挖掘对应物品」的硬上限 ——
命令里写多大都会被夹住）；搜索范围走 `cat_girl.mine_radius`（默认 24 格，4~64）。**这两项都能在
「模组列表 → 选中 Apocalypse Zombies → 配置」的图形界面里直接改**（1.1.79 起，见下），也能手改 TOML。
不走 `mine_protected` 名单的方块（基岩那一类）会被直接拒单。详见「更新日志 1.1.78 / 1.1.79」。

### 配置

`config/apocalypse_zombies-common.toml`，按段组织，每项都带注释：

| 段 | 管什么 |
|---|---|
| `lunar_events` | 各月相开关与效果强度（如血月是否锁床） |
| `evolution` | 进化速度、生成带阶概率、各阶数值 |
| `hordes` | 尸潮波次规模、触发条件 |
| `specials` | 特殊敌对生物：`elite_natural_spawn` / `elite_spawn_weight` / `elite_horde_from_wave` / `elite_horde_max_per_wave` |
| `cat_girl` | 猫耳娘：`auto`（自主模式）、`mine_radius` / `mine_max_blocks`（一键挖掘的范围 / 上限）、`universal_tool`（全功能工具）、`mine_all` / `mine_protected`（挖什么 / 绝不挖什么）、`station_use` / `station_radius` / `station_self_craft`（工作方块） |
| `ai` | 本机 **LM Studio** 助理（1.1.84 起）：`enabled` / `model` / `endpoint`（默认 `http://127.0.0.1:1234/v1`）/ `timeout_ms` / `num_ctx` / `json_schema` |
| `player_mine` | **玩家一键挖掘**（1.1.81 起）：`enabled`（默认开）、`targets`（连带哪些方块：0 只矿石 / 1 矿石+自然方块 / 2 任何可挖方块）、`radius` / `max_blocks`（范围 / 上限 64）、`vein_only`（只连带连通矿脉）、`require_correct_tool`（工具不对口不连带）、`consume_durability`（扣耐久）、`sneak_disables`（潜行只挖一格）、`to_inventory`（产物进背包 —— 连带砸下来的那几格**和你亲手砸的那一格**都算，1.2.4 起）、`protected`（追加保护名单）、`highlight`（瞄准时把会连带的方块描边画出来，默认开）、`count`（瞄准时在准星下方显示「会连挖几格」，默认开） |
| `orbital_strike` | **轨道打击遥控器**（1.2.5 起；2.0.0 起四种弹种）：`enabled`（总开关）、`radius`（基础选区半边长 1~96，各模式再乘倍率）、`damage`（中心伤害，半心单位）、`kill_chance`（每次命中秒杀几率 %）、`damage_mobs`、`destroy_blocks`、`destroy_mode`（`cube` / `column`）、`fall_ticks`、`cooldown`（冷却秒，按模式缩放）、`lock_ticks`（**前摇 tick，默认 140 = 7 s**）、`max_hardness`、`protected`、`cinematic_camera`、`break_bedrock`（**能否挖穿基岩，默认开**）、`default_mode`（`cannon` / `lance` / `gravity` / `storm` / `laser`）、`allow_mode_switch` |

> **图形界面**：`模组列表 → 选中 Apocalypse Zombies → 配置`（1.1.79 起真能用了）——
> 列出**全部 202 项配置**，布尔点开/关、数字直接填、列表用逗号分隔，点「完成」立刻写回上面那个 TOML 文件。
> 也就是说：界面和手改是**同一份配置**，不存在两套。

> `specials.elite_spawn_weight` 改完要**重进世界**才生效 —— biome modifier 在加载时烘焙。

---

## 更新日志

### 5.2.0 — 2026-10-20

**修掉三个「从来就没在玩家机器上编译成功过」的着色器，并给以后加一道真编译的关卡。**

这一版的重点不是加新特效，而是先弄清楚一件事：**v5.0.0 的太空天幕、v5.1.0 的实体光柱，
从出货到今天，一次都没有在玩家的显卡上编译成功过。** 游戏日志里那 19 行
`could not find uniform named ...` 就是证据 —— 链接失败时所有 uniform 都查不到，
MC 对 core shader 编译失败的处理是**静默不画**，所以玩家只看到「特效没出现」，
日志里也只有一行不起眼的警告。

三个根因：

| 文件 | 症状 | 根因 |
|---|---|---|
| `core/orbit_sky.fsh` | `'mix' : no matching overloaded function` | 三目写成了 `a ? b : c ? d : e ? f`（3 个 `?` 只配 2 个 `:`）。GLSL 的三目是**右结合**的，这个写法少一个 `:`，编译器报「expecting COMMA or COLON」 |
| `core/orbit_beam.fsh` | `'noise2' : overloaded functions must have the same return type` | 函数名 `noise2` 撞上 ARB_gpu_shader5 的内建 `noise2`（返回 vec2），和我们的 `float noise2(vec2)` 冲突。改名 `bnoise2` |
| `program/orbital.fsh` | `#include` 无法解析 | Minecraft 的 **program 着色器根本不支持 import**（`EffectProgram` 的预处理器对任何 import 直接返回 `#error Import statement not supported`）。共享代码必须内联 |

另外两处「一直在但从没人用」的死代码：

- `OutSize` / `InSize` / `Time` 三个 uniform **从来没被 Java 赋值过**，一直是 json 里的默认 `(1,1)`。
  也就是说合成器的宽高比一直是 1:1 —— 非方屏上色差、暗角、冲击帧的取样步长全是歪的。
  现在每帧喂真实分辨率。
- `Radial`（径向速度模糊）Java 一直在设值，着色器里却没用它 —— 那个效果其实一直没生效。
  现在补上实现（参考包 composite.fsh 的 RadialBlur）。

**新增的关卡：出货前必须真编译一遍 GLSL。**

- 新增 [tools/glsl_check.py](tools/glsl_check.py)：用本机 OpenGL 3.3 上下文
  **真编译**模组里的每个着色器，并在**链接后的 program** 上查每个 uniform 的位置
  （和 Minecraft 查法一致 —— 查链接后的 program 才算数）。
- 新增 [tools/shader_preview.py](tools/shader_preview.py)：把着色器**真的渲染成 PNG**。
  以前本机开不了图形客户端，shader 写完只能打包给玩家看效果；现在能先自己看。
- 两者都接进了 [tools/check_skyfall.py](tools/check_skyfall.py) 的门禁：
  GLSL 编译不过 = 出货门禁不过。

**新特效（移植参考包 the-shooting-star）：**

- **轨道炮「弧光长矛」特写** —— `shaders/core/orbit_gun.{json,vsh,fsh}` +
  [OrbitalGunStage.java](src/main/java/com/apocalypse/zombies/client/renderer/OrbitalGunStage.java)。
  移植参考包 `star_gun.fsh` 的做法（解析 SDF + 光线步进），但**造型与配色是我们自己的**：
  方形加速线圈 × 8、三根 120° 聚焦爪、尾部反应堆与笼架、散热鳍、推进喷口；
  能量色是弧光青而不是参考包的红。
  充能时一道光波从炮闩推向炮口，开火瞬间炮口爆闪 + 整炮后坐 + 电弧倒跑回炮闩。
  相机完全在 shader 空间（和参考包一样，Java 只给一组四元组）。
- **光轴**（`star_rays.fsh` 的 `shafts()`）—— 40 步、抖动起点、权重逐���衰减的
  屏幕空间光束采集，移植进合成器。落点即光源，光束取协议色。
- **HUD 图形层**（`white_space` 的形状光栅器）—— `shaders/core/orbit_hud.{json,vsh,fsh}` +
  [OrbitHudShapes.java](src/main/java/com/apocalypse/zombies/client/gui/OrbitHudShapes.java)。
  一个形状 = 一个四边形，形状状态藏在顶点色里，AA 用 `fwidth` 在**局部像素空间**算
  （所以形状在任何仿射变换下都保持干净）。实现了面板 / 软投影 / 圆盘（实心·环·辉光·粗环）/
  进度弧 / 准星 / 标尺六种，打击 HUD 现在用真正的进度标尺和落点准星。
  **没有复制参考包的字体和贴图**（那些是第三方资产），文字仍用原版字体。

**服务器端：地形改写改成「工作线程算形 / 服务端线程落块」。**

- 新增 [OrbitalCarveEngine.java](src/main/java/com/apocalypse/zombies/event/OrbitalCarveEngine.java)：
  线程池规模 `clamp(核数-2, 2, 8)`、内存预算 `maxMemory/16`、
  **工作线程绝不碰活的区块**（MC 的区块数据没有并发保护，绕过这条会撕裂区块）。
  参考包 the-shooting-star 也是这么分的。
- 新增弹坑模式 `parallel`（配置项 `orbital_strike.parallel_carve`）：
  服务端线程批量读一层快照 → 工作线程纯算术决定每一格「挖掉 / 换成什么」→
  服务端线程按 tick 预算落地。
- **顺带修了一个真实的观感 bug**：以前挖开沙子，沙子会变成掉落物掉回坑里，
  弹坑转眼被填平（参考包管这叫「塌陷修正」）。现在沙子压成砂岩、砾石换成石头。

**相机：** 参考包用 Mixin 劫持 `Camera.setup` 和 `GameRenderer.getFov`/`renderHand`。
本机拿不到 Mixin 的 gradle 插件（插件门户与各镜像都 404），所以改用 Forge 自带的事件：
`ViewportEvent.ComputeCameraAngles`（位置/朝向）、`ViewportEvent.ComputeFov`（视野）、
`RenderHandEvent`（藏手）。**效果等价，但不用给模组引入 Mixin 依赖** ——
对玩家来说少一个能出问题的环节。

### 5.1.0 — 2026-10-20

**实体光柱：移植参考包 {@code star_beam.fsh} 的四段体积渐变（世界空间圆柱版）。**

- 新增 `shaders/core/orbit_beam.{json,vsh,fsh}` + [OrbitalBeam.java](src/main/java/com/apocalypse/zombies/client/renderer/OrbitalBeam.java)：
  Java 每帧画一根**面向相机的圆柱 quad**（20 段，UV0 = 绕柱角/TAU × 沿柱高度），
  片元着色器据此重建「面向相机程度」，算出移植自参考包的四段体积渐变
  （deep → body → hot → heart）、fbm 绕柱能量条纹、边缘 skin、空气雾、上下端淡出。
- **为什么不用参考包的屏幕空间深度重建**：那需要 `scenePosAt`/`skyAt` 的深度副本与
  `depth_copy` 专 pass，在 Embeddium 下 FBO 黑屏风险高（4.0.3~4.0.6 的教训）；
  圆柱 quad 版只用一个 `ShaderInstance`，不建 FBO、不换帧缓冲。
- 三种协议各有一套柱体性格：
  - **焚城**：锁定末段（最后 25%）出现细瞄准线，命中后 16 tick 全半径主柱 + 强能量条纹；
  - **隔离**：锁定段引力柱随进度增强并在柱内升扫描环，落地后 20 tick 衰减；
  - **黑雨**：只在命中后 14 tick，短而粗的冲击柱（对应「又大又浅的坑」）。
- 柱体颜色取协议色（cinder 橙白 / quarantine 青 / black_rain 绯红），顶点色只做轻染色，
  不压体积渐变。
- 失败自愈：shader 编译失败或 GL 异常时只记一次 warn 并停用该层，退回原有线条/圆环渲染。
- 新增配置 `[orbital_strike] beam_shader`（默认 true）；断层的矛、蜂群的巢荚、
  黎明的光速束保持原有形态（它们本来就不是柱体）。
- 配置总数 222 → 223。

### 5.0.0 — 2026-10-20

**参考 The Shooting Star 重做演出层：程序化天幕升级 + 合成器移植（含 6 种冲击帧）。**

- **天幕 v5**（`shaders/core/orbit_sky`）：移植参考包 `star.glsl` 的三层星场（星等幂分布 +
  各自频率闪烁 + 蓝白到橙金色温）、`blackbody`/`pointGlow` 太阳、深场星系螺旋、银河尘带 fbm；
  新增**月球**（月海/环形山/自发光夜面轮廓）、地球加**海面镜面高光 + 冰盖**。
- **修一个真 bug**：`GameTime` 之前 json 未声明、Java 未 set —— 星空/星云/云其实是**静止的**；
  现在按秒驱动，星星闪烁、云与星云流动。
- **合成器 v5**（`shaders/program/orbital` + 新增共享 `orbit_grade.glsl`）：移植参考包
  `composite.fsh` 的 10 tap 径向变焦模糊、r² 增长色差、soft-screen bloom、自动曝光、
  去饱和/对比分级、胶片颗粒，以及 **6 种冲击帧**（墨线/反相/绯红/墨线+青饰/半调网点/余烬线稿）。
  冲击帧用**局部自适应阈值**（与周围 8 点亮度比较），白闪时形状依然成立；冲击帧中心落在
  屏幕上真实落点，强度/变焦按协议分配。
- 新增 `/orbitpost on|off` 运行时开关：画面异常时不必退出游戏即可切回纯 GUI 近似层。
- 后处理仍默认关闭（`post_shader_experimental=false`，4.0.7 起的黑屏防线），
  `/orbitpost on` 或配置打开即可体验。
- 门禁新增：天幕/合成器 uniform 完整性、include 引用、冲击帧调用检查。
- 设计文档：[`docs/skyfall-v5-reference-port.md`](docs/skyfall-v5-reference-port.md)
  （参考包架构分析、移植清单、跳过项与回滚路径）。

### 4.1.3 — 2026-10-19

**修复暂停菜单「退出游戏」落到「连接已丢失 / 返回到服务器列表」。**

- 根因：自定义暂停界面只调用了 `level.disconnect()` + `halt(false)`，没有走原版的
  `clearLevel` 与标题界面设置；连接关闭后客户端自动进入 `DisconnectedScreen`，
  单人存档也被当成多人服，要求再点一次「返回到服务器列表」。
- 修复：严格照原版 `PauseScreen#onDisconnect`：`level.disconnect()` →
  单人 `clearLevel(保存中)` / 多人 `clearLevel()` → 单人直接回 `TitleScreen`，
  多人回 `JoinMultiplayerScreen`。
- 单人「退出游戏」现在一步回到主菜单，仍会先保存世界。

### 4.1.2 — 2026-10-19

**轨道设施维度改为纯参观区：禁止在维度内发射打击 / 本地预览。**

- 原因：在轨道维度里打任意协议，镜头看到的都是同一片星空 + 同一颗地球 + 平台上的同一台
  卫星实体，六种效果看起来完全一样，容易被误判成“协议没区别”。
- `OrbitalStrikeManager.schedule` 增加维度拦截：在 `apocalypse_zombies:orbit` 内开火会收到
  「轨道设施维度内不能发射打击 —— 这里是参观区」并拒绝。
- `/orbitpreview` 在轨道维度内同样拒绝并提示回主世界预览。
- 进入设施的提示改为「参观区，不能在这里发射打击」。

### 4.1.1 — 2026-10-19

**修复 4.1.0 启动崩溃（卫星模型根骨骼 parent=null）。**

- 症状：标题界面文字全部变「□□□」豆腐块 / FATAL「Rendering overlay」。
- 根因：`tools/facility_model.py` 给根骨骼 `body` 输出了 `"parent": null`，
  Bedrock 格式要求根骨骼**不带 parent 键**；GeckoLib `Bone.deserializer` 读到
  `null` 抛 `Expected parent to be a string, was null`，GeckoLib 启动时预加载
  全部模型 → 异常打断标题渲染。
- 修复：生成器改为「parent 非空才写该键」，重新生成 geo（根骨骼已无 parent 键，
  0 个 null 残留）；`facility_model.py --check` PASS。

### 4.1.0 — 2026-10-19

**轨道设施第一台 GeckoLib 模型：卫星替换方块轮廓。**

- 新增 `tools/facility_model.py`（通道 A 唯一真相源）：生成 `geo/satellite.geo.json`
  （9 骨骼 / 41 方块 / 逐面 UV）+ 512² 图集 `textures/entity/facility/satellite.png`
  （金箔/仪器板/太阳能电池/抛物面/自发光，全部程序化原创）。
- 新增展示实体 `OrbitSatellite`：**不是生物** —— 无 AI、不可推动、不受伤害、
  无物理、速度每 tick 清零并贴回出生点；用一个空控制器保持静态。
- LASER 平台改用实体：`OrbitFacilities.laser()` 只搭基座，中央生成卫星实体
  （附近已有实体则跳过，天然去重）；其余五个平台仍为方块轮廓。
- 门禁 `check_skyfall.py` 新增卫星 geo/贴图/动画 + 512²/骨骼/方块数预算检查。

### 4.0.9 — 2026-10-19

**轨道维度程序化天幕 shader：星空 + 银河 + 星云 + 解析球体地球（大陆/云/夜面灯光/大气）。**

- 新增 core shader `orbit_sky`（`shaders/core/orbit_sky.{json,vsh,fsh}`），在
  `RenderLevelStageEvent.AFTER_SKY` 画全屏四边形，按相机三轴重建视线方向；
  **不建 FBO、不换帧缓冲**，只作用于 `apocalypse_zombies:orbit` 维度。
- 片元着色器实时生成：网格哈希星点、FBM 星云、银河带、远处太阳、程序化地球球体
  （大陆/云层/晨昏线/夜面城市灯光/大气边缘光）。
- 注册失败/资源缺失时静默不画，回退维度原本的末地天空；主世界天空/月亮逻辑不受影响。
- 这是“shader 地球/星云背景”的第一步；GeckoLib 卫星/发射台模型是下一步（P1-b）。

### 4.0.8 — 2026-10-19

**轨道设施改用图片风格的专用方块：装甲板/金箔/仪器板/太阳能电池/抛物面/自发光条。**

- 新增 8 种不可破坏装饰方块（只服务 orbit 维度，无物品形态）：
  `facility_hull / gold / panel / solar / dish / glow_cyan / glow_orange / dark`；
  32×32 程序化原创贴图（`tools/facility_art.py`），带面板缝、铆钉、电池栅线、金箔折痕。
- 六个平台重搭得更接近参考图：
  - 卫星：金箔舱体 + 白色仪器板 + 双层抛物面 + 两侧三片太阳翼 + 天线/推进器；
  - 轨道炮：桁架炮台 + 30 格长炮管 + 每 6 格金环 + 炮口制动环 + 侧面太阳翼；
  - 天基矛：双导轨 + 青色能量线 + 支撑塔 + 金属矛体与尾翼；
  - 引力奇点：三向环 + 金色内环 + 黑球核心 + 青色奇点；
  - 等离子舰：舰体 + 七座发射塔 + 前端发射环；
  - 行星陨落：岩质球体 + 熔岩裂纹 + 双层碎屑环。
- 玩家落点改到平台边缘（z+18），不再站在载体模型里；甲板加引导灯带。

### 4.0.7 — 2026-10-19

**隔离「打击时黑屏」：实验性后处理 shader 默认关闭。**

- 4.0.3~4.0.6 的 FBO 后处理链在部分显卡/Embeddium 组合上会导致打击画面全黑；
  4.0.4 的剔除/帧缓冲修复没有在所有环境生效，线上日志里没有崩溃、只有黑屏，无法继续盲修。
- 配置键改名为 `[orbital_strike] post_shader_experimental`，**默认 false**；旧的
  `post_shader=true` 会被忽略。打开后仍走同一套 GLSL，但多了 GL 错误自检：一旦
  `glGetError` 非 0 就永久关闭并写 warn。
- 默认回退到 4.0.2 的纯 GUI 近似层（速度线/镜头光晕/墨迹冲击帧 + 动态 3D 舞台），
  打击本身、命中白闪、震动、地形结算都不受影响。
- 如果关掉后**仍然黑屏**，那就不是后处理，而是太空舞台/相机；把日志发我，我按下一个方向查。

### 4.0.6 — 2026-10-19

**可传送的「轨道设施」维度：六个平台，每个平台一台对应协议的载体。**

- 新维度 `apocalypse_zombies:orbit`（void 超平坦 + 末地天空 + 无自然生成 + 固定 18000 tick）。
- `/apocalypse orbit <cannon|lance|gravity|storm|laser|planet>` 传送到对应平台；
  `/apocalypse orbit return` 或**右键平台角的磁石**返回进入前的位置。
- 六个平台由 `OrbitFacilities` 用原版方块首次传送时程序化搭建（49×49 双层甲板、
  玻璃护栏、四角海晶灯、返回磁石，以及轨道炮/长矛/奇点/风暴/卫星/陨石六种轮廓）。
- 安全兜底：掉出平台（Y<40）、在轨道维度死亡重生，都会自动送回进入前位置；
  平台之间可直接用命令换着看，不会覆盖返回点。
- 只加载当前平台所在区块，不申请无界 ticket；维度删除不会影响主世界存档。

### 4.0.5 — 2026-10-19

**新增 `/orbitpreview <cannon|lance|gravity|storm|laser|planet>`：本地预览六种天基载体。**

- 不发包、不伤方块、不伤实体；只在客户端把镜头拉到太空段，完整播放该载体的演出。
- 用来回答“卫星 / 天基炮 / 发射器 / 奇点 / 风暴 / 陨星到底长什么样”——它们目前是**演出层的
  程序化 3D 设施**，不是世界里的方块建筑。
- 设计文档：`docs/skyfall-v5-full-fidelity.md`（自定义 GLSL / FBO 多 pass / Mixin 相机 /
  多线程世界编辑的 v5 规划与里程碑）。

### 4.0.4 — 2026-10-19

**修复 4.0.3 后处理黑屏。**

- **原因一**：在 GUI 之前调用 `PostPass` 时，世界渲染留下的背面剔除仍开着，全屏四边形被整块剔掉，
  主目标随即被 clear 成黑色。现在先 `disableCull + disableDepthTest` 再跑两次 pass。
- **原因二**：`PostPass` 结束时会 `unbindWrite`，之后 GUI 画到默认帧缓冲，最终 blit 出来是黑屏。
  现在 pass 结束后显式 `main.bindWrite(false)` 并恢复 viewport / 关闭深度测试 / 开启混合。
- 后处理仍然只在打击演出期间运行；异常继续自动回退 4.0.2 的 GUI 近似层。
- 如果升级后仍有问题，可先把 `[orbital_strike] post_shader=false` 关掉，把日志里的
  `[天陨] 后处理...` 行发我。

### 4.0.3 — 2026-10-19

**轻量后处理 shader：径向模糊 / 色差 / 廉价 bloom / 白闪 / 调色 / 暗角。**

- 新增 `assets/apocalypse_zombies/shaders/program/`：`orbital`（效果）与 `orbital_blit`（回写）各一对
  `json/vsh/fsh`；用两个 `PostPass` 组合（世界主目标 → swap 做效果 → passthrough 画回主目标），
  **只在打击演出期间运行**，没有打击时零开销。
- uniform：`Strength / Radial / Chroma / Impact / Flash / Vignette / Grade`，由服务端相位与协议色驱动；
  不在 GUI 之后跑 —— 后处理只影响世界画面，不会把 HUD 糊掉。
- **失败自动回退**：程序加载/编译/窗口重建任何异常只记一次 warn，并永久退回 4.0.2 的纯 GUI 近似层；
  配置 `[orbital_strike] post_shader=false` 可手动关闭。
- shader 可用时 GUI 层让位（不再叠调色/色差），速度线、镜头光晕、墨迹冲击帧仍保留。
- 配置总数 221 → 222。

### 4.0.2 — 2026-10-19

**屏幕电影层：径向速度线 / 墨迹冲击帧 / 边缘色差 / 镜头光晕 / 冷紫调色 + 暗角。**

- 新增三张程序化原创贴图（`tools/fx_art.py` 可复现）：`fx_speedlines`（1024² 径向速度线）、
  `fx_flare`（512² 横向镜头光晕）、`fx_ink`（1024² 冲击帧墨迹框）。
- 演出接线：锁定后段~弹体下落段叠旋转速度线；充能段右上角横向 flare；
  命中最初 4 tick 叠墨迹冲击帧、10 tick 红/蓝边缘色差；太空段冷紫调色 + 四边暗角。
- 新增配置 `[orbital_strike] screen_fx`（0~100，默认 100；0 = 关闭整层屏幕演出，防晕）。
- 全部用 GuiGraphics 叠加实现（不建 RenderType、不做 shader/FBO），并受距离衰减。
- 配置总数 220 → 221。

### 4.0.1 — 2026-10-19

**五种天基载体的太空段全部改为动态程序化 3D 舞台；静态 2.5D 电影板退为可选回退。**

- 焚城 / 断层 / 隔离 / 蜂群 / 行星陨落不再铺静态插画，改走 `OrbitalSpaceStage` 里已有的
  **程序化 3D 舰体**：充能时炮管伸出、套环推向炮口、能量脉冲沿炮管跑；开火后坐；
  旋转雷达越充能转得越快；散热板/太阳能翼随充能张开；引力环旋转、等离子舰光带、陨石飞行；
  命中后冲击环/白闪/弹体尾焰全部按相位与 `gameTime` 每帧推进，镜头推近拉远时有真实视差。
- 地球/星云/星空/流星/银河等布景本来就是时间轴绘制（大气呼吸、日角漂移、流星），继续保留。
- 新增配置 `[orbital_strike] static_carrier_plates`（默认 `false`）：设为 `true` 可回到 3.11.0 的
  静态 2.5D 电影板（弱机/低画质回退）。
- 配置总数 219 → 220。

### 4.0.0 — 2026-10-19

**《天陨武库》4.0：可建造的指挥终端 + 相位同步/过场广播/取消 + 全原创太空美术 + 出货门禁。**

这是 3.8.0 之后的大版本收口，把「遥控器自由开火」升级成「终端运营 + 可调参数 + 多人演出」：

- **天陨指挥终端**（3.9.0）：新方块 + 六枚协议核心 + 六边形协议轮盘 + 半径/威力/下落速度滑条 +
  充能进度；服务端权威授权，终端充能/冷却/拆毁退款；`[skyfall_terminal]` 配置段。
- **快速充能**（3.10.0）：手持红石块右键终端，冷却缩短 15 秒/个（物品/秒数/开关可配）。
- **P3 多人演出**（3.10.0）：相位同步包 + 客户端平滑追帧；过场广播给 160 格内玩家（每人可关）；
  拆终端 / `/apocalypse skyfall cancel` / 关服 / 维度卸载都会中止并交还镜头；并发上限与方块预算可配；
  HUD 分施放者/旁观者/区内玩家三套；协议号升到 `"2"`（**服务端与客户端必须同版本**）。
- **P4 资产全部原创**：太空舞台 `earth` / `nebula` / 卫星三件套（3.10.0）与五张天基载体电影板
  （3.11.0）全部改为程序化自绘美术；`tools/check_orbital_art.py` 与 `tools/check_carrier_art.py`
  用 dHash 门禁证明与参考图距离 ≥18（实测最小 23），参考照片不随 jar 分发。
- **P5 出货门禁**：新增 `tools/check_skyfall.py`（jar/版本/资产链/数据/语言/配置/原创性/文档 九组判据）
  与 `tools/_deploy_400.py`（构建 → 门禁 → 探锁部署 → 备份 → 事后校验，其它模组 md5 快照）。
- **UI**：ESC 暂停菜单两列网格（3.10.1，`pause_menu.xml` 的 `columns` 可改回单行）；菜单通用背景换成
  无字无按钮的干净底图（3.10.2）。
- 配置总数 211 → **219**；新增 `tools/menu_background.py`、`tools/skyfall_art.py` 等可复现资产生成脚本。

### 3.11.0 — 2026-10-19

**P4 收尾：五张天基载体电影板全部重绘为原创程序化 2.5D 美术，参考照片不再进包。**

- `carrier_cannon` / `carrier_lance` / `carrier_singularity` / `carrier_plasma` /
  `carrier_asteroid` / `carrier_asteroid_cutout` 六张全部由 `tools/carrier_art.py` 生成：
  块面化 Minecraft 科幻风（模块船体 / 桁架 / 太阳能板 / 炮管 / 加速环 / 引擎吊舱 / 不规则小行星），
  背景为深空星野 + 方块化地球弧面。
- 构图锚点对齐 `OrbitalCarrierPlates.spec()` 的炮口 / 焦点 / 引擎归一化坐标（±0.05），
  充能、炮口、命中特效不会跑位；小行星 plate 与抠图使用同一不规则轮廓。
- 新增 `tools/check_carrier_art.py`：尺寸 / 格式 / alpha 校验 + 每张与对应参考图的 dHash 距离门禁
  （阈值 18，**实测最小 23**）+ cutout 不规则轮廓门禁（32 方向半径 max/min ≥ 1.10）。
- 至此太空舞台 `earth` / `nebula` / 卫星三件套（3.10.0）与五张载体板（本版）全部原创；
  参考照片只留在仓库根作设计对照，不随 jar 分发。
- 贴图由程序化脚本可复现生成（无随机熵），两轮未改文件 sha256 一致。

### 3.10.2 — 2026-10-19

- **菜单通用背景换成干净底图** `menu_background.png`（从《废土城市》插画派生、末日紫调，
  图中没有任何文字与按钮）：断开连接、选项、多人、模组列表等界面不再从对话框后面透出
  《末日菜单》原图里烤死的标题字与四个石质按钮（就是截图里那种「重影 UI」）。
- 标题界面仍用原《末日菜单》图：它自己的真实按钮正好盖住图里那四个按钮，标题字是标题页的一部分。
- 新增 `tools/menu_background.py` 可复现生成干净底图（紫色调色 + 顶部压暗）。

### 3.10.1 — 2026-10-19

- **ESC 暂停菜单改成两列网格**（3 行 × 2 列，底部居中）：列数由
  `assets/apocalypse_zombies/ui/pause_menu.xml` 的 `columns` 控制（`1` 回到 3.5.0 的单行横向工具栏），
  资源包可覆盖；局域网按钮在单人未开放时隐藏会剩 5 个，最后一行自动居中。
- **「退出」确认走保存流程**：`halt(false)` → `Saving worlds` → 三个维度写盘 → `Stopping!`，
  实机日志（11:39:54）已验证，不会丢进度。
- 快速充能提示从聊天栏改到**动作栏**，连点红石块不再刷屏。

### 3.10.0 — 2026-10-19

**P3：相位同步 / 过场广播 / 可取消的打击 + 快速充能；P4-A1：太空舞台五件套原创化。**

- **相位同步**：新增 `StrikePhasePacket`，服务端在 MARK/ASCENT/DEVICE/FIRE/IMPACT/AFTERMATH 六个相位各发一次；
  客户端按协议 `phaseStart` 对表，偏差 >3 tick 时用平滑时间偏移（每 tick ×0.85）追帧，卡顿/掉帧后不再「提前落地」。
  网络协议号 `1 → 2`：服务端与客户端必须同版本。
- **过场广播**：施放者附近（`broadcast_radius`，默认 160 格）的玩家也会看到同一部电影与旁观 HUD；
  每个客户端可用新增的 `apocalypse_zombies-client.toml`（`films.broadcast_films=false`）只看世界效果、不抢镜头。
- **可取消**：新增 `StrikeCancelPacket` 与 `cancel/cancelAll/cancelForTerminal`。拆终端（`cancel_on_break`，FIRE 前退还充能）、
  `/apocalypse skyfall cancel`、关配置、关服、维度卸载都会中止并交还镜头，不再出现「镜头挂在太空、地面不再塌」的僵死观感。
- **并发与预算**：`max_concurrent_strikes=2`、`strike_block_budget=4000` 可配；超限时第 N 次请求被拒绝并提示。
- **快速充能**：手持红石块右键天陨终端 → 冷却缩短 15 秒/个（`quick_charge_seconds` 可调、`quick_charge_item` 可换、
  `quick_charge_enabled` 总开关）；终端面板会显示当前物品与缩短秒数。
- **运维口**：`/apocalypse skyfall strikes` 看当前并发与上限；`/apocalypse skyfall cancel` 中止全部未结算打击。
- **HUD v2**：施放者六段协议色相位条；旁观者顶部「代号 // 远程授权」细横幅 + 剩余秒 + `[K]` 跳过；
  区内玩家显示距离警告；打击被中止时 3 秒提示。
- **P4-A1 资产原创化**：`earth` / `nebula` / `sat_body` / `sat_panel` / `sat_dish` 五张太空舞台贴图全部换成
  程序化原创资产（`tools/orbital_art.py`，可复现）；新增 `tools/check_orbital_art.py` 做尺寸/alpha 与
  参考图 dHash 距离门禁（全部 ≥18 才通过）。5 张 1408×768 载体板留到 P4-A2/A3。
- 配置总数 211 → 219。

### 3.9.0 — 2026-10-19

**v4.0 P1+P2：天陨指挥终端 —— 从「遥控器自由开火」变成「建造终端 + 装核心 + 充能 + 调参 + 授权打击」。**

- **新方块「天陨指挥终端」**（`skyfall_terminal`）：5 铁块 + 下界合金锭 + 红石块合成；右键打开六边形协议面板，
  自带光源、掉落表、方块实体（首次引入自定义方块注册类 `ModBlocks` / `ModBlockEntities`）；
- **六枚「协议核心」**：`skyfall_core_cinder / fault / quarantine / swarm / dawn / black_rain` 分别解锁
  焚城 / 断层 / 隔离 / 蜂群 / 黎明 / 黑雨；右键终端安装（创造模式不消耗）。本版**只放出焚城核心的配方**
  （下界合金碎片 + 烈焰粉×2 + 岩浆膏），其余五枚可创造模式取得，配方等 P3 补齐；
- **终端面板**：六边形协议轮盘（节点色直接取 `strike/*.xml` 的协议色，未解锁上锁）、半径 / 威力 / 下落速度
  三条滑条（50%~200%）、过场开关、充能进度条 + 倒计时、主人名、已装核心 x/6；
- **服务端权威**：遥控器只负责「瞄哪儿」；周边 64 格内最近的终端决定用哪份协议、打多大、多疼、落多快。
  终端每打一发按 `terminal_charge_seconds` 充能（默认 60s），期间拒绝授权并提示剩余秒数；
- **新配置段 `[skyfall_terminal]`**：`terminal_required`（默认 true，没有终端就不能呼叫打击）、
  `terminal_range`（64）、`terminal_charge_seconds`（60）、`terminal_owner_only`（false）、`terminal_radius_max`（48）；
- **向后兼容**：`terminal_required=false` 时遥控器退回 3.8 的自由开火行为，旧存档照常能玩；
- 贴图与模型全部原创（`tools/skyfall_art.py` 可复现生成，未使用任何参考图素材）；
- 验证：`gradlew build` 通过；专用服务器启动无注册/数据包错误；RCON 实测放置终端（方块实体 NBT 正确）、
  掉落表正常掉落 `Skyfall Terminal`。

### 3.8.0 — 2026-10-18

**P2：黎明 / 黑雨接入引擎 v2 —— 六种末日协议全部落地。**

- **黎明 DAWN（宇宙激光）**：只净化亡灵，玩家/村民/动物不受伤；浅玻璃碗坑 + 坑沿白玻璃/海晶灯，
  命中后中心立起 4 格白玻璃 + 海晶灯的光柱；白金光柱从深空贯到地表，客户端画三层同心光环；
- **黑雨 BLACK RAIN（行星陨落）**：脏弹陨石砸出宽而浅的黑碗（菌岩/黑曜石/黑色混凝土），
  坑心种一枚幽匿催发体；撞击后默认 30 秒毒雨区：**只毒生者、亡灵免疫、施放者免疫**，
  持续中毒/凋零并熄灭火焰；客户端雾色转脏紫、屏幕斜落紫黑雨丝，小行星尾焰/落点/陨石全部转毒紫；
  HUD 增加「毒雨只伤生者 · 亡灵免疫」警告；
- 新增配置 `[orbital_strike] black_rain_ticks`（100~2400，默认 600）；
- 引擎：关服/退世界时清空挂起的打击、毒雨、雷声与破坏队列，旧打击不会落到下一个世界；
- 六种协议（焚城/断层/隔离/蜂群/黎明/黑雨）现在全部按 XML 相位计时、共用同一套电影/HUD/跳过键；
- 仍然只用原版 RenderType / 事件相机，不引入 shader、FBO、Mixin。

### 3.7.0 — 2026-10-18

**P1：蜂群 / 隔离 / 焚城三份原创协议接入引擎 v2。**

- **蜂群 SWARM（等离子风暴）**：7 枚巢荚按蜂巢落点逐一落下；每枚留下可破坏的
  sculk 巢荚 + 菌毯（不挖坑）；最后一道统一孵化，按 `[orbital_strike] swarm_brood`
  （默认 3/荚，共 21 只）刷僵尸，`swarm_spawn=false` 可只留巢荚；HUD 增加「巢荚会唤醒尸群」警告；
  2.5D 等离子舰的 7 个落点/孢子改为绿色；
- **隔离 QUARANTINE（引力奇点）**：不炸坑；边界铺白玻璃/海晶灯环，中心立三格白玻璃 + 海晶灯信标；
  圈内亡灵即死，玩家/村民/动物不受伤；客户端画白/冷青力场墙与中心光柱；
- **焚城 CINDER（轨道炮）**：保留整列贯穿，坑沿铺熔岩斑 + 火焰/岩浆/灰烬风暴；
  余波阶段按弹种持续冒火/烟/灰（蜂群冒孢子、隔离冒冷白）；
- 三个协议都按 XML 相位走（MARK 地面预告 → 升空 → 装置 → 发射 → 命中 → 余波），
  HUD 显示各自代号/相位/`[K] SKIP`；断层仍是折线裂谷；
- 新增配置 `swarm_brood`（0~8）与 `swarm_spawn`（默认 true）；
- 仍然只用原版 RenderType / 事件相机，不引入 shader、FBO、Mixin。

### 3.6.0 — 2026-10-18

**打击引擎 v2 第一刀：六份原创「末日协议」的数据层 + 断层 FAULT 实装（不再照抄参考包）。**

- **引擎 v2**：新增 `orbital/engine` —— `StrikePhase`（MARK/ASCENT/DEVICE/FIRE/IMPACT/AFTERMATH）、
  `StrikeProtocol`（代号/颜色/相位/地形参数）、`StrikeProtocols`（读取
  `assets/apocalypse_zombies/strike/*.xml`，JDK DocumentBuilder，失败回落内置定义）；
  六份协议 XML 已登记：焚城/断层/隔离/蜂群/黎明/黑雨，后续逐个迁移；
- **断层 FAULT（天基长矛的 v2 形态）**：
  - 服务端：玩家朝向决定裂谷方向；`RiftShape` 生成与服务端/客户端完全一致的折线
    （长 96、宽 7、深 40，随机游走 + 抖动）；`RiftJob` 按全局 4000 格/tick 预算逐点挖开，
    截面随深度收窄成 V 形；伤害沿整条折线判定；命中音效 + 按距离延迟的地鸣；
  - 客户端：MARK 相位（35t）先在地面画金色折线裂缝预告（两侧边线 + 横向刻度 + 中心钉入环），
    然后升空进入载体特写；命中后沿折线画高温谷口/向下光井，而不是圆坑冲击环；
  - HUD：`FAULT // 断层`、相位行（MARK/ASCENT/DEVICE/FIRE/IMPACT/AFTERMATH）、
    `[K] SKIP` 跳过提示；新增 `K` 键绑定（跳过只交还镜头，结算照常）；
- 电影时间轴开始按协议相位走：FAULT 先留 35t 地面标记再升空；其他五种仍走 v1 时间轴；
- 仍然只用原版 RenderType / 事件相机，不引入 shader、FBO 或 Mixin。

### 3.5.0 — 2026-10-18

**ESC 暂停菜单改为横向 XML 工具栏；2.5D 发射过场补「由远到近推近 + 平台充能/发射」动效。**

- **暂停菜单横向化**：按钮从竖排改成屏幕底部的横向工具栏，布局/短标签/间距由
  `assets/apocalypse_zombies/ui/pause_menu.xml` 描述；`PauseMenuLayout` 用 JDK 的
  `DocumentBuilder` 解析（资源包可覆盖 XML，不用重编译），按钮行为仍由 Java 的 action
  白名单分发（resume/advancements/stats/options/lan/quit），XML 不能注入代码；
  XML 缺失或解析失败时回落到内置横向布局；
- **由远到近的过场**：轨道炮/长矛/奇点/等离子风暴开场改为整幅远景，锁定前 65% 内平滑推近
  到平台特写；远景阶段压暗 70%（隐藏画里已有的光束/爆炸），推近的同时亮度恢复，
  命中点已在特写画外，不再一开场剧透；
- **各平台充能/发射动画**：
  - 轨道炮：三团橙光沿炮管向炮口跑 + 炮口旋转充能环 + 发射闪光/后坐震动；
  - 天基长矛：五级电磁线圈逐级点亮 + 跨轨电弧 + 发射瞬间蓝白爆闪；
  - 引力奇点：涡旋加速旋转 + 炮管线圈逐段点亮 + 发射冲击环；
  - 等离子风暴：反应堆约束环 + 导管光团流向炮口 + 反应堆爆闪；
  - 行星陨落：小行星自转 + 迎风激波锥 + 尾焰/碎屑（沿用 3.4.0 的飞向地球与 62% 缩小）；
- 仍然只用原版 RenderType（`entityTranslucentEmissive` / `lines` / `debugQuads`），
  服务端伤害/挖掘/时序零改动。

### 3.4.0 — 2026-10-18

**2.5D 过场补上「平台开火 → 弹体飞行」动画；行星陨落改成小行星飞向地球并逐渐缩小。**

- 轨道炮 / 天基长矛 / 引力奇点：**拉镜提前到发射瞬间**（不再等命中前 2 tick），
  玩家能看到平台充能后开火、弹体/束流从炮口飞出；新增发射闪光、逐渐缩小的弹芯、
  白热尾迹与奇点核心脉冲；命中前镜头已完整展开，弹体沿画里的弹道飞向爆点；
- 等离子风暴：保持命中前拉镜（画里的爆炸提前展开会剧透），反应堆爆闪 + 五道落点逐 8 tick 落下；
- **行星陨落重做**：不再整张铺小行星特写，改为 **星云背景 + P0 地球 + 小行星抠图** 的 2.5D 场景：
  小行星从左上地球方向缓缓压过去（锁定 25% 处就开始移动，不干等），飞行途中
  **线性缩小到原来的 62%**（不会小到看不见），身后拖橙红尾焰和碎屑；命中点落在地球表面，
  白闪 + 双层扩散环，随后切回真实地面弹坑；
- 新增 `textures/environment/carrier_asteroid_cutout.png`（600×600 圆形羽化抠图）；
  所有新层仍走原版 `entityTranslucentEmissive` / `lines` / `debugQuads`，无自定义 RenderType。

### 3.3.1 — 2026-10-18

**选择世界界面的泥土底换成图1（废土城市插画）。**

- 根因：`SelectWorldScreen.render` 不调用 `renderBackground`，全局 `DoomMenuTheme` 的
  `BackgroundRendered` 根本不会触发；`WorldSelectionList` 又在列表区域自绘原版泥土，
  把主题背景整个盖住（3.2.0 的选择世界背景因此没有生效）；
- 新增 `ScreenEvent.Render.Pre`：在屏幕绘制前铺 `pause_background.png`（废土城市，
  `0x80` 压暗 + 紫调）；`ScreenEvent.Init.Post` 里调用
  `WorldSelectionList#setRenderBackground(false)` 关掉列表自带的泥土；
  如果某个版本仍走 `BackgroundRendered`，那里会再铺一次同一张图，保证泥土不透出来；
- 世界列表、搜索框、按钮照常绘制在最上层；按钮仍是末日石质。

### 3.3.0 — 2026-10-18

**五张实拍级载体接管五种轨道打击的太空段；打击一发起就升空，玩家从头看到尾。**

- 新增 `OrbitalCarrierPlates`：把用户给的五张 1408×768 载体重绘作为电影板（随包分发）——
  天基炮 → 轨道炮、天基矛发射器 → 天基长矛、引力奇点 → 引力奇点、小行星 → 行星陨落、
  等离子发射器 → 等离子风暴；宇宙激光保留原来的程序化卫星舞台（其他保留）；
- **去掉地面等待**：以前镜头要等到锁定结束前 40 tick 才升空，现在打击发起后 40 tick（2 s）
  直接升到轨道机位，整段锁定都在看载体的充能特写；
- 镜头语言：锁定阶段贴近载体（炮口/反应堆在画面里，完整光束在画外）→ 命中前 2 tick 开始
  快速拉开 → 命中时整幅画面展开，画好的光束/爆炸随拉镜一起揭示；叠加炮口焰、束流亮点、
  冲击环、屏幕震动与 FOV punch。小行星模式没有光束：一路推近，命中白闪切回地面；
- 每种弹种的电影板动画：引擎喷口闪烁、炮口/反应堆充能光、收拢环、发射束流、命中白闪/扩散环；
  奇点额外有旋转吸积环；风暴五道落点逐 8 tick 落下（第一道与画里的主爆炸重合，
  其余四道在附近补闪）；等离子特写聚焦舰体反应堆（避开画面里已有的巨大光束），
  发射时反应堆爆闪，拉镜后揭示光束与爆炸；
- 仍然只用原版 RenderType（`entityTranslucentEmissive` / `lines` / `debugQuads`）+
  NEW_ENTITY 全属性顶点；无自定义 RenderType、无 shader/FBO；服务端伤害/挖掘/时序零改动
  （只改了客户端演出时间轴）。

### 3.2.0 — 2026-10-18

**两张专门的末日插画接管「ESC 暂停」与「读取世界数据 / 加载世界」；六种轨道打击的发射台全部动起来。**

- **暂停界面换图**：`gui/pause_background.png`（1408×768 的废土城市插画，图上没有烤死的
  按钮/标题）；仍然只铺图 + 一列末日石质按钮，暗化从 `0xCC` 降到 `0x80`，插画本身看得清；
- **加载界面只有图**：新增 `ApocalypseLoadingScreen` —— 「读取世界数据中…」那段原版泥土屏
  整屏换成 `gui/loading_background.png`（碎裂之月插画），不画标题、不画提示；
  进入世界后的 `LevelLoadingScreen`（百分比 + 区块网格）与 `ReceivingLevelScreen`
  （「加载地形中…」）用 `ScreenEvent.Render.Post` 盖同一张图，三段加载连成一张画；
- **选择世界**（存档列表）也改铺同一张加载插画 —— 标题图上烤死的菜单按钮不会再透在列表后面；
- **六种轨道打击的发射动画**（全部由客户端演出时钟 / `phase` 驱动，服务端零改动；
  发射装置的充能从「镜头抵达轨道」的 0 算到「开火」的 1，而不是沿用锁定时长）：
  - 轨道炮：炮管充能伸长、滑动套环推到炮口、四圈能量脉冲沿炮管跑、散热板随充能张开、
    顶部雷达加速旋转、炮口蓄能核由暗到白热；
  - 天基长矛：五级电磁线圈依次点亮、导轨电流脉冲、跨轨电弧、矛尖在发射前从炮口成形；
  - 引力奇点：环状站起旋转并收拢、28 颗尘埃螺旋坠入核心、炮管线圈依次点亮、发射冲击环；
  - 等离子风暴：五枚投放舱从紧凑队形展开、逐舱舱门滑开、舱间电弧、发射后向上反冲；
  - 行星陨落：七块伴飞碎屑、迎风激波锥、随速度变亮的热辉；
  - 宇宙激光：抛物面天线从侧对镜头转向地球、馈源扫描环加速、发射口滑门打开、
    太阳翼高光扫过、束流上五圈白环向地球跑；
- 仍然只用原版 `RenderType.lines()` + `debugQuads()` 与现有实体渲染类型：不建自定义
  RenderType、不做 shader/FBO。

### 3.1.0 — 2026-10-18

**暂停界面重做（末日风、无原版文字）+ 轨道打击改「逐层下削」。**

- **暂停界面**：新 `ApocalypsePauseScreen` 替换原版 `PauseScreen` —— 只铺《末日菜单》背景
  （更重的暗化）+ 一列末日石质按钮（回到游戏 / 进度 / 统计 / 选项 / 对局域网开放 / 保存并退出），
  **不画 "Game Menu" 标题**；行为与原版一致（单人暂停、ESC 回游戏、退出走原版断连路径）；
  全局菜单主题把它排除，避免二次上色；
- **逐层下削（默认破坏模式）**：新 `LayerJob` —— 以落点为圆心、半径 r 的方形区域，
  **一层（同高度整片）挖净后停 `layer_ticks` tick 再下一层**，从地表一直磨到半径深度；
  每层收尾在中心撒火花、每三层一声石头闷响，弹坑看得见地一层层变深，而不是一炮到底；
  每层选区超过每 tick 预算时跨 tick 完成，但绝不跨层推进；
- 新配置 `[orbital_strike] destroy_mode` 默认 `layers`（可选 `cube` / `column`）+
  `layer_ticks`（默认 2，0~20）；长矛/炮台仍强制整列挖穿；
- 已把本机实例的 `destroy_mode` 改为 `layers`。

### 3.0.0 — 2026-10-18

**P0 贴图化：太空舞台的「卫星 / 地球 / 星云」三件套从程序化几何换成参考图贴图。**

- 新增 `textures/environment/` 五张由参考图裁出的贴图（随包分发）：
  `earth.png`（地球圆盘，圆形透明遮罩）、`nebula.png`（宇宙全景 1024×512）、
  `sat_body.png`（金色隔热膜）、`sat_panel.png`（太阳能电池格）、`sat_dish.png`（白色抛物面天线，圆形遮罩）；
- 渲染改走**原版实体渲染类型**（`entityCutoutNoCull` / `entityTranslucent` / `entityTranslucentEmissive`），
  顶点按标准 NEW_ENTITY 格式完整写入（color + uv + overlay + lightmap + normal）；
  1.5.0 踩的是 beaconBeam 的 4 元素格式，这条管线不碰；
- **星云**：参考图的宇宙全景贴到世界轴固定的天球上（球心跟相机、朝向不跟相机，转视角星空不走样），
  程序化的银河/星云/星系三层由它接管；锐利的程序化星群与流星仍叠在贴图上；
- **地球**：程序化大陆/云带/城市灯整段换成参考图的地球圆盘，保留原有大气辉光与晨昏弧；
- **卫星**：舱体换成金箔贴图盒，太阳能翼电池片换成电池格贴图，大天线换成白碟贴图（圆形遮罩），
  金色边框、仪器、推进器与导航灯维持原样。

### 2.12.0 — 2026-10-18

**全局菜单末日化：暂停、选项、选择世界、多人、资源包、语言、模组列表、载入界面……统一
末日背景 + 暗紫压暗 + 末日石质按钮。**

- 新 `client/gui/DoomMenuTheme`：背景挂在 `ScreenEvent.BackgroundRendered`（原版背景画完后整体
  覆盖同一张《末日菜单》图，cover 铺满 + `0x99000000` 压暗 + 冷紫调）；按钮换肤挂在
  `ScreenEvent.Init.Post`，把**类就是 `Button`** 的实例原样替换成 `DoomButton` 外壳 ——
  点击转交原 `onPress()`，可用/可见状态每帧同步（界面里按选择实时置灰的按钮照常置灰）；
- 排除：标题界面（自绘）、本模组配置/交易界面、物品容器界面（背包/箱子/合成台）、聊天与死亡
  界面；图标按钮 / 自绘子类 / 滑块 / 复选框 / 列表行内按钮一律不动，避免破坏它们自己的渲染；
- `DoomButton` 提取为公共类（标题界面的按钮改为复用它，样式一处维护）：灰石面 + 顶面高光 +
  深色描边 + 白字（高按钮 2× 像素字），悬停/聚焦亮紫框 + 紫白字。

### 2.11.0 — 2026-10-18

**标题界面菜单与参考图对齐：按钮铺在图里那四个按钮上（盖住烤死菜单，不再重影）。**

- 背景《末日菜单》原图（1408×768，烤死了标题字与四个按钮）自 2.8.0 起就是标题背景；本版把
  「我们自己的四个按钮」按图内实测像素矩形（x 486–921；四行 y 344 起、行距 70、行高 60，含
  紫框外扩）连同 cover 变换一起铺上去 —— 实心石面正好盖住图里的按钮，布局、标题、比例
  全部沿用参考图；
- 按钮样式对齐参考图：中性灰石面 + 顶面高光 + 深色描边 + 白字（按钮够高时 2× 像素字），
  悬停/聚焦亮紫外框、文字转紫白；打开界面默认聚焦第一项（对应参考图 SINGLEPLAYER 的亮紫框）；
- 底部动态版本行只盖住图里占位文字那一段（含 MOJANG 标志一侧留白），右侧 MOJANG 标志可见；
  GitHub / 团队站两个链接保留，带阴影提升在底图上的可读性。

### 2.10.0 — 2026-10-18

**情境音乐导演：世界内 BGM 按场景自动换曲（探索 / 矿洞 / 血月 / 蓝月）。**

- 新增三首配乐（全部 ffmpeg 转流式 OGG，libvorbis q6 / 44.1 kHz）：
  《The Quiet Latitude》(2:50)、《The Weight Of Stone》(2:52)、《Crimson Countdown》(2:55)；
  `sounds.json` + `ModSounds` 各注册三条 `music_*`；
- 新 `client/music/ContextMusic` 优先级导演：
  **血月（含超级血月）→ Crimson Countdown > 蓝月（含超级蓝月）→ The Last Known Meridian >
  矿洞（主世界、头顶看不到天空）→ The Last Known Meridian > 地表探索（其余，含下界/末地）
  → The Quiet Latitude**；
- 防抖：月亮状态立即切换；探索 ⇄ 矿洞需连续 3 s 稳定才切（洞口来回走不会疯狂切歌）；
  切曲从新曲开头开始；循环沿用「`looping=false` + 每 tick 查 `isActive`」；
- 新配置段 `[context_music]`：`enabled` / `volume` / `exploration_track` / `cave_track` /
  `blood_moon_track` / `blue_moon_track` —— 曲名可换（例如把 `cave_track` 改成
  `the_weight_of_stone` 就换成《石之重》，不用改代码；未使用的曲目也已随包分发）；
- 与既有两套的关系：主菜单 = 《The Last Known Meridian》（2.9.0）；世界内 = 情境导演接管，
  「朋友的酒」让位；把 `context_music.enabled` 关掉即回到「朋友的酒」全局播放的旧行为。
  F10 / `friends_wine_music.enabled` 仍是自研音乐总开关。

### 2.9.0 — 2026-10-18

**主菜单曲《The Last Known Meridian》：标题界面专属 BGM，进世界后让位给「朋友的酒」。**

- `The_Last_Known_Meridian.mp3` → `sounds/music/the_last_known_meridian.ogg`（ffmpeg libvorbis
  q6 / 44.1 kHz，2 分 37 秒，流式 OGG；Minecraft 不支持 MP3，必须转码）；
- 新 sound event `music_the_last_known_meridian`（`"stream": true`）+ `ModSounds` 注册；
- 新 `client/music/MainMenuMusic`：`level == null`（标题/载入/连接中）时循环播放，一进世界立刻停；
  循环走与「朋友的酒」同一套「`looping=false` + 每 tick 查 `isActive`」的流式方案；
  播放期间让原版主菜单曲 `MusicManager#stopPlaying()`（是否压原版沿用
  `friends_wine_music.suppress_vanilla`）；
- `FriendsWineMusic` 在菜单里让位（`level == null` 即停）—— 两个界面各有一首，互不打架；
- 新配置段 `[main_menu_music] enabled / volume`；F10 与 `friends_wine_music.enabled` 仍是
  总开关（关掉 = 自研音乐全静音）。

### 2.8.0 — 2026-10-17

**主菜单换成末日风：紫电浮空岛背景 + 裂纹石按钮 + 底部项目链接。**

- 原版标题界面由 `ApocalypseTitleScreen` 接管（通过 `ScreenEvent.Opening` 替换 `TitleScreen`）；
  背景是 `textures/gui/apocalypse_title.png`（1408×768，按 cover 铺满窗口，不拉伸变形）；
- 四个按钮用代码重绘成参考图的样式：深紫描边、灰色石面、顶面高光、几道随机位置裂纹；
  悬停时外圈紫色泛光、石面提亮、文字转紫白；
- 按钮依次是单人游戏 / 多人游戏 / 选项 / 退出游戏，均为原版界面的正常入口；
- 底部信息条：左侧「Apocalypse Zombies | Ver 版本号 | 玩家名」；
- **底部中间两个可点击链接**：GitHub（`SevenZeroMeowTeam/apocalypse_zombies`）与团队
  （`team.qlm.org.cn`），悬停变亮并出现紫色下划线，点击先弹原版外链确认再打开浏览器；
- 窄窗口下链接自动缩写为「GitHub / Team」，不会挤出屏幕。

### 2.7.2 — 2026-10-17

**「朋友的酒」改为全局背景音乐，并加了一键开关。**

- 之前只在进入世界后播放；现在主菜单、暂停界面、世界里都会一直循环（离开世界不再掐断）；
- **F10** 运行时开关：与配置 `[friends_wine_music] enabled` 同步，切换后会写回配置文件，
  屏幕下方会提示「已开启 / 已关闭」；
- 仍保留原有的 `volume`（与原版音乐音量相乘）与 `suppress_vanilla`（让原版音乐让位）；
- 把音乐音量拉到 0 时仍会停止流式解码，不占用解码线程。

### 2.7.1 — 2026-10-17

**「天基长矛」与「引力奇点」按新参考图重做。**

- **天基长矛 → 轨道质量投射器**：长条形中央脊梁 + 三段环形加速炮管（亮蓝环）+ 两侧各两片
  深蓝太阳能翼（金色边框）+ 蓝白能量管线与红色警示灯；发射的不是光柱，而是一枚
  **金属矛体**：分段弹芯 + 四片 X 形尾翼 + 16 格蓝白尾焰与七节收缩尾环，沿两条平行导轨方向
  扎向地球；
- **引力奇点 → 环状奇点炮台**：24 段深色舱段围成的巨型环站（蓝光条 + 红色警示灯）、
  中央纯黑视界与 60 条高速旋转的蓝白吸积丝、以及从环心伸向地球的四段长炮管；
  开火时炮口喷出三线蓝白光束，沿线八道能量环；
- 两个模式都保留了命中时的 `earthImpact`（白热闪环 / 扩散环 / 碎片射线）。

### 2.7.0 — 2026-10-17

**按参考图整体重做外观与演出：实体卫星、战舰式天基炮、带螺旋星系与彩色星云的深空、
高分辨率地球、带陨石坑的小行星，以及穿大气层的入场/返回转场。**

- **卫星**（`renderStation`）：金色隔热膜舱体 + 朝镜头的大白色抛物面天线（馈源杆 + 双支撑）+
  两侧各三片深蓝太阳能翼（金色边框、电池片网格）+ 顶部三组仪器 + 底部双推进器与橙色余晖；
- **天基炮**（新增 `renderDreadnought`）：金属灰多模块战舰、橙色发光核心环、侧面武器舱、
  背部散热板、尾部推进焰；炮口到弹体之间新增橙白高热光束，马赫环与尾迹统一改成橙色系；
- **深空背景**：右上方一颗大螺旋星系（暖白核心 + 四条对数螺旋臂 + 臂间星点 + 倾斜盘面）、
  四团品红/橙金/冰蓝/青绿星云（含亮结）、14 个远景星系、最亮恒星带四芒星；
- **地球**：球面网格 30×48（更圆的边缘）、海面镜面高光、10 条会旋转的云带、
  大气层改为三圈**实心蓝色泛光**而不是细线，外圈带呼吸；
- **小行星**：不规则噪声轮廓的灰色岩体，分面明暗 + 四个陨石坑（深色盘 + 亮边），
  翻滚速度更快、体积更大；
- **转场**：升空阶段屏幕边缘泛蓝 + 竖直速度线（穿大气层），轨道段结束返回时一层
  暖蓝色进入大气层闪光；全部画在 HUD 最底层，不遮挡火控读数。

### 2.6.2 — 2026-10-17

**卫星从线框全息改成实体：金色隔热膜舱体、浅灰设备平台、深蓝太阳能电池翼、白色抛物面天线。**

- 新增 `solidBox`（六面填充 + 按朝向分面明暗）与 `solidDisc`（同心环带实心圆盘）两个图元 ——
  在不引入贴图、自定义 RenderType 的前提下做出体积感；
- 轨道站重做为写实卫星：金色多层隔热膜舱体 → 顶部设备平台 → 两侧桁架 → 太阳能翼
  （浅灰边框 + 深蓝电池片 + 蓝色电池片网格线）→ 朝下的抛物面天线（亮边 + 馈源杆）→
  白/红两盏导航灯；
- 等离子风暴的五枚投放舱同步改成实心舱体 + 深蓝电池翼；
- 轨道炮的线框炮管上加了一段实体炮口制退器；
- 全部仍走 `RenderType.debugQuads()`（面）与 `RenderType.lines()`（网格/灯），
  服务端逻辑无改动。

### 2.6.1 — 2026-10-17

**宇宙全景：把原来「一黑到底 + 两块大色板」的太空底换成真正的全天球星空。**

- 去掉所有巨大单面片（深空盒与两块星云面），改为 18×36 的暗蓝渐变穹顶 ——
  天顶接近纯黑、朝地平线略偏蓝，并带极轻的面片抖动，不再出现整块色板或色带；
- 银河带：沿一个倾斜大圆聚集的 600+ 颗淡蓝星，带呼吸明暗；
- 三团彩色星云：紫 / 蓝 / 青三组、每组 34 个很小的半透明色块叠出雾感；
- 一个遥远的旋涡星系：两层椭圆盘 + 四条旋臂；
- 约 900 颗恒星：蓝白 / 纯白 / 暖黄三种色温、分大小、各自脉动；
- 两粒偶发流星按周期划过；
- 以上全部程序化生成、固定种子（每次播放同一片星空），仍只使用
  `RenderType.lines()` + `RenderType.debugQuads()`，不引入任何外部图片素材。

### 2.6.0 — 2026-10-17

**演出强化：让整套轨道打击「动起来」—— 活的星球、有后坐的发射装置、会留疤的地面。**

- 地球动态：云层绕球心缓慢旋转、夜面城市灯光各自闪烁、大气外晕呼吸、晨昏线随太阳方向
  极缓慢漂移 —— 太空段不再是静止贴图；
- 发射反馈：轨道炮台 / 长矛台开火后沿炮管反方向后坐（8~10 tick 回位）；炮口白热激波 +
  青色外环 + 五道火花；动能弹尾流加了一串交替大小的**马赫环**；激光束带 2.4 Hz 闪动；
- 命中效果（每种弹种共用）：白热闪环 + 三层扩散环 + 十二道碎片射线 + 中心余辉；等离子
  风暴每道闪电多两条分叉；陨石本体缓慢翻滚，落地后炸成六片飞散；奇点加了一圈紧贴视界的
  爱因斯坦环和外层暗环，坍缩时向地球释放冲击闪光；
- 地面阶段新增：三层**上升冲击柱**（空气被整片顶起）+ 贴地**焦黑环** + 两道呼吸的**热浪环**，
  与原有的白热快环 / 电青慢浪 / 冲击壳 / 地面裂纹叠加；
- 全部仍使用原版 `RenderType.lines()` + `RenderType.debugQuads()`，无自定义 RenderType、
  无 shader/FBO；服务端伤害与地形结算没有任何改动。

### 2.5.1 — 2026-10-17

**渲染兼容性排查：雨天、低视距与多层渲染目标下的太空舞台修正。**

- **雨天破戏**：原版雨雪是绕相机 ±10 格画的，镜头升到 Y=460 后雨丝会悬在太空底前面。
  演出窗口内把客户端本地降水压到 0（只改视觉字段、不发包、不动服务器天气），结束原样恢复；
- **低视距裁剪**：远裁剪面 = 有效视距 × 16 × 4，2~6 区块时 170 格外的深空底会被切掉。
  现在整场布景按 `clamp(far/768, 0.42, 1)` 等比拉近（距离与半径、站点尺寸一起缩放），构图不变；
- **绘制阶段提前到切边方块之后**：水、云、粒子的深度副本都发生在这之后，不会再合成到
  太空画面之上（Fancy 与 Fabulous 的渲染目标顺序都能对上）；回位段仍由世界层效果接上；
- 雾已核实不构成问题：太空面片用的 `position_color` 着色器没有雾；线框用的
  `rendertype_lines` 虽然带雾代码，但其 `FogColor` alpha 默认 0、RenderType 批量绘制时
  不会从 RenderSystem 刷新，实际不吃雾；
- 仍然只用 `RenderType.lines()` + `RenderType.debugQuads()`，不建自定义 RenderType、
  不做全屏 shader/FBO。已知限制：Fabulous 模式下 `lines()` 走 ITEM_ENTITY_TARGET 的
  目标合成顺序由原版决定，若出现线框缺层属该模式的已知不稳定项；光影包会替换这两个
  原版着色器，表现以其实现为准。

### 2.5.0 — 2026-10-17

**六种打击全部搬到外太空：镜头不再停留在地面近景，而是一律升到 Y≥460 的轨道机位，
看着各自的天基平台把这一击打向地球。写实向的地球昼夜面、大陆、云带与大气层。**

- 新增独立渲染器 `OrbitalSpaceStage`：所有几何按相机的「前/右/上」三轴摆放
  （渲染阶段 PoseStack 已减去相机坐标，写死世界坐标会丢在世界原点）；
- 深空：包围相机的暗蓝六面底 + 两块极淡星云 + 110 颗脉动星点；
- 地球：22×36 网格分色（海洋 / 大陆 / 冰盖）、晨昏线渐变、夜面城市灯光、7 条云带、
  三圈大气外晕 —— 全部程序化原创，不打包任何外部图片；
- 六套太空发射构图：
  - `轨道炮`：桁架炮台 + 三管炮身，动能弹拖着 9 节尾环沿炮管方向砸向地球；
  - `天基长矛`：轨道矛台，光矛从台体一路伸展到地球晨昏线，沿线 5 圈能量环；
  - `引力奇点`：纯黑核心 + 冷光边 + 三层倾斜吸积盘 + 26 条螺旋吸积流；
  - `等离子风暴`：五枚投放舱按 8 tick 间隔各打出一道锯齿闪电，落点分布在地球圆面上；
  - `宇宙激光`：轨道卫星（核心舱 + 桁架 + 太阳能板 + 天线碟）的束流直插地球；
  - `行星陨落`：不规则岩块拖着 11 节火环与 58 格火尾，从画面上方切入并命中地球；
- 时序：40 tick 升空 → 命中后 85 tick 轨道展示 → 20 tick 压回地面（太空底淡出）→
  24 tick 回位；开火进度在 `lock-10 → impact+2` 充能打满，与服务器命中同拍；
- 世界段接回：太空底完全淡出后才绘制真实落点的贯穿光柱 / 下钻弹体（背景盒写深度，
  会挡住身后几百格的世界几何），随后照旧由服务端结算挖穿与伤害；
- 兼容：只用 `RenderType.lines()` + `RenderType.debugQuads()`，不建自定义 RenderType、
  不做全屏 shader/FBO；关闭 `cinematic_camera` 时整套太空演出停用，退回原世界坐标表现。

### 2.4.0 — 2026-10-17

**宇宙激光搬到外太空去演：不再是「把镜头抬到 460 格看主世界的天」，而是一个独立的
轨道发射镜头 —— 深空星野、地球弧面、太阳翼张开的卫星，激光从卫星射向行星、再贯穿到地面目标。**

- 太空舞台：相机斜上方 170 格的包围式深空底（暗蓝六面 + 96 颗脉动星点），把主世界天空与
  地形挡在演出之外；行星、卫星、光束全部按相机三轴（前/右/上）摆放，构图不随落点漂移；
- 行星：程序化原创绘制（不是打包图片）—— 球面明暗填充（左上受光）+ 纬线/经线弦 + 6 块
  固定种子的绿色陆块 + 白色极冠 + 两圈大气外晕，参考 NASA 地球照片的层次，不使用外部素材；
- 卫星：本体 + 两片太阳能板（含栅线）+ 朝下的天线碟 + 闪烁导航灯；锁定阶段三圈充能环收拢；
- 发射：光束在锁定末段充能、**在服务端命中时刻打满**，从卫星炮口射向行星表面，接触点白闪
  + 双层扩散环，并在行星远侧留一段淡出的贯穿光 —— 明确「打穿了，继续往地表去」；
- 镜头时序：40 tick 升至轨道（绝对 Y ≥ 460）→ 30 tick 行星/卫星构图 → 65 tick 光束展示 →
  20 tick 压回地面（太空底淡出，真实贯穿光柱接上）→ 24 tick 回到眼位；全程不碰服务端逻辑；
- 回位天空：太空底淡出后才画真实世界的激光柱（背景盒写深度，会把身后光柱挡掉），
  因此回位段是「黑箱溶解 → 世界与光柱浮现」，不会出现光柱凭空跳出；
- 兼容：仍然只用 `RenderType.lines()` + `RenderType.debugQuads()`，不建自定义 RenderType、
  不做全屏 shader/FBO，Embeddium/Sodium 下不会重演 1.5.0 的崩溃；关闭 `cinematic_camera`
  时整套太空演出停用，退回原来的世界坐标光柱。

### 2.3.0 — 2026-10-18

**新增第六种弹种「行星陨落」：参考 NASA 行星图的打击 —— 天边浮起一颗带大陆与云层的星球，
一颗陨石从它的边缘斜切下来，拖着整条火尾砸进地面。**

- 视觉：行星是密集经纬网 + 6 块绿色大陆（纬向短弧簇）+ 白色极冠 + 两圈大气层外晕，缓慢自转；
  陨石是一个发光弹体（三圈光环 + 12 节尾环 + 46 格火线），**入射方向由落点哈希决定**，
  每次都不一样 —— 全部模式里唯一的斜向弹道；
- 机制：半径 1.6×（全场最大）、伤害 1.8×、强径向击退，立方体浅坑而不是垂直井；
- 粒子：下落段沿路径喷火焰 / 烟 / 火花，落地是一记 420 颗爆炸 + 8 圈音爆环 + 140 颗余烬 + 300 团烟；
- 镜头：锁定末 30 tick 抬头看行星，下落段跟着陨石把视线压回地面（跟拍），落地看坑。

### 2.2.3 — 2026-10-18

**轨道炮的弹体也不落地就消失了：它跟着井深一路下钻，直到虚空。**

- `renderShellFall` 落地后不再 return：每 tick 按「4000 格 ÷ (2r+1)²」换算井深，
  弹体（外壳 + 头部三圈 + 尾迹）跟着往下走，前 80% 满亮度、最后 20% 收 ——
  和宇宙激光同一套节奏；
- 客户端状态寿命对轨道炮也改成 `estimateDigTicks()`（r=24 约 290 tick ≈ 14.5 s）；
  `destroy_blocks=false` 时不延长（没有井可钻）；
- 火控 HUD 仍走 40 tick 的 `isHudActive()`，不受影响。

### 2.2.2 — 2026-10-17

**宇宙激光不再落地就收：它一路烧穿到虚空才熄灭。**

- 光柱落地后向下延伸到世界底层（`getMinBuildHeight()`）：整列挖掘一层层挖开时，
  井里的光柱也随之越来越深 —— 视觉上就是「还在往下烧」；
- 存活时长按整列挖掘估算（`(2r+1)² × 世界高度 ÷ 4000 tick/格`，r=32 约 465 tick ≈ 23 s），
  前 80% 满亮度、最后 20% 才收；
- 客户端状态与 HUD 拆成两个窗口（新增 `isHudActive()`）：光柱照旧烧到虚空，
  火控 HUD / 模式提示仍按 40 tick 收，不会被光柱拖着挂二十多秒；
- 卫星与行星全息图分别在落地 40 / 60 tick 内淡出，不在天上杵整场。

### 2.2.1 — 2026-10-17

**把「灵魂出窍」抬到卫星高度：机位不再只比地面高 92 格，而是一路升到 Y ≥ 460。**

- 宇宙激光的机位高度改为 `max(落点 + 92, 460)`，水平距离拉到 50~110 格 ——
  停在卫星旁边（Y=466），从侧面俯看光柱穿过行星落到地面；
- 上升时长从 14 tick 拉到 40 tick（400 格用 0.7 秒会像瞬移），回位 24 tick；
  落地后 14 tick 内视线抬到机位下方 30 格，把**卫星 + 行星 + 光柱**一起收进画面；
- 行星全息图半径从 130 收到 55（球心仍在落点上方 300），卫星缩到 1.8 倍 ——
  在 460 格高度看过去，卫星、行星、光柱三者的层次才分得开。

### 2.2.0 — 2026-10-17

**等离子风暴改成「分批落地」，宇宙激光改成卫星发射 + 行星全息图。**

- 风暴的五道闪电不再同一 tick 全砸：间隔 `STORM_STAGGER_TICKS = 8` 逐道落地（约 1.6 s 打完），
  每道独立挖坑 / 伤害 / 粒子，最后一道补一记低频轰鸣把整场「串」起来；
  客户端每道闪电的下落窗口、落地环与残影都按各自的落地时刻算，状态余晖也延长到覆盖全部五道。
- 宇宙激光改为**由卫星发射**：Y=460 的线框卫星（本体 + 两片太阳能板 + 天线碟 + 导航灯），
  光柱从卫星下方射出；途中穿过一张**行星全息图**（半径 130 的经纬线球，球心在落点上方 300 格、
  缓慢自转）再落到地面 —— 「从外太空穿过行星打下来」。
- 灵魂出窍机位：落地后 12 tick 内视线从弹坑抬到行星下缘，抬头看是谁在开火。

### 2.1.0 — 2026-10-17

**宇宙激光的「灵魂出窍」：镜头不再只是横着拉远，而是从玩家身体里升到 92 格高空，
俯看整根从深空打下来的光柱。**

- 宇宙激光专属机位：水平距离收近（`radius*0.55+10`，夹在 14~34 格）、高度固定 92 格，
  注视点抬到柱身中段（`radius*1.6`）—— 弹坑压在画面下缘、光柱一路向上出画，
  读作「从宇宙之外打下来」；其余四种模式仍是原来的 44 格水平拉出；
- 拉出段（锁定最后 14 tick）从玩家眼位持续冒向上飘的电青碎屑：第三人称下能看到
  「魂」正在离开身体，开火后 8 tick 收尾；
- 新增第五种弹种「宇宙激光」本体见 2.0.0 条目（光速无飞行时间、伤害 3×、贯穿到虚空）。

### 2.0.0 — 2026-10-17

**轨道打击扩成「天基武器系统」：四种可切换弹种、更长的前摇、能挖穿基岩；
前几轮未入日志的打击感与世界特效也一并收进这个版本。**

- **五种弹种**（`OrbitalStrikeMode`），**每种一套独立特效，不再共用激光柱**：
  **轨道炮**（大范围动能弹：一颗发光的弹体带尾迹砸下来，落地炸开；**贯穿型，一路打穿到虚空**）/
  **天基长矛**（半径 0.18×、上宽下尖的矛身、伤害 2.4×、前摇 1.35×，也是贯穿型）/
  **引力奇点**（下落段把周围生物往落点拽，落地向上掀飞；球体 + 三圈轨道环，向内塌缩再爆开）/
  **等离子风暴**（5 个落点各一道锯齿闪电、逐道错开落下，5 个小坑）/
  **宇宙激光**（从 Y=700 的深空发射点直射，**光速无飞行时间**、半径 1.35×、伤害 3×、
  秒杀几率 +30%，贯穿到虚空 —— 破坏性最强的那一发）。
  选择存在遥控器 NBT（`StrikeMode`），**潜行 + 右键循环切换**，服务端权威、随物品栈自动同步；
  手持遥控器时准星下方常驻显示当前弹种，潜行时提示「右键 → 下一个」。
- **前摇默认 80 → 140 tick（7 s）**，各模式再乘倍率（长矛约 9.5 s）。
  老实例的 `lock_ticks = 80` 由一次性迁移抬到 140（Forge 从不覆盖已存在的值）。
- **前摇动画**：地面收拢环从 1.8R 收到 0.95R、平台充能脉动、模式专属预兆
  （长矛三根矛线 / 奇点三圈悬空轨道环 / 风暴五个落点提前亮起）、屏幕下方充能进度条。
- **基岩**：`break_bedrock`（默认开）——基岩不再免疫；屏障 / 命令方块 / 结构方块仍然保护。
  轨道炮与长矛**强制整列挖穿到世界底层**（不受 `destroy_mode` 影响），会直接打穿 -64 的基岩层 ——
  洞口下面就是虚空；奇点 / 风暴仍按 `destroy_mode` 走。
- **世界特效（1.9.0）**：真实方块碎屑（`BlockParticleOption` 用被毁方块的真实材质）、
  几何冲击环 / 冲击壳（真正的环形四边形带）、弹坑边缘向外爬的地面裂纹、落地后 25 s 的悬浮余烬、
  逐层坍塌闷响；**修掉一个 1.6.0 以来的隐性 bug**——`RenderType.lightning()` 输出到天气帧缓冲，
  晴天根本不合成，光柱辉光一直是隐形的，现改用 `RenderType.debugQuads()`（同为 POSITION_COLOR）。
- **打击感（1.8.0）**：落地帧伪 hit-stop（白闪顶格 2 tick）、FOV 顿扩 13° 指数回弹、
  两拍静默 + 按距离延迟的雷声 + warden 低频分层、屏幕边缘泛光与火控 HUD。
- **演出机位**：落地保持段 dolly-in（44→36 格）、1.4° 荷兰角、FOV 收窄 5°、
  上下演出黑边、演出中隐藏手持物品；音量按 16×volume 的可闻半径重新标定（44 格外也听得到）。
- 配色统一回本模组自己的青白（`0x9BF7FF` / `0xEAFEFF`），不再有红雾。

### 1.7.0 — 2026-10-17

**「见证机位」：轨道打击的最后 0.7 秒锁定 + 下落 + 落地 + 1.4 秒坍塌期，镜头从玩家眼里拉出去，
远远地看着完整的一击 —— 参考 the-shooting-star 的收尾一块拼图。**

- **时间轴**（全部从客户端状态推算，不新增发包）：锁定结束前 0.7 s（正好接倒计时的「1」）
  smoothstep 拉出 → 下落/落地全程保持远机位 → 落地后 1.4 s 机位绕目标慢摇（0.25°/tick）→
  0.6 s 平滑插值回眼位与视角。首尾两端的 e=0 与原版相机完全重合，**全程没有硬切**；
- **机位**：以落点为锚、沿「落点 → 玩家」方向拉出（近侧永远是玩家这一侧），距离/高度随半径缩放
  （默认 24 → 44 格外、27 格高，49 格弹坑连同光柱同框）；注视点比落点抬 0.3×半径；
- **实现**：挂在 `ViewportEvent.ComputeCameraAngles`（与镜头震动同挂点，震动叠在演出机位上）。
  1.20.1 的 `Camera.setPosition/setRotation` 是 protected —— 反射调，**官方名/SRG 名（m_90584_ /
  m_90572_）双查**，两边都没有就安静放弃（功能退化成「不拉远」，绝不崩）；渲染矩阵读事件值、
  声音监听读相机本体，**两处都改**；
- **机身入画**：全距机位期间临时切第三人称（看见自己站在弹坑边上），拉出/回位的过渡段保持
  第一人称（眼位附近画自己会穿头）；结束原样恢复玩家自己切过的 F5 模式；退出世界每 tick 兜底还原；
- 新配置 `orbital_strike.cinematic_camera`（默认开）。

### 1.6.0 — 2026-10-17

**修复 1.5.0 进游戏必崩 + 自定义粒子「能量火花」+ 落地能量泛光。**

- **崩溃修复**：1.5.0 的信标纹理光柱（`RenderType.beaconBeam` 自建实例）在装了 Embeddium
  的客户端上必然触发 `IllegalStateException: Not filled all elements of the vertex` ——
  自建 RenderType 实例不在 `BufferSource` 的 fixed buffers 里，走 Embeddium
  `SodiumBufferBuilder` 的动态路径，其 4 元素格式（POSITION_COLOR_TEX_LIGHTMAP）的
  `uv2` 顶点链有兼容问题。**改用 `RenderType.lightning()`**（原版闪电同款：fixed buffer
  单例、POSITION_COLOR 两元素、加色发光，原版闪电每帧都在用，绝无兼容问题），
  双层圆柱（内层白热 + 外层青色辉光）保持「亮得发光」的观感。
- **自定义粒子「能量火花」**（`orbital_spark`）：注册 `SimpleParticleType` +
  `particles/orbital_spark.json`（贴图集复用原版 `minecraft:glow`，不新增美术），
  粒子类 `OrbitalSparkParticle`：白↔青随机色、全亮光照、无重力、空气摩擦减速、
  渐隐 + 收缩。三个阶段都在用：
  - **锁定**：每 2 tick 从外圈向目标点聚拢（`count=0` 才能用显式初速度做「聚」的方向感；
    `count>0` 的速度是随机方向），锁定越久聚得越急 —— 蓄能感；
  - **下落**：光柱头「犁开空气」向外下迸溅，越接近地面越猛；
  - **落地**：一圈从落点向四面八方炸开（30 + radius×2，上限 90）。
- **能量泛光**：落地后约 2 秒，全屏淡青色 + 四边更亮的青色边条（不写 shader 的 bloom
  替代），正弦「呼吸」式衰减 —— 白闪管「炸的一瞬间」，泛光管「能量还在地表翻涌」的余韵。
- 顺带记录的 Forge 1.20.1 API 坑：粒子注册是 `registerSpriteSet`（`registerSprite` 是
  单贴图版，签名不同）；`PARTICLE_SHEET_ADDITIVE` 是 1.20.4+ 才有的。

### 1.5.0 — 2026-10-17

**特效向 the-shooting-star 再逼近一步：真正的发光光柱 + 音爆冲击波 + 电弧。**

反编译研究确认了它为什么炫：`client/render/d.java` 直接用 **OpenGL（GL20/GL30/GL33）写多 pass
自定义 shader**，配 300+ 个混淆特效类。照抄不可能也没必要（All Rights Reserved），我们改用
**原版渲染管线**做出接近的观感：

- **发光光柱**：光柱从「12 条线框」升级为 `RenderType.beaconBeam`（原版信标光束同款）——
  加色混合、半透明、纹理沿高度平铺，真正「亮得发光」；线框保留做边缘。
  - 纹理用原版 `textures/entity/beacon_beam.png`，不新增资产。
- **音爆冲击波**：落地时用原版 `SONIC_BOOM` 粒子（监守者音爆的青色圆环）向四个方向成环推出 ——
  是原版最像「能量冲击波」的粒子。
- **电弧**：落地后 `ELECTRIC_SPARK` 从落点向四周乱窜（20 + radius×2 个，上限 80），
  做出「能量还在放电」的余韵。
- 其余（倒计时 HUD、红晕、白闪、镜头震动、天穹裂缝、轨道平台、整列挖穿）沿用上一版。

**为什么不能一模一样**：参考 mod 的自定义 shader 需要写 GLSL + 注册自定义 RenderType +
管理 RenderTarget，且它的着色器代码受版权保护。我们用原版 `beaconBeam` + 原版粒子组合，
观感方向一致（发光光束 / 能量环 / 电弧），实现方式完全独立。

**验证**：`gradlew compileJava` 全绿；`mods.toml` 版本 1.5.0；装机 1.5.0。
**未验证**：beaconBeam 光柱的 UV 平铺密度和亮度、SONIC_BOOM 环的视觉效果，需要进游戏看
（如果光柱纹理拉伸不对，调 `vMax = height/4` 的除数即可）。

### 1.4.0 — 2026-10-17

**参考 the-shooting-star 的设计再升级：整列挖穿模式 + 下落时长可调 + 范围上限 96。**

反编译研究（对 `the-shooting-star-demo-1.4.3` 用 vineflower 反编译出 232 个源文件）提炼出
它的三个设计要点，这轮把最有价值的一个落地：

1. **整列挖穿**（`star/a.java`：从建筑上限挖到虚空）→ 我们加 `destroy_mode = "column"`
2. **速度倍率**（`spell/a.java`：进度 tick × 倍率，支持 0.3×~3×）→ 我们加 `fall_ticks` 配置
   （6~60 tick），比它简单，效果一致
3. **多线程挖世界**（`ExecutorService` 线程池）→ **不采纳**：我们的 destroyBlock 会触发
   BreakEvent / 光照 / 邻居更新，跨线程不安全；保持单线程分 tick

- **`destroy_mode`**：`"cube"`（默认，立方体）/ `"column"`（整列挖穿）。
  - column 模式从 `getMaxBuildHeight()-1` 一路挖到 `getMinBuildHeight()`，方形列游标式推进
    （不预计算列表 —— 半径 32 约 160 万格，列表要几十 MB）。
  - 每 tick 全局预算 4000 格（原 2500），column 半径 32 约 20 秒挖完，玩家能看着整片地往下陷。
- **`fall_ticks` 配置化**（6~60，默认 24）：下落时长不再硬编码；服务端通过
  `OrbitalStrikePacket` 把真实值同步给客户端（客户端原来写死 24）。
- **`radius` 上限 64 → 96**：配合 column 模式可以挖更大的坑（但塌得更久）。
- 其他：`OrbitalStrikeClientState.FALL_TICKS` 常量改成 `fallTicks()` 实例访问器；
  `DestroyTask` 拆成 `DestroyJob` 接口 + `CubeJob` / `ColumnJob` 两个实现。

**验证**：`gradlew compileJava` 全绿；`mods.toml` 版本 1.4.0；装机 1.4.0；配置已同步写入
`config/apocalypse_zombies-common.toml` 的 `destroy_mode = "cube"` + `fall_ticks = 24`。
**未验证**：column 模式的实际观感（整列塌陷）和 20 秒挖掘时长仍需进游戏实测；
参考 mod 的「创造模式提前拉走」我们没实现（创造玩家天然免疫伤害，但方块照挖）。

### 1.3.1 — 2026-10-17

**整条打击过程现在能被玩家「看见」了：锁定 4 秒 + 下落 1.2 秒 + 坍塌数秒，不再是 1.8 秒一闪而过。**

- **锁定阶段 1.5 s → 4 s**（`lock_ticks` 默认 30 → 80，范围 20~400）：红激光、地面红环、
  天穹裂缝、倒计时 `4 → 3 → 2 → 1` 全部有足够时间看清楚。
- **下落阶段 0.3 s → 1.2 s**（`FALL_TICKS` 6 → 24）：光柱从 Y=320 慢慢压下来，
  每 20 格一个能量环一路亮下去 —— 像真的从太空里砸下来，而不是「啪」地一下到地面。
- **坍塌数秒**：大范围（radius 24 ≈ 11.7 万格）分批挖掘本身就要 2~3 秒，现在这段时间
  发生在玩家眼前的「地面一层层塌下去」是有观感的。
- **节奏/性能配套**：锁定阶段粒子改每 2 tick 一批、电弧音每 8 tick 一声；下落音每 4 tick 一声 ——
  4 秒的演出不能连成噪音，也不能刷爆粒子。

**验证**：`gradlew compileJava` 全绿；`mods.toml` 版本 1.3.1；装机 1.3.1。
**配置**：`config/apocalypse_zombies-common.toml` 的 `[orbital_strike] lock_ticks` 已同步改为 80
（Forge 不覆盖已存在的配置项，光改代码默认值不生效）。
**未验证**：4 秒锁定 + 1.2 秒下落的手感，需要进游戏试。

### 1.3.0 — 2026-10-17

**按你三条要求改：遥控无冷却、范围放大、特效向 the-shooting-star 看齐。**

- **无冷却**：`[orbital_strike] cooldown` 默认 60 → **0**（0 = 完全无冷却，可以按多快就点多快）。
  配置里设回任意秒数仍可恢复冷却。
- **范围大**：`radius` 默认 8 → **24**（49×49×49 立方体），上限 16 → **64**。
  - 注意：这个尺寸不可能在一个 tick 里挖完 —— `24` 半径约 11.7 万个方块，`64` 半径约 215 万个。
    所以破坏逻辑改成**分 tick 分批**：每 tick 最多挖 2500 个，从高到低一层层塌。
    无冷却狂点时任务会排队（全局预算不变），不会把服务器卡死。
- **光柱随半径加粗**：光柱半径 = `clamp(radius × 0.12, 0.7, 4.0)` 格 —— 半径 24 时约 2.9 格粗，
  不在是固定的细线；天穹裂缝的环也从固定 40 格改成 `max(40, radius × 2.5)`。
- **the-shooting-star 标志观感**：锁定阶段多了一条**从 Y=320 笔直射到目标的红色激光** +
  落点红色十字标记（原来只有地面红环）。抬头就能看到「有什么东西在瞄准你」。
- **粒子随半径缩放**：爆炸粒子 `64 + radius×8`（上限 360）、蘑菇云 `48 + radius×6`（上限 240）。

**为什么不是一次挖完**：这是性能红线。参考 the-shooting-star 的 200 格半径它是分批 + 整列处理，
我们这边同理 —— 分批还有个副作用是「地面从中间一圈圈塌下去」，观感比瞬移更好。

**验证**：`gradlew compileJava` 全绿；`mods.toml` 版本 1.3.0；装机 1.3.0。
**未验证**：大范围分批挖掘的手感、红激光的亮度仍需进游戏实测。

### 1.2.9 — 2026-10-17

**轨道打击遥控器挪到创造模式「战斗」页**（原来误挂在「刷怪蛋」页，和枪械分开了）。

- 纯体验修复，玩法不变：创造模式打开「战斗」页，和其它枪械同排；搜索框搜「轨道」或「orbital」
  一样能搜到。
- **注意：目前没有生存合成配方** —— 生存模式只能靠 `/give apocalypse_zombies:orbital_strike_remote`
  获得。需要合成配方的话说一声，我按「末影之眼 + 铜块 + 红石 + 下界合金」之类的口径加一张。

### 1.2.8 — 2026-10-17

**轨道打击的「屏幕级」特效层：倒计时、边缘红晕、落地全屏白闪、镜头震动、天穹裂缝。**
前几轮都是在世界里画线框/发粒子，这一轮补的是「你的屏幕」，落地那一下终于有冲击感了。

- **锁定倒计时 HUD**：屏幕中央偏上用 4 倍字号显示剩余秒数（3 → 2 → 1），颜色随倒计时
  从青 → 白 → 红渐变。
- **屏幕边缘红晕**：锁定期间上下左右四边出现红色脉冲条，越接近落地越亮（0.10 → 0.30 alpha）。
- **落地全屏白闪**：落地后 6 tick 内全屏白色覆盖，从 0.85 不透明度平滑衰减到 0；
  按距离衰减 —— 40 格内满强度、160 格外消失（远处只看到一点白光）。
- **镜头震动**：落地瞬间 6 tick 内镜头 yaw/pitch/roll 做正弦余震（最大 2.2°），
  纯随机抖动会像画面失灵，正弦衰减才像真实冲击波。
- **天穹裂缝**：Y=330 处画一圈 40 格的大环 + 24 条放射裂纹，缓慢旋转 —— 抬头就有压迫感，
  配合 Y=326 的轨道平台一起构成「太空里真的有东西在发射」。
- **音效加料**：落地加一声压低调的 `ENDER_DRAGON_GROWL`（低两个八度），垫在爆炸/远雷下面。

**新增符号**：`client/renderer/OrbitalScreenFX`（HUD 倒计时 / 边缘红晕 / 落地白闪 / 镜头震动）；
`OrbitalStrikeClientState` 新增 `isLockPhase` / `lockProgress` / `impactAge` / `distanceToPlayer`。
**接线**：`ClientEvents.onRenderGui` 里调 `renderImpactFlash` + `renderHud`；
新增 `onComputeCameraAngles`（`ViewportEvent.ComputeCameraAngles`）。

**验证**：`gradlew compileJava` 全绿；包内核到 `OrbitalScreenFX`；`mods.toml` 版本 1.2.8；装机 1.2.8。
**未验证**：白闪/震动/倒计时的观感仍需进游戏实测（尤其是白闪会不会太刺眼、震动会不会晕）。

### 1.2.7 — 2026-10-17

**轨道打击遥控器升级成「天基武器系统」：太空里现在真的有个东西在发射。**

- **轨道平台（纯客户端渲染）**：锁定第一帧起，目标点正上方 Y=326 处出现一个发光平台 ——
  3×3×3 核心方框 + 两圈缓慢旋转的倾斜环带（一顺一转）+ 一圈更淡的外环。它不是实体也不是方块，
  不会进入世界存档；玩家瞄哪，平台就悬在哪的正上方。锁定开始时同步一声 `BEACON_POWER_SELECT`
  （「平台上线」）。
- **光柱加粗**：8 边（半径 0.42）→ **12 边（半径 0.7）**；下落路径上每 20 格挂一个随高度脉动的
  能量环（靠相位差做出旋转错觉）。
- **落地蘑菇云**：56 颗向上翻腾的 `LARGE_SMOKE` + 28 颗火舌（`FLAME`），从落点向四周铺开，
  外圈更稀、中心更浓 —— 一眼看出「这里刚被一发天基炮砸过」。
- **伤害口径调强**：`damage` 默认 60 → **100**（中心 50 颗心，足以直接秒掉铁傀儡）；
  `kill_chance` 默认 35 → **40**。
- 其余（选区立方体、Y=320 光柱、地面冲击波、秒杀反馈、方块摧毁规则）沿用 1.2.5/1.2.6。

**验证**：`gradlew compileJava` 全绿（含 `Mth.sin` 参数类型两处修正）；包内核到 5 个新符号；
`mods.toml` 版本 1.2.7；装机 1.2.7。
**未验证**：平台环带、能量环、蘑菇云的观感仍需进游戏实测。

### 1.2.6 — 2026-10-17

**轨道打击遥控器的观感加强（1.2.5 的补丁，玩法不变）：让「从宇宙之外打下来」这件事更看得见，
并修掉两处代码隐患。**

- **锁定阶段**：高空（Y=320 附近）每 4 tick 稀疏撒一颗星点 —— 抬头能看到「上面有东西在瞄」，
  而不是只看到脚底下冒光。
- **下落阶段**：光柱最后一帧现在**正好压到地面**（原来是 `local / 6`，最后一帧停在地面上方约
  一格，落地瞬间会「跳一格」；改成 `(local+1) / 6`）。
- **落地瞬间**：顶部 Y=320 处向四周炸开一圈 32 颗星尘（六角散开），强调「这一击的源头在宇宙里」；
  同时加一声 `LIGHTNING_BOLT_THUNDER` 远雷（120 格内可闻）。
- **秒杀反馈**：被秒杀的目标身上爆 `EXPLOSION_EMITTER` + 8 颗 `SOUL` 粒子 ——
  「秒了」这件事现在看得见，而不是悄悄躺下。
- **代码隐患**：`onServerTick` 迭代中原来用 `ACTIVE.put(entry.getKey(), next)` 替换条目，
  改为 `entry.setValue(next)`（语义正确、不碰 map 结构）；`resolveLevel` 的注释与行为统一
  （玩家离线不影响，打击照常走完）。

**验证**：`gradlew compileJava` 全绿；包内核验同 1.2.5 的 5 个新符号 + `mods.toml` 版本 1.2.6；装机 1.2.6。
**未验证**：所有观感/音效仍需进游戏实测。

### 1.2.5 — 2026-10-17

**新增科幻武器「轨道打击遥控器」—— 手持遥控器时准星处实时画出立方体选区，右键调来一发从
Y=320 之外打下来的光柱，炸碎选区内方块、对生物造成大额伤害，并且每次命中带 35% 的必杀几率。**
参考了本机 `the-shooting-star-demo`（Stellar Remote：红激光标记 → 倒计时 → 天降光束 → 区域全杀 +
整列挖穿）的玩法骨架，但把它的 200 格半径 / 18 秒演出收成我们项目的口径：可配置半径 1~16 格、
锁定 1.5 秒、立方体选区、纯冷却。

- **怎么用**：
  - 主手拿「轨道打击遥控器」（`item/orbital_strike_remote`，创造模式「战斗」页）；
  - 准星对着地面时，选区立方体（边长 = `radius × 2`）实时画出来 —— **冷却中红色、就绪青色**；
  - 右键锁定 → `lock_ticks`（默认 30 tick = 1.5 s）锁定阶段 → 6 tick 下落 → 落地；
  - 落地：选区方块被抹掉（**不掉落物**）、中心 AOE 伤害生物、每次命中 35% 秒杀；
  - 冷却 60 s（`cooldown`）。
- **三段观感**（客户端画线 + 服务端发粒子，两边各管一半）：
  - **锁定**：地面红环脉冲 + 一道红色引线指向目标，叠加服务端 `END_ROD` 粒子；
  - **下落**：一根 8 边白/青竖线光柱从 Y=320 压下来，服务端同步 `SOUL_FIRE_FLAME` + `END_ROD` 粒子拖尾；
  - **落地**：白/青扩散冲击波 + 大爆炸粒子（`EXPLOSION` / `SOUL_FIRE_FLAME` / `FLASH`）。
- **为什么是 Y=320**：原版世界构建上限在 Y=256 左右；我们不会把玩家送到 320，那只是一个「比
  最高建筑还高」的发射高度 —— 光柱从那儿笔直落下来，在视线上就和从宇宙之外打下来一样。
  客户端渲染的高度是常量 `BEAM_TOP_Y = 320` 与服务端 `IMPACT_FALL_Y = 320` 对齐。
- **秒杀**：`kill_chance`（默认 **35%**）每次命中独立掷一次 —— 过了直接 `hurt(Float.MAX_VALUE)`，
  如果因为抗性 / 事件拦截还没死就 `setHealth(0)` + `die()` 兜底。设置 0 就是纯 AOE 伤害。
- **不炸什么**：基岩 / 屏障 / 命令方块 / 结构方块 / 带 BlockEntity 的方块（箱子、熔炉、刷怪箱、
  告示牌）/ 硬度 > `max_hardness`（默认 50，黑曜石刚好在边界外）/ 配置 `protected` 名单。
- **安全**：站在选区里自己也会被炸（伤害来源标成玩家造成的爆炸）。创造模式不特殊处理 ——
  和原版爆炸一致；参考模组那种「创造模式会被提前拉走」没有实现。
- **配置**：`[orbital_strike]` 段 10 项，全可一键关；`enabled=false` 时物品右键 noop、
  选区/光柱/圆环全部不画（客户端与服务端各自早退）。
- **美术资产**：16×16 图标在 `art/orbital_strike_remote/textures/item/`，交付台账同目录 `DELIVERY.md`。
  不走 GeckoLib 通道（没有 geo/ 和动画），`art_audit.py` 不覆盖它。
- **新符号**：`OrbitalStrikeRemoteItem` / `OrbitalStrikeManager` / `OrbitalStrikeHighlighter` /
  `OrbitalStrikePacket` / `OrbitalStrikeClientState`。

**验证**：`gradlew compileJava` 全绿；包内核到上面 5 个新符号 + `mods.toml` 版本 1.2.5；装机 1.2.5。
**未验证**：选区立方体、光柱、冲击波、秒杀判定都只过了静态编译 —— 还没在真实客户端里看过
（「右键真的调得下来」「光柱有多粗」「35% 秒杀手感」必须进游戏看）。

### 1.2.4 — 2026-10-17

**一键挖掘的产物现在一件都不落地 —— 连着你亲手砸的那一格，整簇直接进背包。**

- **症状**：挖一簇煤 / 铁矿，连带砸下来的几十格产物直接进背包，唯独**你点的那一格**还躺在地上。
  一簇挖完总有一件物品孤零零留在坑里，得再走回去捡。
- **根因**：同一条「一键挖掘」其实分两半。连带格由 `PlayerVeinMine.breakOne` 自己
  `destroyBlock(pos, false)` + 手动发产物，所以能当场塞背包；**种子格始终留给原版挖**
  （工具等级 / 耐久 / 声音 / 进度全按原版走，这个决定是对的、保留），原版于是把它的产物掉在地上 ——
  `BlockEvent.BreakEvent` 里改不了方块自己那一次掉落。
- **修法**：挖之前先登记，掉落生成的那一瞬领走。
  - `PlayerVeinMine.awaitSeedDrops`：按「维度 → 位置 → 谁挖的 + 1 tick 时间窗」记一笔；
  - `PlayerVeinMine.onItemJoin`（`EntityJoinLevelEvent`）：物品实体进场时用「**同一维度 + 同一格 +
    同一时间窗 + 主人**」四条线索认领，`event.setCanceled(true)` 后直接 `Inventory.add` ——
    这坨物品压根不会在世界里生成；
  - 同一格一次掉好几件（树叶掉俩树苗这种）也全领走：登记**不按件删**，到点自然过期；
  - 背包塞不下就 `player.drop` 掉在你脚下（不留在矿洞里）；认不到主人（离线）就让原版照常掉；
  - 别处刷出来的、相邻掉落的物品四条线索对不上，不会被误收。
- **配置还是那一个**：`[player_mine] to_inventory`（默认 **true**）。关掉时整条链一个字节都不碰 ——
  连带格与种子格全留在原地，和 1.2.3 之前的 `false` 行为一致。
- **行为不变**：不设按键、不加命令，触发仍是原版「破坏方块」；潜行只挖一格（`sneak_disables`）
  时根本不接管，那一格照原版掉。

**验证**：`gradlew compileJava` / `gradlew jar` 全绿；包内 `PlayerVeinMine.class` 核到
`onItemJoin` / `awaitSeedDrops` / `SeedDrop` 三个新符号；装机 1.2.4。

### 1.2.3 — 2026-10-17

**「产物槽空」的真凶落定：存档开着「限制合成」（`doLimitedCrafting=true`），而本模组从来没写过
配方解锁进度。本版把全部 18 条配方的解锁补上，并在玩家登录时直接写入配方书。**
（1.2.2 里那句「玩家拿错短木棍」是探针落地之前的推测 —— 本版更正它。）

**真因（这条链是在探针日志 + 存档 NBT + 服务端字节码三头钉死的）**

- 探针实测：铜斧 / 铜锄 / 铜锹三种图案摆上去，**服务端 `getRecipesFor` 每次都能命中本模组的配方、
  也能装配出 `copper_axe x1`**，可玩家合成台的产物槽就是空的、点了也取不出来 ——
  「匹配成功」与「产物槽有东西」在服务端是前后两道工序，断的是后一道；
- 后一道是 `CraftingMenu.slotChangedCraftingGrid` 里的
  `RecipeHolder.setRecipeUsed(Level, ServerPlayer, Recipe)` 闸门（字节码逐条核过）：
  配方不是 `special` 的、世界开着 `doLimitedCrafting`、且**配方不在玩家配方书里** ⇒ 返回 false ⇒
  **产物被整个丢弃**（`assemble` 的结果压根不写进产物槽）；
- 世界确实开着：`saves/1/level.dat` 的 GameRules 里有 `doLimitedCrafting = true`；
- 为什么只有本模组的东西合不了：`craftingdead` / `farmersdelight` 这些能合的模组**都带了
  「配方解锁进度」**（玩家配方书里躺着 `craftingdead:combat_knife`、`farmersdelight:cutting_board`），
  原版物品则早被原版进度解锁（连 `minecraft:copper_block` 都有 —— 见到铜锭就解锁）；而本模组的
  配方书条目数是 **0** —— `data/apocalypse_zombies/advancements/` 从来没建过。

**修法**

- `data/apocalypse_zombies/advancements/recipes/` 新增十个解锁文件（挂在 `minecraft:recipes/root` 下）：
  护甲四件「背包里有铜锭」解锁；五把工具「有铜锭 + 有棍」解锁（棍只写 `minecraft:stick` ——
  1.20.1 的进度解析碰到未注册物品 id 会**整条作废**，硬核生存的短木棍摆法由下面的登录解锁兜底）；
  火把两条一起解锁；
- 新增 `compat/RecipeUnlockCompat`（FORGE 总线）：玩家**登录时**把 `apocalypse_zombies` 命名空间下
  的全部配方一次性写进配方书（`awardRecipesByKey`）—— **既有存档立刻可合**，不必等下一次背包变动
  去触发进度判定；只碰自家命名空间；
- 删掉排查期的探针 / 启动自检临时代码，`CopperGearRecipeCompat` 回到纯去重职责。

**验证**：开发服实跑（`gradlew runServer`）—— `Loaded 1281 advancements`（原版 1271 + 本模组 10，
零解析错误）、`扫描配方 1187 条 → 本模组铜装备配方 11 条`、`Done`；新增门禁
`check_recipe_unlocks.py`（每条配方都必须被 `data/apocalypse_zombies/advancements/recipes/` 的
解锁进度覆盖 —— 就是这次踩的坑），与 `check_recipes.py` / `check_hcsurvival_conflict.py` /
`check_gun_resources.py` 四连全绿；装机 1.2.3。

### 1.2.2 — 2026-10-16

**铜装备手柄槽改成物品标签（兼容硬核生存的「短木棍」）+ 去重口径升级为「抢同一批网格」。**
（用户报「无合成物品」并附合成台截图后，一路查到真凶。）

**真凶（这一版是从截图像素 + 配方数据两头夹出来的）**

- 截图里那个"摆对图案却空产物"的合成台，第二行那根**不是原版木棍**：它比原版短粗、头上一截浅色，
  与背包里真正的原版木棍并排摆着 —— 像素比对（形状 / 亮度 / 全库贴图暴力匹配）指向
  **`hcsurvival:short_stick`（短木棍）**；REI 那格标红 = "这一格没被满足" ✓；
- 硬核生存的硬核工具链正是以短木棍为"棍"：它把**原版木/石工具配方整个换成「1 个屏障」**
  （`data/minecraft/recipes/wooden_axe.json` = 1 个 `minecraft:barrier` = 永远合不出来），
  玩家被推向它的石片 / 燧石 / 短木棍体系 —— 而短木棍配方是「1 根木棍 → 2 根短木棍」，
  在背包里和原版木棍长得几乎一模一样的**两套棍**就这么同时存在；
- 本模组（和硬核生存自己）的铜工具配方要的都是 `minecraft:stick` ⇒ 玩家拿错一根 ⇒ **图案不匹配
  ⇒ 产物格空**。这就是「所有铜制武器、工具、物品无法合成」的完整链路。

**修法**

- **canonical 十一张配方一格没动**（图案仍与原版逐格一致，手柄仍是 `minecraft:stick`）；
- 另加**五张「短木棍版」条件配方**（`copper_{axe,hoe,pickaxe,shovel,sword}_short_stick.json`）：
  图案与 canonical 逐格相同，只有手柄槽换成 `hcsurvival:short_stick`，并挂
  `"conditions": [{"type": "forge:mod_loaded", "modid": "hcsurvival"}]` ——
  Forge 在**解析之前**就按条件跳过，没装硬核生存的玩家根本不会碰到那个物品 id，
  装了的玩家则"原版木棍 / 短木棍两种摆法都能合出本模组那件"；
- 去重口径从「指纹完全相等」升级为**「抢同一批网格」**：类型 / 尺寸相同，且**逐格材料集合两两有
  交集**（空槽对空槽才算一致；shaped 连镜像摆法一起比，且镜像只作用在一侧）⇒
  硬核生存那 11 张同形配方照旧全部判为竞争者、运行期剔除；
  顺手修掉两个真 bug：`frozenset().isdisjoint(frozenset())` 为 `True` 导致「空槽对空槽」被误判成
  冲突（头盔 / 胸甲这类带空格的图案会整条漏判）、镜像两侧同时翻等于没翻 —— 两个都是门禁当场抓住的；
- **为什么不把手柄槽改成物品标签**（一开始就是这么写的，被开发服打回来）：
  1.20.1 的原版 `TagLoader` 遇到标签里引用**不存在的物品**时会把**整条标签丢掉**
  （`Couldn't load tag apocalypse_zombies:copper_handles as it is missing following references:
  hcsurvival:short_stick`），标签空掉 = 手柄槽谁也匹配不上 = **没装硬核生存的玩家丢掉全部铜工具
  配方**。条件配方没有这个问题（Forge 先判条件、后解析），所以现在这条规矩进了门禁：
  **配方里出现外家物品，就必须带条件**（`check_recipes.py` 逐张查）。

**验证**：`check_recipes.py`（图案仍与原版逐格一致 + 短木棍版条件配方 + 外家物品必带条件）、
`check_hcsurvival_conflict.py`（硬核生存 11 张仍全部判为竞争者）、`check_gun_resources.py` 全绿；
开发服实跑（`gradlew runServer`，**本机没有硬核生存 ⇒ 正好验证标签里的未知条目不会毁掉配方**：
零解析错误 + 伪造的重复配方仍被剔除）。装机 1.2.2。

### 1.2.1 — 2026-10-16

**铜装备兼容补丁：与 `[硬核生存] hcsurvival` 同形同料的九条重复配方，运行期剔掉外家那几条，
摆对图案必定出本模组的产物。**（用户报「所有铜制武器、工具、物品无法合成」并要求「写一个
兼容硬核生存的补丁」后处理。）

**病根（这次是在字节码上钉死的）**

- `hcsurvival` 用**同一套原版图案 + 同一材料 `minecraft:copper_ingot`** 注册了同名的九件铜装备
  （`hcsurvival:copper_helmet` …，斧 / 锄同样是 `_1/_2` 一对镜像摆法），与本模组那九件的
  canonical 图案**逐格等价**；
- 1.20.1 的 `RecipeManager.getRecipeFor` 是 `byType(type).values().stream().filter(matches).findFirst()`
  —— **按内部 Map 的迭代顺序取第一条命中**（HashMap 顺序，跟谁先加载无关）。两条一模一样的配方里
  **永远只有一条能被合成台用到**，另一条等于不存在：摆对图案可能拿到硬核生存那件，也可能
  什么都拿不到（配方书 / REI 里两套同名配方还并列混显）；
- 反过来说，只要**两条都活着**，"无法合成"就无解 —— 唯一稳的修法是让其中一条退场。

**修法：`compat/CopperGearRecipeCompat`（新，FORGE 总线）**

- 配方加载完成后（`AddReloadListenerEvent` 加进来的监听器排在原版 `RecipeManager` 之后，
  再由 `PreparationBarrier` 保证等地到全部 prepare 结束）把「**形状指纹与本模组铜装备配方逐格
  等价、产物却不是本模组物品**」的配方从 `RecipeManager` 里 `replaceRecipes` 剔除；
- 判定是**结构化**的：配方类型 + 宽 x 高 + 逐格材料集合（`Ingredient.getItems()` 归一成物品 id
  列表，所以 `item` 与等价的 `tag` 写法同指纹；空槽记 `-`）。
  **shaped 按左右镜像归一** —— `ShapedRecipe.matches` 对同一个图案会同时试正摆与镜像摆，
  图案 P 与镜像(P) 的两条配方接受的是同一批网格，互为竞争者（铜斧 / 铜锄的镜像变体正是为这件事
  而存在），取两者里字典序小的那个当指纹，镜像对才会撞成同一个指纹；
- **不写死 hcsurvival 的配方 id**：只对本模组那九件的指纹建表，主命名空间不是本模组、又撞进这张表的
  才剔 —— 换个同形冲突的模组照样拦得住，硬核生存的其余内容（晾肉架 / 绷带 / 粗制火把…）一张不碰；
- 本模组配方一条都没上桌（被数据包顶掉之类）时**直接不动手**；任何异常只记一行 `warn`，
  配方表保持原样 —— 这是世界加载的地基，不该被兼容代码搞崩；
- 开关：新配置 **`compat.copper_recipe_dedup`（默认 true）**，关掉完全回到原样（两套同名配方并列，
  谁被命中看运气）。配置总数 170 → **171**。

**门禁 `tools/check_hcsurvival_conflict.py`（新）**

把 Java 那边的指纹规则**离线复刻**成 Python，拿真 jar（`[硬核生存] hcsurvival-0.19.2.jar`，找不到
时退回内置表）逐条比对，四条断言：

1. 本模组 11 张铜装备配方（9 件 + 斧/锄镜像）→ 9 个不同指纹；
2. hcsurvival 的 11 张铜装备配方**每一条**都撞进本模组指纹（= 运行期会被剔除）；
3. 剔除后 9 个指纹上只剩本模组产物（没有残留竞争者）；
4. 规则**有边界**：抽样的非铜装备配方（晾肉架 / 绷带 / 粗制火把 / 雪取水）一张都不在指纹集合里。

验证：`check_hcsurvival_conflict.py` 全绿（真 jar 对照）、`check_recipes.py` 9/9 全绿、
`check_gun_resources.py` 全绿；**开发服端到端实跑**（`gradlew runServer` + 一张伪造的同形重复配方
数据包 `verifydup:copper_helmet` —— 图案与本模组铜头盔逐格相同、产物故意换成木棍）：日志里
`[铜装备兼容] 扫描配方 1188 条 → 本模组铜装备指纹 9 个` 与
`[铜装备兼容] 剔除 1 条与本模组铜装备同形的重复配方（摆对图案必定出本模组的产物）：[verifydup:copper_helmet]`
两条都出现 —— 剔除路径真的生效（同一套判定对硬核生存那 11 条同样成立）。
装机 1.2.1。

> ⚠ 记录一笔踩坑：开发服日志是 **GBK** 编码，拿 UTF-8 的 `grep` 搜中文会**静默搜不到**
> （ASCII 的 `Done (`/`Loaded N recipes` 又能搜到，看起来像「代码没跑」）。搜中文请用
> `grep -a` 配 GBK，或直接用 Python 按 gbk 解码。
- 版本号 1.2.0 → 1.2.1（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.2.0 — 2026-10-16

**铜套装收尾：铜斧 / 铜锄补镜像变体（左右两种摆法都能合）+ 铜锹补齐进本模组 + 配方门禁。**

（用户报「合成表都有，就是空的合成物」、并要求「把铜锹补进我们的模组」后一起处理的三件事。）

**一、查清"铜"装备在包里有双份**

- **本模组配方数据全部有效**：9 张 canonical 图案 == 原版、模型贴图齐全、游戏日志零配方加载错误、
  离线复刻 1.20.1 匹配规则逐格验证全过 —— 摆对一定能出；
- `[硬核生存] hcsurvival` 自带 `hcsurvival:copper_*`（9 件、含铜锹，斧/锄还带镜像双配方
  `_1/_2`）。REI / 配方书按"铜"搜索会把两套同名物品混显 —— **悬停看提示末行可区分**
  （`Hardcore Survival` / `Apocalypse Zombies`）。

**二、铜斧 / 铜锄补镜像变体**

1.1.103~108 期间铜斧图案是错的（'SX'、锄也被镜像），玩家照着摆了数周；1.1.109 修回原版图案后，
老习惯的镜像摆法会合不出东西。现各加一张**镜像变体**（`copper_axe_mirror` / `copper_hoe_mirror`，
与 hcsurvival 的 `_1/_2` 同思路）：左右两种摆法都合出同一件物品。

**三、铜锹补进本模组**

原先玩家在配方书里看到的"铜锹"只存在于 hcsurvival（`hcsurvival:copper_shovel`）；本家补齐：

- `ModItems.COPPER_SHOVEL` = `new ShovelItem(ModTiers.COPPER, 1.5F, -3.0F)`（与石锹同手感参数，
  耐久/效率/挖掘等级随 `ModTiers.COPPER` 走），归工具页；
- `models/item/copper_shovel.json` + `textures/item/copper_shovel.png`：贴图由原版 `iron_shovel.png`
  逐像素套用本套装已有的"铁→铜"色板重染（从 copper_axe 与 iron_axe 提炼的 10 色映射，零冲突）；
- 配方 `['X','S','S']`（== 原版 iron_shovel）+ 双语"铜锹 / Copper Shovel"。

**门禁同步**：`check_recipes.py`（canonical == 原版；`_mirror` 变体必须精确镜像；对照表含铜锹，
现 9 张）；`check_gun_resources.py` 的原版物品类白名单加 `ShovelItem`（否则误报"找不到模型绑定"）。

验证：`check_recipes.py` 9/9 全绿、`check_gun_resources.py` 全绿（9 枪 + 17 个其他物品 + 27 音效）、
包内资产核对无误；装机 1.2.0。
- 版本号 1.1.109 → 1.2.0（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.109 — 2026-10-16

**修铜斧 / 铜锄配方图案（用户报「配方表错误」）—— 并给配方加门禁。**

用户在配方书里看到铜斧表：第 2 行是「木棍 / 铜锭」，与原版斧（锭 / 棍）相反。查 git 历史找到
病根：**1.1.103 那次"修图案"自己修坏了** —— 把铜斧从三列压窄成两列（对）时，顺手把第 2 行的
锭 / 棍写反（`XS` → `SX`），又把本来正确的铜锄镜像了（` S` → `S `）。

- `copper_axe`：`['XX','SX',' S']` → `['XX','XS',' S']`（对齐原版 iron_axe）；
- `copper_hoe`：`['XX','S ','S ']` → `['XX',' S',' S']`（对齐原版 iron_hoe）；
- 新增门禁 `tools/check_recipes.py`：把 8 张铜装备配方与**从游戏 jar 里读出的**原版
  `data/minecraft/recipes/iron_*.json` 逐格对齐（键名归一为「材料 / 木棍 / 空」，产出物品也核），
  任一张形状不一致即红；游戏 jar 不在时退回内置对照表（2026-10-16 从 1.20.1 原版读出）。
  出货脚本把它列入判据。

验证：门禁在修复前**精确报出这两张**（其余 6 张全绿），修复后 8/8 全绿；
`check_gun_resources.py` 全绿；装机 1.1.109。
- 版本号 1.1.108 → 1.1.109（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.108 — 2026-10-16

**win94 装弹改由右手逐发推入（用户标注：子弹沿箭头方向从右侧装填门压入 ✓ 方向已对，右手要真正参与装弹）。**

此前两段换弹里子弹是"自己滑进机匣"的：右手全程握在握把上（reload_tactical），或只在收尾杠杆段
才出现（reload_empty）—— 真枪装弹是靠手压的。本轮把右手做成**装弹手**：

- `GunFrame` 新增 round 链捕捉（与 bolt/lever 同一套"手跟活骨骼"机制）：`round()` / `roundGrip()` /
  `roundAtGate()`（按 cartridge 骨的 +Z 停位区分「在门口」（FEED_Z，正值）与「在膛里」（CHAMBER_Z，负值），
  只认正值 ⇒ 收尾上膛时手不会追着子弹钻进枪管）；
- `Win94ItemRenderer` 把 `cartridge` 骨交给 `Win94GeoModel.capture()`；
- `Win94GeoModel.rightHand()`：装弹窗口内右手离握把、**跟着子弹骨**逐发把子弹推到位 —— 握点取弹壳中段、
  向门外与上方各偏一点（黄铜在拳边可见），两发之间退到门外"等下一发"位（= 出膛位姿态 + 同一偏移）；
  窗口 tick 8–42（战术 44t）/ 10–66（空仓 88t），与音效表的压弹拍点（11.2–17.2 / 22–28 / 32.8–38.8；
  13–19 … 57–63）一致；收尾杠杆段与 bolt 循环里杠杆优先，手回到环上；过渡用 `HandMotion.ease` 平滑，
  子弹的 step 瞬移不会让手跟着瞬移（表现为"把下一发从门外带进来"）。

验证：`compileJava` 通过；节奏与音效表/关键帧拍点对齐；杠杆优先级与既有 bolt/inspect 行为一致；装机 1.1.108。
- 版本号 1.1.107 → 1.1.108（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.107 — 2026-10-16

**修 1.1.106 旋转换算的方向错误：win94 杠杆实机向上翻（用户报「应该向下拉」）。**

1.1.106 把 win94 的动画翻译到落盘文件时，位置通道翻对了（装弹方向因此修好），但**旋转通道的
换算方向写反了** —— 当时按"精确镜像"推导（rx 不变、否 rz），实际是 **GeckoLib 加载预烹饪的逆**
（从仓库 `art/bride/gl/` 里的 GeckoLib 4.8.4 源码逐处读出）：

| 环节 | 源码 | 换算 |
|---|---|---|
| 几何：pivot / cube / 骨骼·方块旋转 | `BakedModelFactory.constructBone/constructCube` | pivot x→−x；cube origin x→−(x+w)；旋转 (rx,ry,rz)→(−rx,−ry,rz) |
| 动画：位置 | `RenderUtils.translateMatrixToBone` | posX→−posX（y/z 原样） |
| 动画：旋转 | `BakedAnimationsAdapter.buildKeyframeStack(isForRotation=true)` | (rx,ry,rz)→(−rx,−ry,rz) |

⇒ 落盘文件必须写：**位置 x 取反；旋转否定 rx/ry、保留 rz**（这正是莫辛/AWM 等已出货枪的文件
规则：莫辛 casing 的 bbmodel (60,−160,−40)/+0.5 → 落盘 (−60,+160,−40)/−0.5）。1.1.105/106 的
lever +62° 原样落盘 ⇒ 加载时被烹成 −62° ⇒ 杠杆向上翻；hammer/trigger 的 rx 同病。

**修复**：`export.py` 换算函数改为 `cook_for_export()`（规则改正 + 三处 GeckoLib 源码注释）、
校验 `check_cooked()`、落盘 `win94.animation.json` 重新生成（与 1.1.106 版 diff：**34 处键全部是
rx/rz 符号变化，位置通道 0 处变化**）、`gate.py` 的机构符号判据改成落盘空间符号
（lever 负 / 击锤负 / 扳机正）、`anim.py` 与 `art/win94/README.md` 的规则说明重写。

**验证**：`gate.py` 十项全绿 · `check_gun_resources.py` 全绿 · `check_cooked()` 逐键 0 失败 ·
tick 契约与各通道时间点不变。修正后：lever 落盘 −62°（渲染 +62° = 环向前下方摆）、
hammer −32°（待击向后）、trigger +16°（下端向后）—— 与 1.1.104 的机构相位表完全一致。
- 版本号 1.1.106 → 1.1.107（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.106 — 2026-10-16

**实机试玩三处修正：win94 手上显小、右键瞄准应隐藏手和枪、装弹方向反了。**

三处都是用户实机反馈（截图标注），逐条定位根因后修复：

1. **手上显小**。1.1.104 把模型按真枪尺寸重建后总长 17.83 u，而其它长枪的模型都画大了
   15–20%（莫辛 22.90 u 对真枪 1232 mm 超 16%），第一人称缩放却共用 1.25 —— 屏幕上只有
   17.4 u，比 UZI（18.1 u）还短，视觉上像个小玩具。`Win94Item.FIRST_PERSON_SCALE`
   1.25 → **1.50**（屏幕 20.9 u，仍略小于莫辛，保住卡宾枪的体量感）。
   `firstPersonScale` 在握姿链的**上游**生效，ADS 补偿量随它一起放大，准星线仍在屏幕中心
   （`GunItem#firstPersonScale()` 的设计就是为此）。

2. **右键瞄准没有隐藏手和枪**。用户最初的要求就是"右键瞄准显示透明十字准星放大 2.5 倍，
   **看不见手臂和武器**"；1.1.104 接入时把"看不见"误判为 bug（未注册导致）而写成
   `hidesModelWhileAimed() = false`。恢复为 **true**：抬枪过 `SCOPE_HIDE_MODEL_AT` 后第一人称
   模型整体不画，只留 CLEAR_SIGHT 的镜片、圈与十字准星（与 AWM 黑镜同一条框架路径，
   `ClientEvents.onRenderHand`）。

3. **装弹方向反了（根因最隐蔽）**。bbmodel 是**作者空间**（+X = 射手右侧，装填门、抛壳口
   都建在 +X），而 **bedrock 导出把 X 取反** —— 落盘 geo 里所有不对称件都在 −X 侧
   （全项目一致：莫辛/AWM 的枪机柄与抛壳件同理；wiki 07「导出空间 −X = 射手右侧」）。
   1.1.104/105 的 `export.py` 转换动画时**漏了这次镜像**：几何在导出空间、动画还在作者空间，
   子弹从"没有装填门的那一侧"压进机匣、空壳飞向另一侧 —— 实机看到的正是「装弹方向反了」。
   - `tools/win94/export.py` 新增换算层（位置 x 取反 ✓；旋转按当时推的"精确镜像"处理
     —— ⚠ **旋转这条规则写错了方向**，1.1.107 更正为"否定 rx/ry、保留 rz"，见下）
     + `check_mirrored()` 逐键校验"落盘值 == 换算(bbmodel 值)"，漏翻 / 重复翻当场报错；
   - 落盘 `win94.animation.json` 重生成：**78 个键**按换算翻转（cartridge / spent_shell / gate
     的 x、body / gate / spent_shell 的旋转）—— 位置方向因此修好；旋转部分当时以为"X 轴机构
     不受影响"，实际方向写反，杠杆在实机向上翻 —— ⚠ 1.1.107 修正；
   - `tools/win94/gate.py`：装填门开度判据放宽为 `|x|`（门在导出空间反向弹开同样是"被顶开"），
     新增检查项 10「落盘动画与导出几何同坐标系」：geo 装填门在 −X、换弹子弹 x ∈ [−0.86, 0]、
     空壳末帧 x −2.10 向右上方抛出；
   - `tools/win94/anim.py` / `art/win94/README.md` / `art/win94/DELIVERY.md` 写明两套空间的分工
     （作者空间写 bbmodel、export.py 负责镜像，**不许手翻**）。

**验证**：`gate.py` 与 `check_gun_resources.py` 全绿（9 把枪 + 16 物品 + 27 音效 + 14 个动画文件
1977 条通道符合 GeckoLib 契约）；`check_mirrored()` 逐键核对 0 失败；重生成前后 diff 确认
tick 契约（40/16/12/22/44/88/52）与各通道关键帧时间点逐条不变。
- 版本号 1.1.105 → 1.1.106（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.105 — 2026-10-16

**修 1.1.104 引入的启动崩溃：`win94.animation.json` 被 GeckoLib 拒绝，客户端在资源加载阶段直接崩溃。**

实机连崩三次（`logs/2026-10-16-*.log.gz`），报错逐字相同：

```
Caused by: software.bernie.geckolib.GeckoLibException:
    apocalypse_zombies:animations/win94.animation.json: Error loading animation file
Caused by: com.google.gson.JsonParseException: Invalid keyframe data - multiple starting keyframes?0
```

**根因**：GeckoLib 4.8.4 的 `BakedAnimationsAdapter.getKeyframes` 有一条硬约束 ——
逐键遍历通道时，**时间戳为 0 的关键帧必须是该通道在 JSON 里的第一个键**，
否则抛 `multiple starting keyframes` 并令整个 `animation.json` 解析失败
（反编译 `geckolib-forge-1.20.1-4.8.4.jar` 逐条字节码核对过判定条件与消息拼接）。
1.1.104 的 `anim.py` 把 `gate.position` 的 0 秒帧**追加在逐发压弹循环之后**，
于是它落在 JSON 中段：`reload_tactical` 的 0 帧排在 1.94 之后、`reload_empty` 的排在 3.15 之后 → 整包被拒。

**修复（四层，改完互相对得上）**：

- 资产：`win94.animation.json` 与 `win94.bbmodel` 的 `gate.position` 零帧移到首位（通道按时间升序）；
  顺带删掉 `reload_empty` 里两枚 0 值冗余帧（3.0 / 3.30，前后帧都已是 0，语义不变）。
- 源头 `tools/win94/anim.py`：零帧改到压弹循环之前声明；写 Blockbench 前一律
  `geckolib_sort()`（每个通道内按时间升序稳定重排）；自检复刻 GeckoLib 规则（零帧在首位、无多个零帧）。
- 防线 `tools/win94/export.py`：导出时逐通道按时间升序写键，并加 `check_geckolib()`，
  违规拒绝写出（而不是把一个会崩的包交给构建）。
- 门禁 `tools/win94/gate.py`：新增「GeckoLib 关键帧契约」检查项，7 条 clip 全绿。

**验证**：用 GeckoLib 4.8.4 原始字节码反射调用 `getKeyframes`，扫全部 **15 个动画文件 / 2088 个通道
→ 0 失败**；对 1.1.104 的坏文件会逐字复现上面两条报错（对照验证，证明校验器抓的就是这个崩溃）。
`export.py` 从 bbmodel 重新生成的动画与已发货资源**逐键逐值零差异**。
- 版本号 1.1.104 → 1.1.105（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.104 — 2026-10-16

**win94（M1894 杠杆步枪）按真枪重做模型 + 按真实机构重排动画；生成器脚本清空重写。**

上一版 `win94.bbmodel` 有三个结构性毛病：outliner 里同一批方块在 `root` 下**又挂了一份孤儿副本**
（动画只驱动骨骼、那份不动 → 一播动画枪体就裂开）；机匣下方的环**只做了一个**（把真枪的扳机护圈
和杠杆环当成了同一个正圆环）；装填门装在机匣**尾端**。本轮把旧脚本全部清出
（13 个补丁脚本 → `tools/_legacy_win94/`），重写为一套 `tools/win94/` 生成器并整体重建。

**几何：三处按真枪量测的实质修正**（用户给的 3D 参考图 + 一张真枪棚拍侧视图交叉量取，
标尺：机匣 180 px ↔ 3.02 u）：

| 项 | 旧版 | 新版 | 真枪依据 |
|---|---|---|---|
| 环 | **一个**（当成"环兼护圈"） | **两个**：`guard_loop` 16 段（外径 63×38 mm，**固定不动**、包住扳机）+ `lever_loop` 20 段（外径 110×46 mm，随杠杆摆） | 真枪护圈 2.3×1.3 in、杠杆环 4.2×1.6 in，关闭时侧面成"8"字 |
| 装填门 | z +0.02…+0.34（机匣**尾端**） | z −1.63…−0.88（机匣**中后部**），嵌在右壁凹槽里 | 照片 x 482…527 px（机匣长度 43–68% 处） |
| 倍镜 | 镜管中心 y 0.64（bore +40 mm），净空 13 mm | 镜管中心 y 0.80（bore **+50 mm**），镜管底与机匣顶留 **27 mm** 抛壳净空 | M1894 顶部抛壳，真枪顶装架 38–50 mm |
| 闭锁块行程 | 0.62 u = 38 mm | **0.98 u = 61 mm** | 抽壳行程必须 ≥ 弹壳长（.30-30 壳 2.04 in ≈ 52 mm） |
| 杠杆全开角 | 72° | **62°** | 真枪 60–70°；由连接点弧长与闭锁块行程反推 |
| 方块 / 骨骼 | 178 / 14 | **249 / 16**（新增 `gate`、`carrier`；`trigger_guard` 并入机匣） | — |

**杠杆那一处按真枪重做**（用户连着两轮标注"这个位置还需要优化"）：lever 是**一根直钢条**，
从机匣前下方的转轴 (y −0.95, z −2.30) 一路斜到握把下方，**从扳机护圈下方穿过**，终点
**正好落在杠杆环的前端点**上 —— 旧版杆做成"前段水平后段陡降"，正好从护圈孔里穿过去（侧面看像
往机匣底下插了根棍），而杆的终点又停在环前上方、离环 0.263 u ≈ **16 mm**，一眼就是两件东西。
另外护圈不再悬空：加了 `guard_strap`（护圈上缘到机匣底的连续金属带）与 `lower_tang`
（机匣底延伸到枪托腕部的下尾板），护圈成为机匣的一部分。

**动画按真实机构相位重排**（`bolt` 一条里就是完整的杠杆循环）：

```
0.05–0.40s lever 下扳到底（0.40 时闭锁块全退 0.98 u）
0.06–0.34s 击锤被闭锁块尾压下 → 待击（M1894 是 cock-on-opening）
0.35s      空壳撞 ejector，向右上翻滚飞出
0.30–0.46s carrier 才下摆接弹 ← 闭锁块后退的**后半段**
0.68s      carrier 抬到膛口高度（在闭锁块复进之前）
0.74–0.94s 闭锁块面推弹入膛 → 0.95s lever 归位闭锁
```

- 用户明确指出过的那条：**carrier 是"先下后上"**，一开栓就抬起等于把还没出弹仓的子弹抬到膛口。
  现在 `tools/win94/gate.py` 会卡"最低位时刻必须落在闭锁块全退行程的后半段、且早于最高位时刻"。
- 换弹仍是**机匣右侧装填门逐发压入**（管状弹仓，没有弹匣）：`reload_tactical` 3 发、
  `reload_empty` **5 发 + 再扳一次杠杆上膛**，节奏与 `Win94Item` 的两张音效表 tick 锚点对齐。
- 装填门单列 `gate` 骨骼：压弹时被子弹顶开、进仓后回位。

**工程侧**：

- 生成器重写为 `tools/win94/`：`spec.py`（唯一数字来源）→ `model.py`（几何 + UV 货架 + 共面自愈）
  → `build.py`（经 MCP 建进 Blockbench）→ `tex.py`（512² 逐面贴图）→ `anim.py`（7 条 clip）
  → `export.py`（geo/animation）→ `gate.py`（门禁）→ `all.py`（一键）；
  木纹/钢纹改成按**模型坐标**绘制，枪托 24 段拼起来不再有"栅栏"竖纹。
- **门禁 `tools/win94/gate.py`**：两个环闭合度、护圈包住扳机、环在转轴后方（正角度）、
  杆从护圈下方过、护圈挂在机匣上、装填门位置、镜高与抛壳净空、7 条 clip 的 tick 与 Java 常量一致、
  carrier 先下后上、5 发压弹 —— 实跑全绿（`check_model` 报 0 issue，`check_gun_resources.py` 全绿）。
- Java 侧同步：`Win94GeoModel` 的手部目标随新几何更新（`GRIP` y −0.85、`LEVER_KNOB` (0, −2.17, 0.92)、
  `LEVER_TURN_MAX` 85→62），类注释里的模型尺寸改成 17.83 u / 16 骨骼。
- 已知模型缺陷与限制列在 `art/win94/README.md`「已知缺陷」一节；本轮改动全过程见 `art/win94/DELIVERY.md`。

- 版本号 1.1.103 → 1.1.104（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.103 — 2026-10-15

**修铜工具合成配方图案 + 火把保底配方。**

铜质八件（剑 / 镐 / 锄 / 斧 / 头盔 / 胸甲 / 护腿 / 靴）的合成表在 1.1.92–1.1.94 入库时就有，但**斧和镐的图案写错了**：

| 物品 | 原图案（错） | 修正后（对齐原版工具布局） |
|---|---|---|
| `copper_axe` | `XXX` / `XSX` / ` S `（三行三列、铜锭围住木棍） | `XX` / `SX` / ` S`（右上两铜、中左木棍、下中木棍） |
| `copper_hoe` | `XX` / ` S` / ` S`（木棍在**右**列） | `XX` / `S ` / `S `（木棍在**左**列） |

原版 shaped 配方按图案逐格匹配、不对称，所以玩家按铁斧/铁镐的摆法放铜锭时合不出铜斧/铜镐 —— 表面上看就是「铜工具没配方」。其余六件（剑、镐、四件甲）图案本来就对，只改这两件。

**火把保底配方**：整合包里有别的模组会动火把的配方（实测现象是 `木棍 + 煤炭` 不出火把）。本模组不覆盖原版 `minecraft:torch`，改在自己的命名空间下各加一条**保底**：

- `apocalypse_zombies:torch`：煤炭 + 木棍 → 4 火把
- `apocalypse_zombies:torch_from_charcoal`：木炭 + 木棍 → 4 火把

两条都是 shaped、与原版同图案，放在 `apocalypse_zombies` 命名空间避免与原版或别的模组撞 id。原版配方若还在就是多一条重复路径；若被别的模组删掉，这两条顶上，火把始终能合。

- 版本号 1.1.102 → 1.1.103（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.102 — 2026-10-15

**修了猫耳娘穿铜甲一进渲染就崩的问题。**

实机崩溃报告（`1.20.1-Forge_47.4.27` 实例 `crash-reports/` 下 15:10:59 与 15:12:21 两份，同源）里的链条干净：

```
ResourceLocationException: Non [a-z0-9_.-] character in namespace of location:
textures/models/armor/apocalypse_zombies:copper_layer_2.png
    at CatGirlArmorLayer.render(CatGirlArmorLayer.java:101)
```

| 项 | 内容 |
|---|---|
| 根因 | `CatGirlArmorLayer` 自己拼原版盔甲贴图路径：`new ResourceLocation("textures/models/armor/" + armor.getMaterial().getName() + …)`。原版材质的 `getName()` 是裸名（`iron`），拼出来合法；而模组材质（铜甲 `ModArmorMaterials.COPPER`）的 `getName()` 带命名空间 `apocalypse_zombies:copper`（Forge 标准写法），整条串进 `ResourceLocation` 后前缀被当成命名空间校验，含 `/` 非法 → 抛异常。玩家自己穿铜甲不崩，是因为原版 `HumanoidArmorLayer` 会先按 `:` 拆出域再拼路径 |
| 修法 | 按原版同一套拼法：先把材质名按 `:` 拆成域 + 路径，再拼 `域:textures/models/armor/<材质>_layer_<n>.png`，并过一遍 `ForgeHooksClient.getArmorTexture`（兼容覆写了自定义贴图的物品） |
| 顺手修 | 层号对齐原版约定 —— 护腿用 `layer_2`、其余部位用 `layer_1`；原实现写成 `leggings ? 1 : 2`，不崩，但铜甲贴图会张冠李戴 |

- 版本号 1.1.101 → 1.1.102（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.101 — 2026-10-15

**把 1.1.100 的文档与代码对齐，并加上一键出货推送工具。**

- `readme.md` 里 1.1.100 写着「留了一个 K 键可以现场四档切换」，但仓库里从来没有这个键
  （`KeyBindings.java` 只有 R / G 两个）。那次四档比对是 2026-10-13 **在游戏里做的一次性验证**，
  比对用的临时代码没进仓库。定案结论 `XP(+90) + YP(180)` 一直在 `CatGirlGeoRenderer` 里，
  与玩家手持一致（本次实机复核确认）。删掉那句 K 键描述，其余 1.1.100 的推导、表格与结论与代码对过，保持一致。
- `tools/github_push.py` 随本次改动一起入库：本机到 github.com:443 时通时不通（DNS 给的 IP 经常握手超时），
  它把一批候选 IP 逐个做「TCP 443 + **带证书校验的** TLS 握手」，挑最快的写进 hosts 里我们自己的标记段
  （`--restore-hosts` 随时撤掉），然后 `git add/commit/push`。**不带参数就是全流程**：扫描 → 写 hosts → 提交 → 推送。
  用法见文件头。本次实测又踩到三个坑，都已写进脚本：HTTP/2 推大包会被中间设备掐断
  （`Recv failure: Connection was reset`，改成固定走 HTTP/1.1）；远端 `main` 停在 1.1.98、本地已到 1.1.101，
  直接推会被 `! [rejected]` 顶回来 —— 先 `git pull --rebase origin main` 接上远端历史（本次就是这么接的）；
  推送阶段按扫描排名**逐条换 IP 试推**，每条先用 `git ls-remote` 验通道
  （TLS 握手最快那条未必扛得住 git 会话：实测 925 ms 的那条 git 21 秒连不上）——本次就是第一条失败、第二条推成的。
- 版本号 1.1.100 → 1.1.101（`gradle.properties` / 根 `mod.toml` / `readme.md` 头表 + 更新日志，四处同改）。

### 1.1.100 — 2026-10-14

**她手里拿的东西不再上下颠倒了**。

玩家手里物品的最终朝向，链子是 `translateToHand(arm)` → `mulPose(XP, -90°)` → `mulPose(YP, 180°)`
→ `translate(+1/16, 0.125, -0.625)`，再往外还有 `setupRotations` → `scale(-1,-1,1)` → `translate(0,-1.501,0)`；
这些**全部从官方映射 jar 的字节码里读出来的**，不是照抄注释。她的链是 GeckoLib 的
`applyRotations(180 - bodyRot)` → 骨骼树，**没有**那次 `scale(-1,-1,1)`。

把两条链逐项展开、并把她 geo 里的真实 pivot 代进去，唯一解是 `F·XP(-90)·YP(180) ≡ XP(-90)`
（记 `F = scale(-1,-1,1)`，恒等式验过三遍：矩阵乘开一次、三根基向量各一次）——
**可实机那样摆是上下颠倒的**：说明两条链之间还差一个没被建模的绕 X 的 180°。

| 环节 | 核对结果（均来自反编译，不是推测） |
|---|---|
| 原版玩家的两步基准旋转 | `XP(-90)` → `YP(180)`，与代码注释一致 |
| 原版实体的外层 | `setupRotations` → `scale(-1,-1,1)` → `translate(0,-1.501,0)` |
| GeckoLib 的实体朝向 | `applyRotations` 用 `180 - bodyRot`，与原版同一套约定 |
| GeckoLib 的物品层 | 骨骼帧只施加一次平移（`prepMatrixForBone` 的净位移为 0），没有额外翻转 |
| 她的 geo | `right_arm` 在 +X、`item_righthand` 挂在 `right_hand` 下、静止无旋转 |

**定案过程与结论**：纸面推导给出 `F·XP(-90)·YP(180) ≡ XP(-90)`，可实机那样摆是上下颠倒的。
在游戏里逐档比对（四档实时切换）后，与玩家手里一致的答案是 **`XP(+90) + YP(180)`**，
而它恰好等于：

```
XP(+90)·YP(180)  ≡  Ry(180) · XP(-90)
```

也就是说：她的空间相对「原版模型空间 + `F`」**还差一个绕 Y 的 180°**（等价于她的 geo 与代入的那套
差一个 `Rx(180)` —— X 同号、Y 与 Z 都反）。这层差异纸面上抓不到：GeckoLib 在层里又施加了一次骨骼变换
（`prepMatrixForBone` 之后还有 `translateAndRotateMatrixForBone`），加上它不做原版那次翻转，
两件事叠加起来的净效果与朴素推导并不等价。

**教训（1.1.90 就是这么改错的）**：`YP(180)` 这一下是**实测需要**的，别因为「矩阵恒等式能把它化掉」就删掉 ——
那个恒等式描述的是原版模型空间，而她不在那个空间里。要再动这两行，先把四档比对重做一遍。

### 1.1.99 — 2026-10-13

**猫耳娘不再「想不明白」了：思考型模型会把整轮额度都拿去想，答案一个字都写不出来 —— 现在先把她的答案头一个字写好。**

实机（端点 = llama.cpp，模型 = `DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M`）上四个现象逐条查清：

| 屏幕上看到的 | 真正发生了什么 |
|---|---|
| `……我又想不明白了（没有 JSON）。` | 这个模型是 **DeepSeek-R1 蒸馏**：思考开关写在它自己的模板里，请求里那个 `enable_thinking=false` 它当没听见。`max_tokens=300` 被思考吃满（回包 `finish_reason=length`），**`content` 是空串**、正文全在 `reasoning_content`；旧版把 `reasoning_content` 当正文 → 思考里没有花括号 → 「没有 JSON」 |
| `列表为空，无法执行任何任务。` | 候选表（`CatGirlRecipeTable`）是懒加载的，而**只有 `/apocalypse catgirl recipes` 那条命令会喂它** —— 一进游戏就跟她说话时表是空的，候选恒空，她只能说这句 |
| `只能执行一次任务，制作石头。` | 候选为空 + 小模型自由发挥的产物，前两条修好即消失 |

**三处修改（都在 `ai/` 里）**：

1. **先替她把答案的第一个字符写好**（新配置 `ai.prefill_json`，默认 true）：在 messages 末尾追加一条
   内容就是一个 `{` 的 assistant 消息，服务端把它当「已经开好的头」接着往下写，模型没有"先想一段"的机会。
   同一句话实测：**299 token / 13.9 秒 / 空答案 → 36 token / 1.6 秒 / 合法 JSON**，思考一个字都不吐。
   个别服务端不收这种「以 assistant 收尾」的请求（HTTP 4xx）—— 那种情况模组**自动去掉这一条重来一轮**，不必手动关。
2. **解析层只认真答案**：`content` 是答案、`reasoning_content` 是思考。思考里恰好草拟过一整段合法 JSON
   时仍可拿来救命，但**思考本身绝不当回话端给玩家**。挖不出 JSON 时的理由也改成能动手的：
   「她的思考把 max_tokens 用光了，答案还没开始写就被截断 —— 把 `ai.max_tokens` 调大，或换一个不吐思考的模型」。
   取 JSON 的方式也从「第一个 `{` 到最后那个 `}`」改成**括号配平扫描**（思考残渣里的花括号会被跳过）。
3. **候选表在对话前先喂饱**：`LocalAiClient.ask` 与 `CatGirlAiPrompt.candidates` 都会
   `CatGirlRecipeTable.ensureLoaded(server)`；兜底候选清单也不再依赖配方表是否载入 —— 列表本来就不该是空的。

**两个新配置 + 一个默认值**（`[cat_girl.ai]` 段）：`max_tokens`（默认 **512**，原来硬编码 300）、
`prefill_json`（默认 true）；`timeout_ms` 默认 30000 → **60000**（思考型模型一轮真能想十几秒）。

**门禁**：`tools/ai_wire_test/LmStudioWireTest.java` 从 17 项加到 **24 项** —— 新增的四条判据就是上面那几张截图
（只有思考不算答案 / 降级理由指向 max_tokens / 两段花括号取真答案 / prefill 开关的形状），并对着**真端点**
实跑「带 prefill」与「不带 prefill」两条路径。

### 1.1.98 — 2026-10-11

**修好 EasyNPC 武器商预设：它以前是个空商店。**

实机导入后暴露了两个真问题，都是「按类结构反推 SNBT」的代价：

- **`TradingDataSet` 挂错了层**：原来直接写在 `data:` 下，而 EasyNPC 读的是
  **`data.TradingData.TradingDataSet`**（字段表见 `TradingDataCapable`）—— 写在顶层等于
  **交易设置整段被忽略**。
- **商品表 `Offers` 整个缺失**：右键能打开交易界面，但**里面什么都没有**。

修法是照 EasyNPC 官方带交易的预设（`default_preset/villager/welcome_coin_trader.npc.snbt`）
逐字段对齐，并补齐自己漏掉的 `Offers` / `PresetUUID` / `Profession` / `SkinData` / `SoundData` /
`EntityAttribute`。预设也从 `api/preset/apocalypse_zombies/`（不是 EasyNPC 的约定路径）挪到
**`default_preset/villager/`**（与官方 24 个默认预设同级）。

现在预设自带**七条交易**，六把枪全部装满弹、绿宝石定价，每 30 分钟自动补货：

| 商品 | 弹量 | 价格 | maxUses |
|---|---|---|---|
| Uzi | 32 | 18 绿宝石 | 16 |
| 十字弩 | 1 | 20 | 16 |
| S686 | 2 | 24 | 12 |
| 莫辛纳甘 | 5 | 32 | 12 |
| M1 加兰德 | 8 | 36 | 12 |
| RSC M1917 | 5 | 40 | 8 |
| AWM | 5 | 48 | 8 |

**导入时那两条提示不是错误**：`Owner data was updated` / `Action permission levels were reduced`
是 EasyNPC 对**每个**预设都做的净化，官方内置预设导入时一字不差地打同样两条。第二条是动作权限被夹到
`security.cfg` 的 `creativePlayerCommandLevel`（默认 `MODERATORS`）；抬到 `OWNERS` 就不再夹。

细节与「怎么改商品」见 [`docs/EasyNPC-武器商.md`](docs/EasyNPC-武器商.md)。

### 1.1.97 — 2026-10-11

**全部 readme 过一次账：把停在旧版本的描述改成现状。这一版只动文档，没碰代码。**

起因：`art/` 下那几份 README 与 `DELIVERY.md` 各自停在交付那一天，里面的「待办 / 未做 / 未修」
有些早就做完了 —— 下一个动这个仓库的人照着旧结论干活会白跑。核过一遍，四处实证错误：

- **音效署名还停在借用时代**（`art/awm/README.md`、`art/m1garand/README.md`）：两处都写着
  「22 个 TaCZ 音效是**未修改副本**、只留在自用包」—— 1.1.93 早就全换成项目自备录音了，
  `-clean.jar` 也因此第一次有了声音。旧行已划掉并写明现状。
- **一个「未修」其实早修了**（`art/crossbow/DELIVERY.md` 偏差 #9）：「物品栏图标只有约 4 px，
  未修待定」—— 1.1.95 已修（这把 0.30 → 1.20）；紧跟的「待定 #2：是否四把枪一起放大」也随之**已决**。
- **一个「未做」其实早做了**（`art/uzi/DELIVERY.md`）：「Java 同步：未做，`UziItem` 尚未落地」
  —— 早就落地了，八个 clip 里五个在用。
- **wiki 索引对不上现状**（`docs/wiki/README.md`）：部署脚本还写着 `_deploy_140.py`（现 **196**）、
  readme 还写着「514 行」（现 **1975 行**）、门禁「13 个脚本」（现 **18 个**）、
  `tools/`「100+ 个脚本」（现 **235 个**）。

**待办列表加了重核结论**（`art/awm/README.md`、`art/m1garand/README.md`）：逐条核过 ——
`WeaponMount` 常量类**确实仍未做**（全仓库没有这个类）、AWM 那 5 段 clip 仍**未接线**
（`AWMItem` 里没有任何 `ANIM_*` 常量）、持枪程序化微动仍缺；但加兰德的 `draw` **已接线**。

**`mod.toml` 那条也改准确了**：`build.gradle` 只认 `src/main/resources/META-INF/mods.toml`，
根目录这个**不参与构建** —— 每版顺手同步它的 `mod_version` 只是习惯，改了它不影响任何产物。

### 1.1.96 — 2026-10-11

**村民会自己管门和种地了。**

- **随手关门 / 白天开门**：村民会照看附近的门 —— 白天打开、夜里关上。**铁门不碰**：那是玩家上锁
  用的，替它开等于绕过门禁。门 1.5 格内有活物时这一轮不动手，免得把谁夹在门里。
- **成熟就收、收了就补种**：小麦 / 胡萝卜 / 马铃薯 / 甜菜，成熟的当轮收掉，**先用一颗当种子补上**
  （顺序与原版农民一致，不会留下空畦），其余进村民自己的背包 —— 背包装不下就丢在它脚边，
  不让作物凭空蒸发。
- **为什么不做成 Goal**：村民的日程走 `Brain` 的活动系统（`WORK` / `IDLE` / `PANIC`），移动由
  `MoveToTargetSink` 下发，自己挂的 `Goal` 会和它抢 `Flag.MOVE`；而这两件事都**不需要移动** ——
  站在原地就能干完。所以挂在「村民 tick」那一支上，与「恐慌 + 呼救铁傀儡」共用同一个节流
  （`ai_enhance.villager_interval`，默认 20 tick）与按实体 id 打散的相位。
- **开销**：一轮是一条 `半径 × 5 × 半径` 的方块带（y 只上下探 2 格 —— 门与庄稼都在地面附近）。
  默认半径 6 时单轮约 845 格，同屏 N 个村民摊到每 tick 上是 N/20 轮。
- **三个新配置项**（`ai_enhance` 段）：`villager_door_enabled`、`villager_farm_enabled`、
  `villager_chore_radius`（2~24，默认 6）。关掉前两个就分别停掉那件事；`villager_enabled = false`
  仍然是整支的总开关。图形配置界面里会自动多出这三行（总数 151 → **154**）。

### 1.1.95 — 2026-10-11

**枪械在物品栏里的显示放大到与金剑相近的比例。**

- **问题在哪**：枪械走的是 `builtin/entity`（GeckoLib 渲染 3D 模型，不是平面贴图），物品栏里多大
  只由 `display.gui.scale` 说了算 —— 而它一直是 **0.30~0.36**。于是 1.5 格长的 AWM 在 16 像素的
  格子里只占约 **7 像素**，短枪更小。**贴图本身没问题**（内容占满画布：awm 100%×88%、
  mosin 100%×44%），所以这不是重画贴图能解决的。
- **新值怎么定**：不拍脑袋 —— 直接量各枪 geo 模型的联合包围盒得到**真实全长**，再按
  「枪长占到格子宽度的约 90%（14.5 / 16 像素）」反算，所以短枪放得多、长枪放得少：

  | 枪 | 模型全长 | 旧 scale | 新 scale |
  |---|---|---|---|
  | AWM | 1.50 格 | 0.30 | **0.60** |
  | 莫辛纳甘 | 1.43 格 | 0.30 | **0.63** |
  | RSC M1917 | 1.32 格 | 0.32 | **0.69** |
  | S686 | 1.22 格 | 0.30 | **0.74** |
  | M1 加兰德 | 1.10 格 | 0.32 | **0.82** |
  | Uzi | 0.99 格 | 0.36 | **0.92** |
  | 柯尔特 1878 | 0.93 格 | 0.30 | **0.97** |
  | 十字弩 | 0.76 格 | 0.30 | **1.20** |

  效果是**八把枪在物品栏里看起来一样长**（视觉差异只剩模型本身的长短），而不是现在这样长枪短枪
  都缩成一小条。
- **只动了 `gui` 这一格**：`display` 的其它槽位（第三人称、第一人称、地面、展示框、头盔）一个没碰
  —— 手里的持枪位与掉落物的显示保持原样。

### 1.1.94 — 2026-10-11

**铜装备补齐铜斧。**

- **为什么单独补**：1.1.92 那批是按点名列的（剑 / 镐 / 锄 + 四件甲），漏了斧。斧在原版是与镐并肩的
  第二把「主力工具」—— 砍木、破盾、当近战武器都行，缺了它这一档就不成套。
- **数值照石斧，不是石剑**：斧头在 1.20.1 的伤害本来就比剑高一大截（石斧 **9** 点 vs 石剑 5 点），
  所以铜斧抄的是**石斧**那一组参数（`1 + 7 + 1 = 9` 点 / 攻速 -3.2），与石斧完全一致 ——
  这正是"武器伤害和石制一样"这条要求对斧的读法。耐久 200、效率 5.0、挖掘等级同石，
  全部跟着 `ModTiers.COPPER` 走，与另三件铜工具同一档。
- 贴图沿用「原版铁质 → 铜色」那套映射（`tools/copper_gear_art.py` 的映射表加一行，现在共 10 张，
  含穿在身上的两层）。配方照原版斧形（三个铜锭 + 两根木棍），进创造模式工具页。

### 1.1.93 — 2026-10-11

**枪械音效全部换成项目自备的录音 —— 顺手切掉了「纯净包没声音」这条尾巴。**

- **换掉了什么**：此前 22 条音效事件指向的全是**借用**的 TaCZ AWM 录音（CC BY-NC-ND 4.0），
  文件躺在 `assets/apocalypse_zombies/sounds/awm/`（22 个 / 604 KB）。现在整套换成
  `sounds/guns/` 里项目自备的 17 个录音，TaCZ 那 22 个文件已删除。
- **事件名一个没改**：`sounds.json` 的键、`ModSounds` 的常量、各枪的 `tick → cue` 时刻表是
  同一份契约，所以换音源只是把文件重新指一遍 —— 七把枪的时刻表一个字都不用动。
  （`ModSounds` 的类注释早就写下了这条路：*replacing the .ogg files is the whole job*。）
- **两把枪有了自己的枪声**：`uzi_shoot`（四支 AK 录音，每发随机挑一支 —— 连发时不像复读）
  与 `crossbow_shoot`（三支弩弦，同样随机）。其余狙击 / 半自动 / 霰弹共用 `awm_shoot`
  （一支 .338 的录音）—— 素材里没有它们各自的枪声。
- **机械声全部重指**：拉栓 `akm_bolt_2`、推栓与抛壳 `akm_bolt_1`、闭锁 `bolt_1`、
  举枪 `awp_reload_1`、卸匣 / 插匣 `akm_reload_1/2`。
- **副产品（值得单说）**：`build.gradle` 的 `borrowedEntries` 原来**整目录**排除
  `sounds/**` 与 `sounds.json`（为了剥掉 AWM 音效），代价是连背景音乐一起没了 —— 纯净包是个
  哑巴包。音源换成自备的之后这两项不必再排除，所以 **`-clean` 分发包从这一版起有声音了**；
  还留在借用清单里的只剩转录动画 `awm.animation.json` 一项，`borrowedPack` 也随之只剩动画。
- `crossbow_hit`（弩箭命中）事件已按素材注册好，但当前**没有调用点** —— 弩命中沿用原版箭矢声。
  留着是为了以后接命中反馈时不必再动 `sounds.json`。
- `alarm_siren_a/b`（两支警报）**暂未接入**：项目里还没有警报场景，素材先随包放着。

### 1.1.92 — 2026-10-11

**新增一整套铜装备：铜剑 / 铜镐 / 铜锄 / 铜头盔 / 铜胸甲 / 铜护腿 / 铜靴。**

- **定位**：原版五档（木 / 石 / 铁 / 钻石 / 下界合金）之间没有「铜」这一层 —— 石（耐久 131、
  攻击 +1、石级挖掘）上去直接就是铁（250、+2、铁级）。铜补的是**石与铁之间**那一格：
  - **耐久比石高**：工具 200（石 131 / 铁 250）；
  - **武器伤害与石一样**：攻击加成都取 +1，所以铜剑与石剑同为 5 点；
  - **护甲比皮革高、比铁低**：护甲值 2 / 4 / 3 / 1，合计 **10**（皮革 7 / 铁 15）。
    单看头盔它与铁同为 2 —— 原版护甲值是整数，皮革的 1 与铁的 2 之间没有第三个数，所以这条
    落在整套**总和**上。
- **其余口径**：挖掘等级同石（挖得动铁矿石、挖不动钻石）；效率 5.0（石 4.0 / 铁 6.0）；
  附魔性 12（石 5 / 铁 14）；护甲耐久系数 11（皮革 5 / 铁 15）⇒ 头 121 / 胸 176 / 腿 165 / 靴 143。
- **修复材料**是铜锭（`minecraft:copper_ingot`）；穿戴音借铁的 —— 原版 1.20.1 还没有铜护甲音效。
- **配方**与原版石 / 铁装备同形，材料换成铜锭（工具另加木棍）。
- **贴图**：把原版**铁质**装备贴图做「铁 → 铜」的色调映射（只换色相、保留明暗），含**穿在身上**
  的两层 `copper_layer_1/2.png` —— 文件名必须与 `ModArmorMaterials.getName()` 对得上。
  生成器在 `tools/copper_gear_art.py`，PNG 读写用脚本自带的 zlib 实现，不依赖任何图像库。
- 猫耳娘的护甲渲染层认的是 `ArmorItem`，所以这套铜甲她也能穿、也能正常渲染。

### 1.1.91 — 2026-10-11

**修好爆炸弹「只有特效、一点血都不掉」。**

- **病根是一道只装了一半的闸**：`event/AmmoEffects` 里防递归的 `detonating` 写了声明、也在
  `onLivingHurt` 开头做了 `if (detonating) return;` 的检查，但**全文件没有一处把它设成 `true`**。
  于是爆炸自己引爆自己 —— 爆炸拿玩家当伤害来源，那一下伤害又走进同一个事件、手里还是爆炸弹、
  又炸一次……一路递归到 `StackOverflowError`。
- **为什么看到的偏偏是「有粒子、有爆炸声，就是不掉血」**：粒子与音效在 `detonate()` 一进门就发了，
  而 Forge 的 `LivingHurtEvent` 是在伤害**真正落地之前**触发的 —— 栈溢出炸在中途，那一发伤害
  （连子弹本身那 6 点引信伤害在内）整个作废。特效与伤害看着是两件事，其实是同一处的两端。
- **修法**：把闸合上。`detonate()` 里先判一次、再 `detonating = true`，整段用 `try/finally` 包住 ——
  用 `finally` 而不是写在末尾，是为了中途任何异常都不会把闸**永久锁死**（那会让爆炸弹从此连特效都没有）。
- 口径一个字没动：半径 2.5 格、中心 14 点、向外线性衰减、引信 6 点、只打敌对生物、不破坏方块、
  玩家自己永远不在伤害范围内。

**十字弩的三处姿态**（前两条同一个根因：**静止类片段把弦放回了松弛位**）。

- **装弹之后弦应该是拉满的**：装弹链是 `draw`（拉弦上牙）→ `reload_tactical`（装箭），
  但 `reload_tactical` 与 `static_idle` 都写着 `bow_pose(0.0)` —— 刚拉满的弦在装箭时又弹了回去，
  切回待机再看仍是没上弦。弩的常态本来就是「已上弦待发」：`getAmmo` 默认就给 1（新弩到手就是
  上弦的），射空后 `inventoryTick` 又立刻自动开始装弹。所以静止类片段（`static_idle` /
  `reload_tactical` / `ADS_up` / `ADS_down` / `inspect`）的弦一律停在牙上；真正经过松弛位的
  只剩 `draw` 的起点（空弦拉起）与 `shoot` 的终点（放弦弹回）。
- **发射完成回到平行**：`shoot` 末帧必须把弦放掉（弦心离牙 ≥ 1 格单位），门禁现在按这条判，
  实测 2.98u。
- **右键瞄准隐藏双手与武器**：`hidesModelWhileAimed()` 由 `false` 改为 `true`。满镜时弩身与
  双手正压在准心环与十字上（武器就在屏幕正中），玩家等于在透过自己的手套瞄；举镜过半把画面
  交给镜片之后，世界照样看得见 —— 藏掉的是弩和手，不是那层镜。
- **顺手修好一个一直没生效的门禁**：`check_crossbow_anim.py` 的弦缆运动学检查里，
  `bone_xform` 的缓存键只有骨骼名、**不含时间**。调用方按片段复用一个 memo 逐帧扫描，于是整段
  动画的每一次求值都拿回第一帧那个函数 —— 「弦心最大距离」恒等于首帧值：`draw` 全程都报
  2.98u（看着像"根本没拉弦"），这一段检查形同虚设。缓存键补上时间后才真正逐帧，`draw`
  2.98→0.79→0.094、`shoot` 0.094→2.98 才露出来。

### 1.1.90 — 2026-10-11

**子弹能穿过树叶、打碎玻璃；修好猫耳娘手里那件东西「倒着的、跟玩家拿反了」。**

- **子弹与方块的约定**（新配置段 `bullets`，**七把枪与怪物那发实体子弹共用同一份口径**）：
  - `bullets.pass_leaves`（默认 **true**）：子弹穿过树叶 —— 不掉伤害、不减速，不再被路上一片叶子挡下来
    （叶子上蹭出一小撮绿粒子）。认原版 `minecraft:leaves` 标签，带这个标签的模组树叶一样放行。
  - `bullets.break_glass`（默认 **true**）：命中就打碎玻璃（玻璃板、染色玻璃、遮光玻璃都算 ——
    认的是原版 `SoundType.GLASS` 而不是写死方块 id；硬度为负与带方块实体的方块不动）。
    碎法走原版掉落表：原版玻璃本来什么都不掉，等于「碎了但不掉东西」。爆炸弹那条「不破坏地形」不变。
  - `bullets.pass_glass`（默认 **false**）：打碎之后继续飞，还是碎在玻璃上停下（默认停下）。
  - 实现收在一处 `BulletRay`：原来**八个文件各抄一份** `level.clip(... COLLIDER ...)`（一字不差；
    七把在册的枪 + 一份归档副本），现在统一走它 —— 柯尔特 1878 继承 `S686Item`，自动跟着换；怪物那发实体子弹的命中判定在原版 `Projectile` 里插不上手，改成「撞上叶子不消散、
    挪到叶背继续飞」—— 规则同源，同一份配置管两边。
- **修猫耳娘手里那件东西**：1.1.80 那次**多补了一步**。原版那两步基准旋转（`XP -90°` → `YP 180°`）
  是写给**翻转前**那个模型空间的 —— 原版实体渲染器在模型之外还压了一次 `scale(-1,-1,1)`
  （把模型里「Y 向下」翻成世界向上，顺带把模型 +X 映射到世界 -X）。她的 geo 是按**翻转之后**那个空间
  画的（`right_arm` 在 +X、头在 +Y 上方、刘海在 -Z、尾巴在 +Z），GeckoLib 又不像原版那样补那次翻转
  —— 所以她这里只需要 `XP -90°` 一次。记 F = `scale(-1,-1,1)`，`F · XP(-90) · YP(180) ≡ XP(-90)`
  （物品的上 / 面 / 右三根基向量逐个验过）。多补的 `YP 180` 等于给手里的东西又套了一层 F ——
  物品的「面」朝下、自身右轴翻到她的左，看起来就是「倒着的、跟玩家拿反了」，斧刃朝里是同一条因。
  **`cat_girl.held_item_mirror` 这个开关随之退休**（它本来就是给这个 bug 打的补丁），
  老配置里那行删掉即可（留着不影响，Forge 会忽略它）。
- 不回归：RSC M1917（19 骨 / 577 方块 / 512² / 8 条片段）、其余 6 把枪的资产与动画、猫耳娘 v4、
  1.1.89 的配置自动迁移（`migrateLegacyAiConfig`）全部原样。

### 1.1.89 — 2026-10-11

**老实例的本地 AI 端点自动迁移：Ollama 口径 → LM Studio 口径**

1.1.84 把她换成 LM Studio（`http://127.0.0.1:1234/v1`）之后，老实例还在报
「连不上本地模型 `http://127.0.0.1:11434`」——**不是接线没换，是配置文件里的值没人换**：
Forge 的配置**只写默认值、从不覆盖已经存在的值**（连越界值都只在读取时校正，文件里照旧写着越界的数），
所以 `apocalypse_zombies-common.toml` 里 1.1.76 写下的 `endpoint = "http://127.0.0.1:11434"`
和 Ollama 形状的模型名（`fableforge-ai/nexus-coder:q4_k_m`）一直躺到今天，注释是新的、值是旧的。

- **一次性迁移**：`Config.migrateLegacyAiConfig()`，在 `ModConfigEvent.Loading` 里跑（配置进内存**之后**才读得出值；
  构造阶段读会抛 `Cannot get config value before config is loaded`）。改完调 `SPEC.save()` 让 Forge 把文件按新值重写。
- **判定故意收窄**：端点只认那套旧默认值（`127.0.0.1/localhost:11434`，含 `/api/chat`、`/api/generate` 尾巴的写法），
  自己填的地址 —— 哪怕也带 11434、或是别人机器的 Ollama —— 形状对不上就不碰；
  模型名只认「旧默认那个」或 Ollama 惯用的 `:量化标签` 尾巴，LM Studio 的 `作者/模型` 名字一律不动。
- **日志**：迁移发生时会写一行 `Migrated legacy cat_girl.ai config: … → …`（实机探针认这一行）。
- **顺手改齐**：`tools/_ai_probe.py` 从 Ollama 的 `/api/chat`（`options.num_ctx` / `format:"json"` / `eval_count`）
  改成 LM Studio 的 `/v1/chat/completions`（`chat_template_kwargs` / `json_schema` / `usage.completion_tokens`），
  与 `LmStudioWire` 同一套请求体与回包兜底；**不传模型名会自动从 `GET /v1/models` 挑**（优先模组默认那个），
  端点没起来时只回一句「LM Studio 起了吗」，不再是栈回溯。
- **出货**：`py tools/_deploy_189.py --build`。

### 1.1.88 — 2026-10-11

**RSC M1917 轮廓对表口径换代：台阶表 → 线性插值，点状特征收口**

1.1.87 之后还剩 6 处离群值（拖曳钩、前背带环、准星、机匣尾突、中枪箍），
逐列追下去发现根因不在外形，而在**读轮廓的口径**：

几何生成器一直用「1 mm 台阶表」读实测轮廓（整毫米格取上一列的值），
而门禁用**线性插值**读同一份实测 —— 两条口径在每一处竖直断崖上都差一整列。
于是照片里一刀切下去的竖直边（背带环的尖、机匣后端面）在同一列被读成两个不同的高度，
报出 −19 ~ +36 mm 的「离群值」，其实几何是对的。

本版把生成器也改成**按测量列线性插值**（与门禁同口径），并让放样在**实测跳变点**劈段
（`LOFT_MIN_SEG` 1.0 → 0.15 mm），此外四处实体修正：

| 件 | 原写法 | 修法 |
|---|---|---|
| 膛口帽前沿 | 探出 z=0 有 **0.4 mm** | 收回到 z=0 —— 0.4 mm 会让整张对表网格整体偏移，每条断崖都假报一列 |
| 中枪箍 / 前托木料下缘 | 直接跟 `pB(z)`（含背带环的下探） | 改走 `pBw(z)`：木料不跟着挂在腹下的钢件一起下探，下探由背带环件自己画 |
| 前背带环 V 尖 | 拐点 706、2.5 mm 内回升 | 收陡（688~707.4，拐点 **706.5**，0.9 mm 内回升） |
| 准星起点 | z 20 mm | **15.3 mm** |

- **结果**：单列最大偏差 >10 mm 的列数 **6 → 0**（全表 2577 列，最大单列偏差上缘 7.5 mm / 下缘 8.8 mm）；
  剪影 IoU 0.960 → **0.963**，上缘 RMS 2.34 → **2.05 mm**，下缘 RMS 2.28 → **1.68 mm**。
- **门禁加固**：`tools/rsc_1917_silhouette.py` 新增 **单列最大偏差 ≤ 10 mm** 判据（`--edge-tol`，默认 10），
  并把「读模型」从插值改成**取最近列**（方块台阶几何一插值就会造出根本不存在的中间高度）。
  RMS 会把尖摊平，单列判据才抓得住点状离群值。
- **几何**：584 → **577 方块**（19 骨、512² 逐面 UV、13 px/u）；8 条片段与其余 6 把枪不动。
- **Java**：`Rsc1917Item` 类注释漂移修正（17 骨 → 19 骨、四条片段 → 七条、1.34 格/1339 mm → 1.32 格/1319 mm），逻辑一行未改。
- **出货**：`py tools/_deploy_188.py --build`。

### 1.1.87 — 2026-10-11

**RSC M1917 弹匣/护圈段精修：把最后几处「定点常量」也改成跟实测表放样**

上一版把木头/机匣/枪托的外轮廓改成了照参考照片逐列放样，但弹匣箱与扳机护圈那一小段仍是手写常量。
用户圈出两处后逐列对表，定位到 4 个「一整块平板只用一个定点值」的件：

| 件 | 原写法 | 实测偏差 | 修法 |
|---|---|---|---|
| 弹匣箱侧壁加强筋（左右各一） | 下缘 `pB(940)+14` 常量拉满 z 876~986 | z 880 处 **−18.6 mm** | 新增 `wallZ()` 薄墙放样器，下缘跟 `pB(z)+14` 走 |
| 卡榫长杆（`safety` 骨） | 下缘 `pB(1064)+1` 常量拉满 z 1044~1092 | z 1090 处 **−19.5 mm** | 改放样，后端随实测表抬升 |
| 扳机护圈底圈 | 下缘 `pB(1020)−2` 常量 | z 1030 处 **+9.0 mm**（偏浅） | 改放样，下缘逐列跟表 |
| 卡榫 / 铰链（弹匣盖） | 下缘定点常量 | z 990 处 −10.3 mm | 同上，改 `wallZ` |

另新增一条自检规矩：`clip`/`clip_empty`（漏夹 5 发）的**每一块下缘不得低于其跨度内的弹匣内底**
—— 原先一排 5 发的底缘在 z 892 处比真值低 22 mm，会从弹匣前脸戳出来。

- **结果**：剪影 IoU 0.951 → **0.960**，上缘 RMS 2.34 mm 持平，下缘 RMS 3.84 → **2.28 mm**；
  圈出的窗口（z 850~1120 mm）最大偏差 **−19.5 → −5.4 mm**。
- **几何**：518 → **584 方块**（19 骨、512² 逐面 UV、13 px/u，atlas 353/512 行）；
  Java 侧一行未改，8 条片段与其余 6 把枪不动。
- **工具**：`tools/bbmcp_lib.js` 的 MCP 请求超时 900 s → **75 s + 最多 3 次重试**
  （实测 500+ 次调用后桥会偶发挂住，没超时整条构建就卡死）；出货脚本 `tools/_deploy_187.py`。

### 1.1.86 — 2026-10-11
**RSC M1917 外形重建：轮廓改成「照参考照片逐列量取」驱动**

- **问题**：1.1.85 的几何竖直尺寸是一组手写常量（前托只覆盖 z 470~805、木头前段整段缺失），
  侧视剪影与参考照片差 20~35 mm。新增剪影对表工具量化后，IoU 只有 **0.62**。
- **做法**：`tools/rsc_1917_measure.py` 按 alpha 取剪影 + HSV 分木/金，逐列量出真值表
  `art/rsc_1917/profile2.json`（2577 列，全长 1319 mm，0.51212 mm/px，膛线轴 y_axis=128.0 px）；
  `tools/rsc_1917_geo.js` 改成**放样器**：木头/机匣/枪托的上下缘直接采样实测表，
  手写常量只留横向半宽与特征件（准星/枪箍/背带环/弹匣箱/扳机护圈…）。
- **结果**：剪影 **IoU 0.62 → 0.951**，上缘 RMS 5.24 → **2.34 mm**，下缘 RMS 11.76 → **3.84 mm**；
  全长 1320 mm 对实测 1319 mm（0.08%）。
- **新门禁** `tools/rsc_1917_silhouette.py`：IoU ≥ 0.90、上缘 RMS ≤ 3.0 mm、下缘 RMS ≤ 5.0 mm，
  超阈值 exit 1（点状特征——拖曳钩/背带环的尖——离散化后会有几列 20~36 mm 离群值，故上下缘分列阈值）。
  `tools/rsc_1917_preview.py` 出正交侧视渲染与「参考图/模型」上下对照长图（尺度归一 0.51212 mm/px）。
- **几何**：282 → **518 方块**（19 骨、512² 逐面 UV、13 px/u，atlas 349/512 行）；
  机匣后端面按实测收到 z=1122；弹匣盖与漏夹改成跟着箱底走（不再戳穿箱底）；
  准星 z 20~34、刺刀座 z 20~32、拖曳钩 z 102~192（底 −42）、前枪箍 z 171~197、
  中枪箍+前背带环 z 688~707（底 −64）、照门 z 782~862（顶 +28）、
  弹匣箱 z 858~1000（底 −88.6）、扳机护圈 z 998~1044、托底板 z 1306~1319、后背带环 z 1214~1244（底 −119）。
- **材质**按参考照片重新配平：枪管/枪箍更黑、机匣比木色深一档、木托偏暗红棕。
- **不回归**：8 条动画片段与 Java 常量未动；另 6 把枪与柯尔特 1878 规格未变。

### 1.1.85 — 2026-10-11

**新枪：RSC M1917（法国 Fusil Automatique Modèle 1917 半自动步枪）。**

- **真机口径**（这三条就是这个型号的身份证，也决定了整套动画）：
  - 5 发**漏夹从下方**插进**固定弹匣** —— 不是 M1 那种从机匣上方往下压；
  - **弹匣盖铰链在前端**，松卡榫后向前下方敞开 60°，废漏夹随之掉出；
  - **没有自动空仓挂机**（那是 M1918 才有的；M1917 只有射手手动按的枪机卡榫）：最后一发打完，
    枪机照常复进闭锁，空漏夹被合着的盖兜在匣里，等换弹时开盖才掉出来。
  - 8mm 勒贝尔口径；长行程导气活塞；旋转闭锁枪机；拉机柄在机匣**右侧、只沿枪轴平移不旋转**。
- **几何与贴图**（`tools/rsc_1917_geo.js` → `rsc_1917_build.js`）：
  - 19 骨 / 282 方块 / **512² 逐面 UV 图集**（1692 个面，装箱密度 13 px/u）；
  - 尺寸不是估的：参考图 `art/rsc_1917/ref_rsc1917_side.png` 先按枪管上下缘拟合倾角**转正**，
    再以枪口断面中点为膛线轴逐列量取 —— 剪影 2599 px = **1331 mm**，成品 **21.42 u = 1339 mm**
    （0.6% 误差），枪口 Z=−16.03、托底 Z=+5.39，膛线轴 = 模型 Y 0、扳机 = Z 0。
  - 曲面全部用图元生成（`tubeZ` 实心芯+外圈棱、`band` 环），枪托逐段带 cube 级 rotation 连成托腹弧线。
- **8 条片段**（`tools/rsc_1917_bb_anim.js` 在 Blockbench 里跑 → `rsc_1917_anim.py` 转 GeckoLib）：
  `static_idle`(2.0s) / `draw`(1.0) / `shoot`(0.6) / `shoot_last`(1.2) / `bolt`(1.1) /
  `reload_tactical`(2.6) / `reload_empty`(3.6) / `single_load`(1.5)；
  隐藏件（弹壳 / 空漏夹 / 单发那发）全靠**本骨 scale 0**，不许整枪缩放。
- **换弹动画按真机顺序**（也是门禁逐条卡的因果）：
  按卡榫 → 盖向前下敞开 → 空漏夹掉出 → 新漏夹**自下往上纯平移**插到位 → 合盖 →
  **最后才拉一次拉机柄送弹入膛**（因为没有挂机，这一拉是真需要的；M1 那套「枪机已被挂住」在这里不成立）。
- **Java 接线**：`Rsc1917Item` / `Rsc1917GeoModel` / `Rsc1917ItemRenderer` +
  `ModItems` 注册 + 中英 lang（含死亡讯息）+ `models/item/rsc_1917.json` +
  `damage_type/rsc_1917_bullet.json`；**手持姿势**（握把 / 前托 / 拉机柄 / 弹匣盖四个手部目标点）
  从本枪 geo 量出来写进 `Rsc1917GeoModel`，动作相位与片段关键帧对齐。
- **门禁**：新增 `tools/check_rsc_1917_art.py`（逐面 UV 落绘、无重叠、**镜像符号**：
  抛壳件与拉机柄必须在 −X 侧）与 `tools/check_rsc_1917_anim.py`
  （片段表/时长契约/隐藏件钉位/**换弹因果**/末帧 rest/镜像符号/不许整枪缩放）；
  出货走 `tools/_deploy_185.py`，并实跑 `check_gun_resources.py`。
- 不回归：LM Studio 接线、挖掘数字与高亮、36 格库存、猫耳娘 v4、
  另外 6 把枪与柯尔特 1878 的规格全部未动。

### 1.1.84 — 2026-10-11

**她的脑子换成 LM Studio 了：本机 `1234/v1` 上那个 Qwen3.5-4B 蒸馏版（GGUF / Q4_K_S），不再走 Ollama。**

- **接线层重写**：`ai/OllamaWire` → `ai/LmStudioWire`，请求改走 OpenAI 兼容的
  `POST /v1/chat/completions`（Ollama 那套 `/api/chat` + `options.num_ctx` + `format:"json"` 它一个也不认）。
  端点写法宽容：填主机、填 `/v1`、填整条 `/v1/chat/completions` 都能拼对。
- **两个实测撞出来的坑**（都钉进门禁了，免得下次换模型再撞一遍）：
  - `response_format` LM Studio **只认 `json_schema` / `text`** —— 照搬 Ollama 的
    `{"type":"json_object"}` 会被 **HTTP 400** 顶回来（原话：`'response_format.type' must be
    'json_schema' or 'text'`）。现在五个键连类型与取值范围一起钉死，小模型没法用
    「少写一个键」「count 写成文字」蒙混。
  - 回包可能把话放在 **`reasoning_content`** 里而 `content` 是空的（思考型模型），
    只读 `message.content` 会白跑一轮 —— 现在按 content → reasoning_content → `choices[0].text` 依次兜底。
- **不用先在 LM Studio 里手动加载模型**：它会按需把模型拉起来（首次多等几秒），所以
  `ai.timeout_ms` 默认 20000 → **30000**。
- **新增开关 `ai.json_schema`**（默认 true）：极少数版本 / 模型不收 json_schema 的那种情况，
  关掉即退回「提示词约束 + 容错解析」，她照样说话，只是格式偶尔要返工。
- **默认配置**：`ai.endpoint = http://127.0.0.1:1234/v1`、
  `ai.model = qwen3.5-4b-claude-4.6-opus-reasoning-distilled`。
- **门禁**：`tools/ai_wire_test/LmStudioWireTest.java` 拿**真 LM Studio** 跑 17 项
  （白名单 + 各类坏回包降级 + 回包三种形状 + 端点拼接 + `response_format` 契约 + 真模型实跑）。
- 不回归：`server.execute` 回主线程 / 连续失败 3 次熔断 5 分钟 / 每玩家最近 6 轮历史 /
  动作只认 `none|say|set_job|craft` / 合成仍要过「配方表 + 她的白名单」两道 —— 一条没动。

### 1.1.83 — 2026-10-10

**瞄准的时候准星下面会报数了：这一下左键会连挖几格 —— 跟画出来的框是同一份数字。**

- 数字画在准星正下方（`client/renderer/VeinMineHighlighter.renderCount`），含你瞄的那一格 ——
  那是这一下左键的总账；描边只画「连带下来的那些」，所以框会比数字少 1 个，两个都对。
- **只报 2 格以上**：只砸一格的时候原版本来就是这样，没必要在准星底下常驻一行字。
- **到上限会说明**：撞到 `max_blocks`（默认 64）时写成「会连挖 64 格（已到上限）」，
  免得你以为眼前那一簇就这么大。
- `player_mine.count = false` 可以只留框不要数字；两个开关各管各的（只要数字、不要框也行）。
- **顺手补了个谎**：1.1.82 的高亮在你**潜行**时还会照画一整簇，可实际上潜行只砸一格。
  现在「潜行不连带」这条判定收进了 `PlayerVeinMine.preview` 这个共用出口（服务端与客户端读的是同一份），
  蹲下时框和数字会一起消失 —— 依旧是那条规矩：画的一定是真会砸的。
### 1.1.82 — 2026-10-10

**挖矿看得见了：瞄着矿脉时，左键会一起下来的那些方块会被描上青色的边 —— 画的一定是真会砸的。**

- **高亮由客户端画**（`client/renderer/VeinMineHighlighter`，挂在 `RenderLevelStageEvent` 的
  `AFTER_TRANSLUCENT_BLOCKS` 阶段）：瞄准的那一格原版已经画了黑框，我们只给**会连带下来的那些**描边，
  一眼就能看出「这一镐下去会带走多少」。
- **「画出来的框」=「实际会砸的」**：选块用的是服务端同一个 `PlayerVeinMine.preview(...)`
  —— 同一份配置 + 同一套安全判定。不会出现画了不砸，也不会砸了没画。
- **纯观感，不影响判定**：关掉（`player_mine.highlight = false`）照样能一键挖掘；
  联机时高亮按**你自己**客户端那份配置算，服务端该砸多少还是它说了算。
- **不卡**：瞄准格没变就不重算（缓存键含半径 / 上限 / 目标集合等），配置一改立刻重算。
- **配置**：`[player_mine]` 新增 `highlight`（默认 **true**），该段共 **11 项**、图形界面共 **168 项**。
- 不回归：1.1.81 的连带规则 / 1.1.80 的 36 格库存与手持方向照旧，猫耳娘 v4 与柯尔特 1878 原样。

### 1.1.81 — 2026-10-10

**玩家也能一键挖掘了：左键砸掉一格，同一种矿石跟着一起下来 —— 不设按键、不加命令，
全部行为只认配置文件（默认开启）。**

- **触发方式就是原版的「破坏方块」**（`BlockEvent.BreakEvent`，服务端；没有按键、没有网络包、
  客户端装不装这个 mod 都一样）：以你砸的那一格为种子，把**同一种方块**连带下来。默认**只认矿石**
  （煤 / 铁 / 金 / 钻石 / 红石 / 青金石 / 绿宝石 …，走原版 `forge:ores` 标签）。
- **深层也认亲**：`iron_ore` ↔ `deepslate_iron_ore` 算同一簇 —— 否则你在深层挖铁矿只会下来一格。
- **配置 `[player_mine]`（10 项，图形界面里同样能改）**：`enabled`（默认 **true**）、
  `targets`（**0 = 只矿石** / 1 = 矿石 + 自然方块 / 2 = 任何可挖方块）、`radius`（默认 16，4~64）、
  `max_blocks`（默认 **64**，1~64，含你自己砸的那一格）、`vein_only`（true = 只连带连通的矿脉）、
  `require_correct_tool`（true = 手上工具不对口就不连带，只砸你点的那格）、
  `consume_durability`（true = 每多挖一格扣 1 点耐久，创造模式不扣、工具用坏就停手）、
  `sneak_disables`（**true** = 潜行时只砸一格，想单挖就蹲下）、
  `to_inventory`（true = 产物直接进背包，塞不下掉在你脚下）、
  `protected`（追加保护名单，与 `cat_girl.mine_protected` 合并生效）。
- **安全边界与她那边共用同一套判定**：容器 / 方块实体（箱子 · 熔炉 · 床）、保护名单、流体、火、
  硬度为负 —— 一律不碰。只有把 `targets` 调成 2 才会连带你自己盖的房子，默认不会。
- 不回归：1.1.80 的 36 格库存 / 手持物品方向 / 不垂直下钻照旧，猫耳娘 v4 与柯尔特 1878 原样。

### 1.1.80 — 2026-10-10

**她的库存扩到 36 格（背包 27 + 物品栏 9，与玩家同款）；修掉「她手里的东西方向不对」；
自主挖矿不再垂直下钻、会自己到附近找矿。**

- **库存 36 格**：`CatGirlEntity` 的 `GOODS_HOTBAR = 9` / `GOODS_BACKPACK = 27` /
  `GOODS_SIZE = 36`，容器真按 36 格建。界面按原版排布 —— **上三行背包 27 格、最下一行物品栏 9 格**，
  槽位坐标只有 `CatGirlTradeMenu.goodsSlotX/Y` 一份（界面标价格也走它，不会对不上槽）；
  玩家那 27 格移出面板（仍注册，shift 搬货 / 给予格 / 3×3 合成不变）。
  **老存档不用管**：库存按槽位下标原样存取，原来的 9 格仍落在 0~8，新的 9~35 是空的。
- **修「手持物品方向不对」**：她的东西是**真实物品**（挂在她主手槽、由 `BlockAndItemGeoLayer`
  画在 `item_righthand` 骨骼上），而 GeckoLib 那一层只做「平移到骨骼 pivot + 骨骼自身旋转」，
  **没有**原版 `ItemInHandLayer` 在交物品前补的那两步基准旋转（`XP -90°` → `YP 180°`）。
  缺它的直接后果：**平物品（方块、锭、食物）立着摆在她手里像一张牌子**，工具也少一截倾角。
  现在补齐这两步再走原版 display 变换。原版那一步后面还跟着 `translate(±1/16, 0.125, -0.625)`
  ——「从手臂枢轴挪到手心」的 0.625 格位移，是照原版「枢轴在肩」算的；我们的挂点骨骼 pivot
  （`[2.75, 10.4, 0]`）本来就落在她手心，再补会把手里的东西顶到小臂上，**故不取**。
  另留开关 `cat_girl.held_item_mirror`（默认 false）：只有你看着她的镐/斧头朝里侧、跟玩家拿反了才开。
  **1.1.90 已删这个开关**：那一步是写给「翻转前」那个模型空间的，她这套空间只需要 `XP -90°` 一次 ——
  多补的 `YP 180` 正是把东西翻成「倒着的、跟玩家拿反了」的那一步，见 1.1.90 条目。
- **不再垂直下钻 + 会找矿**（`cat_girl.mine_depth` 默认 **1**、`prospect` 默认 **true**）：
  自主挖矿的垂直窗口从 `-8…+6` 收到 **`-1…+3`**（不再把自己挖进坑里）；附近一时没矿可挖时，
  她按 `prospect_step`（默认 8 格）在 `autonomy_radius` 内挑**没探过、能站人**的地表点走过去重扫，
  已探点入表带过期；连续 `prospect_tries`（默认 6）次空手就回主人身边待命。**订单另算**：
  `/apocalypse catgirl mine` 是主人点名的活，下探深度走 `mine_order_depth`（默认 **6**）。
- 三处不回归：1.1.79 的图形配置界面 / 一键挖掘上限 64 / id 参数修复、猫耳娘 v4 皮肤与几何、柯尔特 1878。

### 1.1.79 — 2026-10-10

**一键挖掘的数量上限收到 64；「模组列表 → 配置」这个按钮现在真能按了 —— 图形界面直接改配置
（范围就在里面改），和手改 TOML 是同一份。**

- **数量上限 = 64**：`cat_girl.mine_max_blocks` 默认 **64**、范围 **1~64**；
  `/apocalypse catgirl mine <方块id> [数量]` 里 `[数量]` 写超过 64 会被**夹到 64**
  （配置是唯一的口子：改配置才能改上限，命令越不过去）。
- **新增图形配置界面**（1.1.79）：Forge 从 1.19 起删掉了内置配置编辑器，本模组自带一张 ——
  `模组列表 → 选中 Apocalypse Zombies → 配置` 打开：
  - 列出**全部 154 项**配置，按段分组（`cat_girl` / `ai` / 月相 / 进化 / 尸潮 …），滚轮翻页，右上角显示进度；
  - 布尔 → **开/关**按钮；整数/小数 → 数字输入框；列表（如 `mine_protected`）→ 逗号分隔输入框；
  - 点「完成」**立刻写回** `config/apocalypse_zombies-common.toml`，另有「恢复默认」；
  - 填了非数字会就地提示（`「cat_girl.mine_radius」这一项要填数字。`），**整屏不会半途写坏**；
  - **范围就改这里**：`cat_girl.mine_radius`（默认 24，4~64）。**填了越界的数不会把游戏搞坏**：
    启动时 Forge 会把它改回默认值并在日志里写明
    （`Incorrect key cat_girl.mine_max_blocks was corrected from 256 to its default, 64.`），
    顺手把文件也改回来 —— 从 1.1.78 带着 `256` 升上来的老配置就是这么被收成 64 的（实机验过）。
- 实现：`client/ModConfigScreens`（注册扩展点）+ `client/gui/ApocalypseConfigScreen`（界面本体，
  直接读 `Config.values()` 的声明顺序）；注册走 `DistExecutor.unsafeRunWhenOn(Dist.CLIENT, ...)`，
  这几个纯客户端类在**专用服务器上不会被加载**（`_deploy_179.py` 有断言钉着）。
- **修了个真 bug（实机撞出来的，`mine` 和 `craft` 都中）**：两个命令的 id 参数原来是
  `StringArgumentType.word()` —— 它（以及 `string()`）的**不带引号**形式只认 `[A-Za-z0-9_.+-]`，
  所以**文档里让你写的 `minecraft:diamond_ore` 一直解析不过去**（Brigadier 直接报
  `Expected whitespace to end one argument, but found trailing data`）；`craft` 更别扭：
  它的失败提示里写着「写 id，例如 minecraft:diamond_pickaxe」，你照抄反而报错。两条都换成
  原版 `/setblock` 那套 `ResourceLocationArgument.id()`：两种写法都收
  （`minecraft:diamond_ore` 与 `diamond_ore`，不带命名空间按 `minecraft:` 补前缀），
  还白拿一份 id 补全；控制台上两种写法都验过能解析。
- 三处不回归：1.1.78 的镐子 / 一键挖掘 / 工作方块、猫耳娘 v4 皮肤与几何、柯尔特 1878。

### 1.1.78 — 2026-10-10

**她的镐子成了全功能镐子，谁都能挖、挖了都有掉落（基岩除外）；新增「一键挖掘」指令；
干活会自己走去工作方块前 —— 就近没有就把合成台/熔炉做出来放脚边。**

- **全功能工具**（`CatGirlHarvest`）：她主手拿什么，都按方块「该用的工具类型」结算掉落 ——
  斧砍树、锹挖土、剪刀剪叶、镐挖石；`always_drops` 打开时连原版工具等级也不再拦（木镐也挖得下
  黑曜石那类高硬度矿，掉落照给）。**唯一的例外是保护名单**（默认：基岩 / 屏障 / 光 / 结构空位 /
  三种命令方块 / 结构方块 / 拼图 / 传送门与传送门框 / 末地门 / 强化深板岩 / 紫水晶母岩 / 刷怪笼，
  配置项 `cat_girl.mine_protected`，可增删）。
- **一键挖掘指令**：`/apocalypse catgirl mine <方块id> [数量]` —— 给她一份订单，她自己走过去、
  在配置范围内找**最近的同名方块**砸，产物进她自己的库存；挖满自动收工，
  `/apocalypse catgirl mine stop` 中止。
  - **范围** = `cat_girl.mine_radius`（默认 24 格，4~64，自主挖矿与一键挖掘共用）；
  - **数量上限** = `cat_girl.mine_max_blocks`（默认 256，1~4096）—— 命令里写多大都会**被配置夹住**，
    想一次挖更多就去改配置，不是去改命令；
  - 订单会**存进 NBT**（读档继续挖），容器/流体类方块直接拒绝下单（她按约定不碰容器）。
- **什么都能挖**：`cat_girl.mine_all`（默认开）把自主挖矿的目标从「只有矿石」放开到所有非保护的自然方块
  （土 / 沙 / 砾 / 树叶 / 石头类都算）—— 仍然只认自然方块，不会拆主人的房子。
- **去工作方块干活**（`CatGirlStationGoal`）：合成走去就近的合成台、熔炼走去就近的熔炉，
  走到跟前才动手 —— **像玩家一样**，而不是站在野外空手摆 3×3。
  - 就近没有时（`cat_girl.station_self_craft`，默认开）她自己做：合成台 = 4 木板、熔炉 = 8 圆石，
    材料从她自己的库存出（伐木/挖矿攒的），只放在**空气/草/雪这类可替换位置**且下面有实心支撑，
    **绝不覆盖任何已有方块**。做不出来就什么都不做。
  - 开关与半径：`cat_girl.station_use`（默认开）、`cat_girl.station_radius`（默认 16 格）。
  - **有退路**：就近压根没有这类方块 → 退回原来的「就地空手做」，不会把她的活卡死。
- **修**：同一维度里**第二只及以后的猫耳娘永远不会自己制作/熔炼**（自动制作的时间戳之前按维度记账，
  同 tick 里第二只被第一只刚写下的时间戳挡掉）。现在按每个个体记账。

### 1.1.77 — 2026-10-10

**她终于会自己做材料了 —— 「有没有」改成「够不够」，并且不再烧自己的装备。**

- **修：做一件工具后就僵住（材料明明还有）**。她的补料链之前只问「这种料我**有没有**」，
  不问「**够不够**」：手里捏着 1 块木板、配方要 3 块，摆料失败 → 补料那圈又以为什么都不缺 →
  **一块木板都不会再劈**，于是整条链卡死在第一件成品上（实机：做出 1 把铁锹后 50 秒不动，9 个铁矿原封不动）。
  现在按「同一种料一条配方里占几格就是要几个」记账，缺几个补几个，直到够为止。
- **修：把自己的铁剑/盔甲烧成铁粒**。原版有「铁制装备 → 铁粒」的冶炼配方，她缺铁粒时真会把自己的铁剑、
  铁护腿丢进炉子。现在**成品装备一律不进炉**（炉子里只有矿石/生料那类原材料）。
- **覆盖到材料**，不只成品：木板、木棍、熔炼后的锭，都由她自己的库存现做现用；
  原料只从**真实配方表**里挑（她不会凭空变出东西）。
- **验证方式（可复跑）**：`tools/rcon_catgirl_craft_probe.py` 对着真服务端下料、掐表、读她库存：
  12 原木 + 12 圆石 → 她自己劈木板/搓木棍、做出**木镐/木斧/木剑/木锹/木锄 + 石镐/石剑/石锹**；
  9 铁矿 + 6 煤 → 她自己烧成锭、做出铁装。11 项断言全绿（含「镐/斧/剑齐活」「不烧玩家的方块料」「不烧自己装备」）。
  探针开跑前会**清干净场地掉落物** —— 否则上一只阵亡掉的东西会被新那只捡走，把「她自己做出来的」测成假绿。

### 1.1.76 — 2026-10-10

**修了一个会把服务端打崩的崩溃；她能听人话了 —— 用你机器上的本地模型（默认 qwen2 1.5B）。**

- **崩溃修复（重要，1.1.75 装了就中）**：她那张合成用的 3x3 之前是「配一张空菜单」建的，
  而原版 `TransientCraftingContainer.setItem()` 内部就会回调 `menu.slotsChanged(...)` ——
  菜单是 null 时<b>第一次放材料就 NPE</b>，而这条路径跑在服务端每 tick 的 `broadcastChanges` 里，
  于是整局崩（崩溃报告：`CatGirlCrafting.layOut → TransientCraftingContainer.setItem`）。
  现在给她配了一张空壳菜单（`GridMenu`，`slotsChanged` 走默认空实现），并给
  「下单」和「自动制作/熔炼」两条 tick 路径各加了一层兜底：真出事也只记日志、跳过这一拍。
- **本地 AI 助理**：`/apocalypse catgirl ai <一句话>` —— 她听懂人话、回你一句，必要时动手：
  **切工种**（伐木/挖矿/战斗/跟随，和「你手动指派」同一条路径，会关掉自主模式）或
  **用她自己的材料给你下单做东西**（剑/镐/斧/锹/锄/弓弩/箭/盾/盔甲，扣爱心币手续费）。
  `/apocalypse catgirl ai status` 看端点/模型/熔断状态。
- **跑在你机器上的模型**：默认 `http://127.0.0.1:11434` + `fableforge-ai/nexus-coder:q4_k_m`（qwen2 1.5B），
  不联网、不花钱。实测（RTX 3060 6GB）：**0.2~0.6 秒一轮、约 150 token/s**。
  *（这是 1.1.76 当版的口径；**1.1.84 起默认已换成 LM Studio `http://127.0.0.1:1234/v1`，
  1.1.89 起老实例的配置会自动迁过去** —— 见 1.1.89 条目。）*
  「思考标签」会被剥掉，模型返回的每个字段都会被<b>重新校验</b>：动作只认 none/say/set_job/craft，
  物品必须真在配方表里、还得是她会做的那几类 —— 不可信的字段一律降级成聊天，绝不透传到执行层。
- **不会因为 AI 而崩**：请求在工作线程跑、结果回投主线程；连不上/超时/回包是垃圾 → 一句中文提示；
  连续失败 3 次熔断 5 分钟（别让她每句话都去戳一个没起来的 ollama）。配置项都在 `catgirl.ai.*`
  （`enabled` / `actions` / `endpoint` / `model` / `timeout_ms` / `num_ctx`），`actions=false` 时她只陪聊不动手。

### 1.1.75 — 2026-10-10

**她有脑子了：自己看着背包和周围挑活干、会把多余的成品收进你指定的箱子、你挨打时贴过来站位。**

- **自主模式**（`CatGirlNeedGoal`）：每 2 秒看一眼 —— 有敌人在主人身边就上（FIGHT）、
  背包里原木不足 8 就伐木、矿石不足 8 就挖矿、都不缺就跟着你。它<b>只改工种、不抢执行权</b>，
  所以不会和战斗/劳作打架。你一动手切工种（给工具 / 空手右键），这个个体就自动关掉自动模式 ——
  你要它砍树时它不会自作主张跑去挖矿。`/apocalypse catgirl auto` 再打开。开关 `auto_job`。
- **用容器**（`CatGirlContainerGoal`）：把**多余的成品**（工具/武器/盔甲/弓弩/盾，每种至少留一件）
  收进你给它绑的储物点；背包里矿石少于 4 时从那里取一组接着熔炼。
  储物点用 `/apocalypse catgirl chest` 绑定（她 6 格内最近的容器）、`chest clear` 解绑 ——
  **没绑她一个容器都不碰**（原版分不出哪个箱子是玩家的）。开关 `chest`。
- **护卫**（`CatGirlEscortGoal`）：主人被攻击时贴到主人与攻击者之间站住。原版跟随只在主人离得远时
  才动，挨贴脸时她是看戏的 —— 这条补上「挨打 → 立刻靠过去」。打谁仍由目标选择器决定。开关 `escort`。
- **两个新命令**：`/apocalypse catgirl auto`（开关自主模式）、`/apocalypse catgirl chest [clear]`（绑定/解绑储物点）。

### 1.1.74 — 2026-10-10

**她会走路了：开门、浮水、绕开挡路的、自己跨过坑，还会跟着你不被甩掉。**

- **导航换成玩家式**（`CatGirlNavigation`）：原版跟班用的默认导航把门当墙、把水当死路 ——
  现在她能推开门走过去、落水会浮着走、也不绕太阳。
- **开路**（`CatGirlClearWayGoal`）：导航走不通时，砸掉挡路的自然方块（原木/树叶/土/沙/圆石类/雪），
  掉落照旧走她那一套（含 `always_drops`）。**绝不碰**箱子·熔炉·工作台这类带方块实体的、也不碰门；
  硬度 3.0 以上（黑曜石/残骸）不砸。开关 `clear_way`。
- **搭桥**（`CatGirlBridgeGoal`）：正前方是坑（深谷/水/岩浆）时，用**她自己背包里**的实心方块铺一格落脚点，
  铺完重算路径。背包里没砖就不过去 —— 和你一样。开关 `bridge`。
- **自己出门找目标**：搜索半径取 `work_radius` 与新的 `autonomy_radius`（默认 32）的较大值，
  所以老存档里写死 12 也不会把她关在院子里。
- **不跟丢**：跟随速度走 `follow_speed`（默认 1.3，原版跟班 1.15），主人跑起来时她能跟上；
  主人离她超过 `autonomy_radius` 时她先跟人再干活。

### 1.1.73 — 2026-10-10

**猫耳娘会「接单」了：你说做哪件，她掏自己的料做给你。**

- **订做指定物品**：`/apocalypse catgirl craft <物品id> [数量]`（找 16 格内属于你的那只猫耳娘）。
  材料从**她的库存**扣，手续费按 `craft_fee`（默认 2 枚）从**你的爱心币**里扣，成品直接进你背包。
  她界面里也多了一格「样品槽」：放一件样品 → 右边出成品，样品不收，取走成品就再做一件（想停就把样品拿回去）。
- **3×3 摆放**（这次的重头）：她不再「按材料堆凑」，而是把配方自己的形状铺进一张 3×3 网格再让原版 `matches` 点头 ——
  「3 木板 + 2 木棍」到底是斧还是镐，看形状，不再掷骰子看配方表顺序。
- **盔甲看得见了**（`CatGirlArmorLayer`）：GeckoLib 自带的 `GeoArmorRenderer` 只认自注册的几何盔甲，
  对原版/模组盔甲物品无效，所以这里把原版盔甲网格（`HumanoidModel` 的内/外层）按骨骼包围盒**贴合**到她的
  头 / 身 / 双臂 / 双腿 / 双脚上，走路甩尾会带着甲一起动。开关 `armor_render`（默认开）。
- **内部熔炉**：她的库存里有矿石 + 一份燃料（原版熔炉认什么她就认什么）→ 自动烧成锭（铁矿石→铁锭、生铁→铁块那类
  走原版 `minecraft:smelting`）。开关 `smelt`（默认开）。燃料本身不会被烧掉（不然她会把木头全烧成炭）。
- **月亮三项**：①月相颜色逐条对齐 Crafting Dead（蓝月 `0x55AAFF`、血月 `0xFF5555`、黄月 `0xFFE055`、
  超级血月 `0xCC44FF`…），HUD 的月相字色跟着 tint 走；②**血月会主动刷怪**了：每 `blood_moon_spawn_interval`
  (200 tick) 在每名玩家 20~40 格外放 `blood_moon_spawn_count`(2) 只僵尸，走 `finalizeSpawn` 吃尸潮倍率；
  ③闸门复用已有的 `isBloodMoon()`。

### 1.1.72 — 2026-10-10

**猫耳娘自己干活：拾取 → 自制 → 按工种换装备（含盔甲），工具无耐久、砸矿必掉**

- **拾取**（`pickup`，默认开）：她扫身边 1.5 格捡地上的东西塞进自己的库存（**36 格**：背包 27 + 物品栏 9，1.1.80 起）——
  不走原版那套（原版要 `mobGriefing` 开着才捡），5 tick 扫一次，捡到的直接进她的货架。
- **自制**（`auto_craft`，默认开）：新增 `CatGirlCrafting` —— 把她库存里的材料按**原版配方表**
  做成装备，每 40 tick 出一件，产物进库存（也就是摆上货架）。
  只做「她自己的装备」：工具（剑/镐/斧/锹/锄）、弓弩、盔甲、箭、盾、三叉戟 ——
  不设白名单她会把材料做成木棍台阶、把库存变垃圾场。材料判定用多重集（她没格子摆位），
  要精确摆放走她界面里那套原版 3×3。候选配方带缓存，不会被一千多条配方拖慢。
- **自动换装**（`auto_equip`，默认开）：按工种自己换主手 —— 伐木拿斧、挖矿拿镐、
  战斗拿剑（没剑但有弓且有箭就用弓弩），跟随/没事干时把工具收回库存。换装按材质等级
  （木/金 0 < 石 1 < 铁 2 < 钻 3 < 下界 4）挑最好的，**换下来的回库存不丢**；
  手上已经是对口工具时不动（保护玩家刚给她的那把）。同时把库存里防御更高的盔甲穿到
  头/胸/腿/脚四个槽（换下来的同样回库存）。
- **无耐久**（`no_durability`，默认开）：她的主手、盔甲、库存里所有可损物品每 20 tick 修满。
- **砸什么都有掉**（`always_drops`，默认开）：原版卡掉落的是 `playerDestroy` 里的
  `canHarvestBlock`（工具等级），不是掉落表本身 —— 掉落为空且方块要求对口工具时，
  用最高等级工具再取一次，所以木镐砸钻石矿也有钻石。
- **货币交易**：爱心币（`love_coin`）那套原样可用 —— 她做好的东西进她库存即货架，
  从她货架拿东西按 `coinValue` 扣爱心币；不够钱给提示 + 生气粒子。

**闭环**：捡/收下材料 → 她自己做成剑斧镐甲 → 按工种换上 → 你花爱心币从她货架换走成品。

### 1.1.71 — 2026-10-10

**猫耳娘：全无敌不死 + 弓弩完整蓄力 + 她的界面与玩家背包同布局**

- **全无敌 / 不死**：新开关 `invulnerable`（默认 true）。开启时 `isInvulnerableTo` 恒真、
  `hurt` 直接返回 false（连红屏击退都没有），并且额外兜住两个原版后门 ——
  `kill()`（`/kill` 不看无敌）与虚空伤害（`OUT_OF_WORLD` 绕过无敌判定）：
  `aiStep` 每 tick 把血线补满，掉到世界外就拉回主人身边。关掉开关退回原逻辑
  （只免疫尸潮阵营的伤害）。
- **弓弩完整蓄力**：弓拉满 **20 tick** 才放、箭速 3.0、散布 1.0；弩装填 **25 tick**、箭速 3.15、
  散布 0.6，放完歇 6 tick —— 节奏与玩家拉弓/装弩一致，不是连发。蓄力时站定（停寻路）抬臂。
- **她的界面 = 她 36 格 / 你 27 格**（1.1.80 起）：她的库存按玩家的排布来 ——
  **上三行是背包 27 格、最下一行是物品栏 9 格**（共 36），槽位坐标只有一份算法
  `CatGirlTradeMenu.goodsSlotX/Y`，界面标价格也走它；**玩家那 27 格移出面板**
  （`PLAYER_ROW_Y = 10000`，槽位仍注册，所以 shift 搬货 / 给予格 / 3×3 合成照旧）；
  背包与物品栏之间画一条分组细线，面板高度仍 226。
- **尾巴摆动**：新增 `tools/cat_girl_tail_sway.py`，把 tail1..tail4 按「逐节相位波」重算 ——
  idle 周期 2s、左右摆 20/13/11/9 度、扭转 4/5/6/7 度，四节相位依次后移 0.12 个周期
  （波从尾根走到尾尖，是猫甩尾而不是整根平移）；walk 周期 1s、摆幅略收、扭转加大。
  可复跑、`--check` 校验、自动留 `.bak.json`。

### 1.1.70 — 2026-10-10

**猫耳娘配方表：自动同步游戏里所有能做得出来的东西**

- 新增 `tools/cat_girl_recipes_sync.py`：自动发现并抽取**原版 `client.jar` +
  游戏实例 `mods/` 下每一个 jar + 本模组开发目录**里的配方（`data/<ns>/recipes/**.json`），
  归一化成「id / 来源 / 类型 / 产物 / 材料」四要素，按 id 排序、算内容指纹。
  只认真配方文件，`advancements/recipes/`（进度）与 `datapacks/bundle/`（实验数据包）自动排除。
- 产出三份：主表 `art/cat_girl/recipes_all.json`、汇总 `art/cat_girl/recipes_summary.md`、
  装机副本 `data/apocalypse_zombies/cat_girl/recipes.json`（随 mod 打包，运行时读）。
  幂等可复跑，`--check` 用指纹判定「盘上的表是否还跟游戏一致」（不一致 exit 1，已接入出货门禁）。
- 新增 `CatGirlRecipeTable`：从资源管理器载入装机表，按服务器实例缓存，暴露总数 / 来源 /
  命名空间 / 按产物反查 —— 这是她「会做玩家能做的任何东西」的依据表；
  真正合成仍走原版 `RecipeManager`，所以模组配方天然支持。
- 新增调试命令：`/apocalypse catgirl recipes`（总数 + 内容来源 + 命名空间分布）、
  `/apocalypse catgirl recipes <命名空间>`（列明细，最多 20 条）。

**当前实机数据**：1 433 条配方（原版 1 174 + 模组 259），命名空间 10 个，
供了配方的模组 9 个（sophisticatedbackpacks 84、crafting-dead-core 83、Jennycraft 34、
hexalunar_calamity 24、tacz 11 …）。指纹 `644faf82cd9b7035`。

### 1.1.69 — 2026-10-10

**猫耳娘「工具即指令」：给什么工具，就干什么活**

- **斧子 → 伐木**（`ItemTags.AXES`）、**镐子 → 挖矿**（`ItemTags.PICKAXES`）、**剑 / 弓 / 弩 → 打怪**。
  交工具的瞬间工种跟着切，并提示「收下了 X，开始 Y」。判断走原版物品标签，模组里带标签的斧/镐同样认。
  锹/锄与自定义武器只换装、不动工种。
- **弓真的会放箭**：新增 `CatGirlBowGoal`（注册在近战之前、同优先级）。条件=打怪模式 + 手持弓/弩 +
  目标活着 + 有视线 + 距离 > 3 格 + **她库存里有箭**；每 1.4 秒一发，箭从她库存里扣，贴脸自动退回近战。
  距离 ≤ 3 格或没箭时弓的目标不成立，自然轮到近战 —— 不需要额外优先级数字。
- **修一个静默失败**：弓既不在原版工具标签里、也没有 ATTACK_DAMAGE 属性，原来交给她是**毫无反应**的。
  现在交弓/弩会正常收下；**交箭**（右键）会进她自己的库存，箭袋空了会给玩家一句提醒。

工程：`mod_version` → `1.1.69`；`tools/_deploy_169.py`（新增映射函数 / 弓目标 / 两套 lang 提示键判据）。

### 1.1.68 — 2026-10-10

**猫耳娘交互修复**

- **蹲下右键 = 打开她的界面**：这条分支提到了 `mobInteract` 的最前面。原来它排在「喂鱼 / 交工具」
  之后，手里正好拿着斧子去蹲下点她，会被「交工具」吃掉；而 shift 状态是每 tick 同步的，
  服务端本来就有滞后 —— 分支越靠前越稳。现在蹲下永远优先。
- **点她一定会有回应**：未认主 → 提示「喂她一条鱼」；不是主人 → 提示「她只认自己的主人」；
  认主后空手 → 循环工种（跟随 / 伐木 / 挖矿 / 战斗）。原来这几种情况是静默无反应，
  看起来就像「点了没反应」。
- **她的界面只显示她自己的东西**：玩家背包那 27 格挪到面板之外（槽位仍存在，所以 shift
  一键搬进背包、关界面把给予/合成格还回玩家都照常可用），只在面板底部保留**快捷栏一行**——
  不然界面上没有任何玩家来源格，给予格和 3×3 合成就没法填。顺带修了价格文字飘在「库存」
  标题上方 40px 的错位。
- **工程**：`mod_version` → `1.1.68`；`tools/_deploy_168.py`（新增两套 lang 提示键 + 界面槽位布局判据）。

### 1.1.67 — 2026-10-10

**月亮事件与 Crafting Dead 同步**

- **触发方式**：从「每晚按概率随机掷骰」改为 **Crafting Dead 的 28 天日历** ——
  第 6/7 天蓝月、第 13 天血月（每 14 天）、第 20/21 天黄月、第 27 天超级血月（每 28 天）。
  `MoonEvent.forDay` 与 CD 的 `MoonEventType.forDay` **逐条一致**（连判定顺序都照抄，
  出货脚本里钉了对照判据防漂移）。想回随机：`lunar_schedule = false`，那组概率原样保留。
- **血月规则补齐**：血月（含超级血月）期间禁止 **苦力怕 / 蜘蛛 / 洞穴蜘蛛 / 女巫**生成
  （`blood_moon_blocks_other_mobs`，默认开），与 CD 的 `MoonEventHandler.handleCheckSpawn`
  同一条规则 —— 血月之夜把舞台留给僵尸潮。禁睡、进化加成、尸潮等原有规则不变。
- **工程**：`mod_version` `1.1.66` → `1.1.67`；出货脚本 `tools/_deploy_167.py`
  （新增「日历表与 CD 逐条一致」判据 + 猫耳娘/柯尔特不回退护栏）。

### 1.1.66 — 2026-10-10

**新内容：猫耳娘（`cat_girl`）随从 —— 推倒重写 v4**

- **模型 / 贴图**：`tools/cat_girl_v4_build.py` 是唯一真相源，从零生 128×128 皮肤 +
  31 骨骼 / 126 方块装机 geo（逐面 `uv/uv_size`）。脸层 44×32 px（7.9 px/u）；
  眼 / 眉 / 腮红全部走整数列镜像公式 `a' = w − a − width`（浮点起点在 44 列偶数画布上
  会让左右各差 1 px），嘴宽取**偶数**才能让中心正好落在 22.0。
- **玩法**：喂鱼驯服 → 空手右键循环工种（伐木 / 挖矿 / 游荡）→ 潜行右键开交易界面：
  卖任意物品（含模组物品）换爱心币、爱心币附魔、3×3 合成走原版 `RecipeManager`
  （模组配方照样能合）、用爱心币买她伐木挖矿攒下的库存。
- **修 6 处 Java 编译**（都在源码里留了注释，别再踩）：
  `TamableAnimal` 在 1.20.1 属 `net.minecraft.world.entity`（**不在** `.animal` 子包，
  写错会让整类变未知类型并级联炸掉菜单与渲染器）；Forge 1.20.1 **没有**
  `RegisterMenuScreensEvent`，走 `FMLClientSetupEvent` + `MenuScreens.register`；
  `ServerPlayer.openMenu` 本版本**无 2 参重载**，要同步 entityId 得用 `NetworkHooks.openScreen`；
  `SimpleContainer.addItem` 返回**剩余物 ItemStack**（不是 boolean）；
  `ForgeRegistries.ITEM` → `BuiltInRegistries.ITEM`；`Config` 补 `CAT_GIRL_ENCHANT_COST`。
- **工程**：`mod_version` `1.1.65` → `1.1.66`；出货脚本 `tools/_deploy_166.py`
  （含**柯尔特 1878 不回归护栏**：12 骨 / 87 方块 / 512² / 8 条片段长度逐条等于 Java 常量）。

### 1.1.65 — 2026-10-09

**修正 · 右键瞄准的姿态与物品栏大小**

- **全枪族瞄准时枪离玩家太远**。根本原因是 `adsZ`（瞄准时沿视线往玩家身边收多少）**七把枪全是 0**，
  所以枪纹丝不动地停在手部基准位上，"像是被推出去半臂"。现在各枪都给了收拢量。
  注意 `adsZ` 的屏幕表现不是平移而是**整体变大/贴脸** —— 它是沿视线方向的位移。
- **S686 瞄准时枪托挡视野**。从 geo 量出来：枪托顶部 `y = +1.06` 比照门准星 `+0.38` 还高，
  而视轴在 `y = 0` —— 枪托整个**横跨视轴**，准星一对到屏幕中心它就压在视线上。
  把 `ADS_Y` 从 `0.3533` 降到 `0.30` 让整枪下沉，枪托顶落到视轴之下。
- **分枪微调的 `ADS_X` / `ADS_Y`**（各枪几何差异大，只能一把把调）：
  | 枪 | ADS_X | ADS_Y | adsZ |
  |---|---|---|---|
  | Uzi | −0.4746 | 0.3015 | 0.18 |
  | M1 加兰德 | −0.475 | 0.32（枪托下压） | 0.21（枪托后移） |
  | 莫辛纳甘 | −0.475 | 0.37（枪管上调） | 0.18 |
  | AWM | −0.475 | 0.346 | 0.18 |
  | 弩 | −0.475 | 0.399 | 0.18 |
  | S686 | −0.4749 | 0.30 | 0.06 |
  | 柯尔特 1878 | −0.465 | 0.27 | 0.18 |
- **物品栏里 S686 / 柯尔特偏大**：两把枪的 `gui` scale 是 `0.36`，而其余长枪（Mosin / AWM / 弩）
  都是 `0.30` —— 它们比 Mosin 短却用了更大的值。统一到 `0.30`（Uzi 本身很短，保持 0.36）。
- 工程：`mod_version` `1.1.64` → `1.1.65`；瞄准诊断探针（`DIAG_AIM` / `DEBUG_ARMS`）保持默认关闭。

### 1.1.64 — 2026-10-09

**修正 · 柯尔特 1878 的折开回到"枪管向下折"**

- 1.1.63 把折开改成了"机匣+枪托绕铰链向上翻、枪管不动"。枪管确实稳在画面里了，但
  **枪托会翻到斜上方，整把枪看着像一支折叠托武器** —— 枪托折叠本身就是问题，回退。
- 现在恢复真枪的样子：**只有枪管组绕铰链向下折 62°**，机匣 / 托颈 / 枪托保持原姿态；
  前托、空壳、左手、待装弹都挂在枪管链上，跟着一起折。
- "整体向上微抬"与折开是两件事：换弹时整枪往上抬 `0.25 u` 并回收 `0.05 u`（`LIFT`），
  甩腕那一下仍是向下一顿。`shoot` 的后坐同理 —— 整枪上抬 + 后退，不转枪管。
- `body` 骨的 pivot 从铰链改回机匣中心（它不再参与折开）。
- 工程：`mod_version` `1.1.63` → `1.1.64`。

### 1.1.63 — 2026-10-09

**调整 · 柯尔特 1878：方块拼缝全部消除 + 折开改成"枪管不动、机匣上翻"**

- **方块之间的黑缝没了。** 根因是贴图生成时给每个面的**四边都压暗了 24%** ——
  一块块的深色描边拼起来就是一串缝，远看像模型没接上。现在去掉描边，并让每个方块往各方向
  外扩 `0.003 u`（0.19 mm）与邻居**轻微重叠**，兜住浮点取整留下的亚像素缝。
- **折开不再让枪管垂下去。** 第一人称里枪管一垂就甩出画面中心，看着像枪塌了。
  改成 `body −62° / barrel +62°` —— 两个骨骼的 pivot 都是铰链，反向角正好抵消，
  于是**枪管在世界坐标里纹丝不动**，只有机匣与枪托绕铰链向上翻开。相对角仍是 62°，弹膛照样露出来。
  "枪管真的没动"是量出来的：`tools/colt_1878_fold_probe.js` 里 `body −62 / barrel +62` 那一行，
  枪管 cube 的世界坐标与 rest **逐位相同**。
- 随之撤掉了 `shoot` / `static_idle` / `ADS_up` / `ADS_down` 里**所有** barrel 与 body 的转角：
  后坐改成**整枪向上微抬 + 向后推**，待机改成整枪在手里微微起伏。
  以后再往这两个骨上加转角，枪管就会跟着动 —— 这条约束写进了 `tools/colt_1878_anim.js` 的注释。
- 验收图（`art/colt_1878/anim/`）：`fold_closed_seamless.png` 是合膛状态的接缝检查，
  `fold_open_barrel_still.png` 是折开状态（枪管保持水平、机匣上翻）。
- 工程：`mod_version` `1.1.62` → `1.1.63`。

### 1.1.62 — 2026-10-09

**修复 · 柯尔特 1878 的折开动作根本不是折开，外加一批"看不出来但确实是错的"地方**

> 起因：看图后要求"查找短管霰弹枪的真实换弹进行动画重做"。照真枪查了一遍才发现，
> 问题不在"不够像"，而在**几何上就是错的**。

- **折开绕错了轴（最要命的一条）**：原来写的是 `rotation [0,0,-52]` —— 绕的是 **Z**，
  而 Z 是枪管长轴。绕长轴转是**枪身滚转**：枪仍水平伸着、只是换了个面，
  玩家看到的"折开"其实是枪在原地翻身。真枪是绕**铰链那根左右横轴（X）**、管组**向下**折。
  这一次不再靠推理：新增 `tools/colt_1878_hinge_probe.js` 直接量枪管方块的世界坐标 ——
  绕 X −62° 让枪口端的世界 y 从 +0.28 掉到 −7.1，绕 Z −52° 则几乎不动。折开角同时 52° → **62°**。
- **顶杆（top lever）也拨错了方向**：原来是沿枪轴前后推（position z），真枪是**横向拨**（position x）。
  改成从侧向拨出 0.13 u。
- **`shell_upper` 原本是一个方块都没有的空骨** —— 退壳动画一直在驱动不存在的东西，
  所以游戏里"掉壳"根本看不见。补上两发空壳（黄铜底缘朝弹膛口那一侧）。
- **退壳改用真机行为**：本枪是 **extractor（抽壳器）不是 ejector（抛壳器）**，
  开膛时只把壳顶起几毫米，壳是靠**甩腕**抖出去的。新动画是
  「extractor 顶起 → 整枪向下一顿 → 两发壳飞出并翻转」，而不是原来那种平白飞走。
- **左手与待装弹挂错了父骨**：`hand_l`（握前托）与 `bolt_loaded`（弹膛里的弹）原本挂在 `body` 下，
  而它们应当随**枪管**走 —— 枪管一折开，左手就脱离前托飘在半空、待装弹停在一个不存在的膛位上。
  改挂 `barrel`；`GunFrame.partChain` 本来就是运行时沿父链走的，**Java 一行都没改**。
- **枪托那串"台阶"是两处叠加**：① `colt_1878_build.js` 下发 `place_cube` 时把 cube 级
  `rotation` 写死成 `[0,0,0]`，geo 里给枪托算好的下垂角**从来没生效过**；
  ② 那个下垂角**符号是反的**，每段相对整体下降上翘 13.3°，8 段互相错开。改对之后
  `sin(13.3°) × 0.5075 = 0.1167 ≈ DROP/SEGS = 0.12`，相邻段端点正好对接，枪托成一条平滑斜线。
- 换弹动作链整体按真机重排：拇指横向拨顶杆 → 管组绕铰链向下折 62° → extractor 顶壳 →
  甩腕退壳 → 右手取弹 → **两发同时**塞进两个弹膛 → 管组上抬合膛、顶杆自动回中。
  时长不变（`reload_tactical` 3.0 s / `reload_empty` 3.6 s，仍明显慢于 S686 的 1.95 / 2.475）。
- 几何重建：**83 → 87 个方块**（多出来的两发空壳），12 根骨不变。
- 验收图在 `art/colt_1878/anim/`：`reload_tactical_t0p67.png` 是折开到底、
  `reload_tactical_t1p04.png` 是甩腕退壳（两发空壳已经飞出去）。
- 工程：`mod_version` `1.1.61` → `1.1.62`；顺手把根 `mod.toml` 从 `1.1.60` 补同步过来
  （上一版漏了这一步）。

### 1.1.61 — 2026-10-09

**新增 · 柯尔特 1878 教练枪（`colt_1878`）—— 短管并排双管霰弹枪**

- **真实原型**：Colt Model 1878 双管霰弹枪的 **20 英寸教练枪（coach gun）**构型 ——
  全长 940 mm、枪管 610 mm、约 3.4 kg（真实 Cimarron 复刻件数据）。它是西部时代的
  "马路护卫/驿站车夫"用枪：管短、好带、折开装两发。
- **几何全部程序化生成**（`tools/colt_1878_geo.js`）：**并排**双管（不是 S686 的上下双管）、
  两管之间的**焊接肋条 + 前珠**、管口黄铜圈、纺锤前托、下垂托颈、**两个外露击锤**、
  双扳机（前后各一）、机匣顶上一条折开拨杆。498 个面、512² 逐面 UV 图集、全长 **0.93 格**。
- **动画**（`tools/colt_1878_anim.js`）：8 条片段 —— 抬枪 / 射击后坐 / 折开检查 / 有弹换弹 /
  空仓换弹 / 待机 / 抬镜 / 落镜。折开与换弹都按**真机机构**排：拨杆推到位 → 管组绕铰链折下到
  52° 露出两个弹膛 → 退壳 → 两发新弹依次入膛 → 合膛 → 拨杆归位；换弹比 S686 慢（3.0 s / 3.6 s），
  因为教练枪的弹膛短、要塞两发。
- **代码只覆盖差异**：`Colt1878Item extends S686Item`，覆盖动作时长 / 音效时刻表 / 伤害类型
  （`colt_1878_bullet`）/ 准线 / 手感五项 —— 开火、换弹、手臂姿态那一整套逻辑一行都不用抄。
- **僵尸掉落** 0.2% 那一档从六把枪扩到七把；创造模式物品栏同列。
- **僵尸掉落** 0.2% 那一档从六把枪扩到七把；创造模式物品栏同列。
- 门禁 `tools/check_gun_resources.py` 全绿（7 把枪），明细见 `art/colt_1878/`。

**修复 · 残兵（弓手）「走路不对 + 不打人」**

- **根因**：`Zombie.registerGoals()` 已经在 2 号位挂了原版近战 `ZombieAttackGoal`，而
  `GoalSelector` 里同优先级不能抢占（`WrappedGoal.canBeReplacedBy` 要求挑战者号更小），
  所以弓 Goal 挂在 2 号位 = 和原版近战抢 MOVE/LOOK：近战的 navigation 一空就让旗、
  弓一开火又抢回来 —— 实测弓手在 7.5~13 格（弓 Goal 的 strafe 区间）以恒定速度来回踱步，
  16 秒只放 7 箭、靶子掉 0 血。
- **修法**：弓 Goal 提到 **1 号位**（和投掷同源），并补 `canContinueToUse` 覆写 ——
  只改 `canUse` 不够：原版的 `canContinueToUse` 只看「目标还在」，贴脸之后 MOVE 会被它钉死，
  近战出口永远等不到旗子；现在贴到 **3.5 格**以内主动交旗给近战。
- **顺带**：残兵实现 `SightFiring#sightFiringRange()`（此前只有 `MarksmanSkeleton` 实现），
  报最远那件武器即弓的 15 格；否则 `PreyJudge` 对残兵退回「走得到才打」，
  玩家躲塔顶/船上/柱顶时怪站着发呆（表现为「怪物不会攻击」）。两件武器的射程都改成常量
  引用，改射程时同源跟随。
- 工程：`mod_version` `1.1.60` → `1.1.61`。

### 1.1.51 — 2026-10-08

**调整 · 尸潮每波 +15%（复利）**

- 原来每波是**线性**加人数（`4 + 波次×3` / `9 + 波次×5`），后面的波只比第一波长一点，不像升级；
  第一波更是只有 **4–9 只** —— 这就是"数量有点少"的来源。
- 现在改成**每波是上一波的 1.15 倍**（复利），基础人数提到 **10–16**。五波下来：
  `10–16 → 12–18 → 13–21 → 15–24 → 17–28`，中值 13 → 15 → 17 → 19.5 → 22.5，约 +15%/波；
  第 5 波是第 1 波的 **1.75 倍**。公式即 `base × growth^波次`，波数改大时自动跟着走
  （12 波的话第 12 波是第 1 波的 4.65 倍）。
- 新增配置：`horde_base_min` 10 / `horde_base_max` 16 / `horde_wave_growth` 1.15。进化等级的加成
  照旧**叠乘**在这之上，单波 ±15% 的抖动也保留（同一次围城里两波的人数仍不会完全一样）。
  单波硬上限 90 → 120（高配置下的保护，默认参数远够不到）。
- 只动 `HordeManager.rollWaveSize` 一个方法 + `Config` 三个新键。

### 1.1.60 — 2026-10-08

**新增 · 僵尸掉落（压制 crafting-dead + 分档补掉落）＋ 相同物品一键采集**

- **crafting-dead 的僵尸掉落压到 2%**：`craftingdeadsurvival` 那六种僵尸（`weak_zombie` /
  `fast_zombie` / `tank_zombie` / `police_zombie` / `doctor_zombie` / `giant_zombie`）原本必掉，
  现在每次死亡掷一次骰，**没中就整单清掉**。判定用的是**命名空间而不是具体实体类型** ——
  它将来加新变体，这里不用跟着改。反编译它的 `ZombieMixin` 确认过：那个 mixin 管的是
  「水里不转化 / 不在阳光下燃烧 / 幼年体」，掉落走的是标准 `loot_tables/entities/*.json`，
  所以 `LivingDropsEvent` 拦得住、也改得动。
- **僵尸额外分档掉落**（参考 Zombie Apocalypse Core 的思路 —— 食物 / 武器 / 装备 / 工具都要有，
  而不是清一色腐肉；但**用的全是原版物品**，不引入依赖、掉率好读、玩家一眼认得）：

  | 档 | 默认概率 | 内容 |
  |---|---|---|
  | 食物 | 12% | 面包 / 熟牛肉 / 熟鸡肉 / 熟猪排 / 苹果 / 胡萝卜 / 烤土豆 / 曲奇 |
  | 装备 | 6% | 皮革或锁链护甲的一个部件 |
  | 工具 | 5% | 铁锹 / 铁镐 / 铁斧 / 石斧 / 石锹 / 剪刀 / 打火石 |
  | 武器 | 4% | 铁剑 / 石剑 / 木剑 / 弓 / 弩（弓弩附带 4~12 支箭） |
  | 枪械 | **0.2%** | 本模组七把枪之一 —— 枪是稀罕物，不该变成打僵尸的常规产出 |

  五档**独立掷骰**：一只僵尸可能同时掉好几样，也可能什么都不掉。开关与概率全在配置的
  `[zombie_loot]` 段。
- **相同物品一键采集**（默认 **G** 键，可在控制里改）：把**范围内与手上物品相同**的掉落物一次
  收进背包；手上是空的就收范围内全部。**范围（默认 6 格）、单次上限（64）、是否只收同种**
  都在配置的 `[collect]` 段。收集走原版 `Inventory.add` 的语义 —— 塞不下就余在背包外、
  背包满就停下，不会吞东西。服务端重新读配置、重新判定，客户端只是发个请求。

### 1.1.59 — 2026-10-08

**修复 · 十字弩在游戏里散架（cube 级 pivot 漏取反）**

- **现象**：模型散架 —— 各部件位置不对、彼此分开，且**所有场景**都这样（第一人称 / 物品栏 / 地上）。
- **根因**：`tools/crossbow_v1.py` 的写出行 `game_convention_geo()` 取反了**骨级** pivot、
  镜像了 cube 的 `origin`、取反了 cube 的 `rotation` —— **唯独漏了 cube 自己的 `pivot`**。
  于是方块的位置已经镜像了，它**绕以旋转的支点却还停在镜像前的那一侧**：
  421 个带 pivot 的方块里 **372 个**中招（`cam_l`/`cam_r` 各 74/74、`scope` 128/175），
  每个绕一个在身体另一侧的支点转 8.85°~39°，自然各奔东西。注释里那句
  「立方体坐标 / 骨骼 pivot：X 取反」也没提这一档。
- **修法**：`game_convention_geo()` 补 `cube['pivot'] = _neg_axes(cube['pivot'], _NEG_POS)`。
  pivot 是个**点**不是最小角，按普通点镜像即可 —— 不要套 `origin` 那条 `-(x+size)`。
- **范围**：**只有十字弩**。它是唯一「既走这套取反层、又带 cube 级 pivot」的模型；
  awm 339 / s686 202 / uzi 128 / m1 218 / mosin 91 个带 pivot 的方块全部正常。
- **验证**：修复后 421 个方块的支点**全部**落回自身包围盒 ±1.5u 内（修前 195）。
  另外确认左右骨的 `rotation` 本来就是正确镜像的（`cam_l` rot.y 全负 / `cam_r` 全正），
  所以**只动了 pivot 一项**。
- 诊断工具留在 `build/check_crossbow_pivot.js`（可扫全部 geo，查这类镜像漏项）与
  `build/diagnose_crossbow_mirror.js`（`--apply` 才写文件）。细节见
  [`art/crossbow/README.md`](art/crossbow/README.md) §8。

### 1.1.58 — 2026-10-08

**修复 · 放置武装村民导致服务端崩溃（`Can't find attribute minecraft:generic.attack_damage`）**

- **根因**：1.1.56 给武装村民挂的是原版 `MeleeAttackGoal`，而它的攻击路径 `Mob.doHurtTarget`
  第一步就去读 `ATTACK_DAMAGE` 属性 —— **村民的 `createAttributes()` 里没有这个属性**
  （只有移动速度与跟随范围）。`AttributeSupplier.getValue` 找不到属性时直接抛
  `IllegalArgumentException`，于是"放下武装村民 → 服务端 tick 到它 → 崩"。
  崩溃报告里的链条很干净：`MeleeAttackGoal.tick → checkAndPerformAttack → Mob.doHurtTarget
  → LivingEntity.getAttribute → AttributeSupplier.getValue`。
- **修法**：`AttributeMap` 没有公开的"添加属性"接口，没法凭空把 `ATTACK_DAMAGE` 补给村民，
  所以新写了 `entity/ai/VillagerDefendGoal` 自己走一遍 —— 贴到攻击距离直接 `hurt()`，
  伤害值由模组给定（**5.0**，取在铁剑 6 之下：村民是自卫，不该比僵尸更能打）、不经过属性系统，
  再让村民挥手做动作。等价于把原版那个 Goal 里唯一需要属性的一步换掉。
- **教训**：给一个本来不打架的实体挂攻击 Goal 之前，先确认它的 `createAttributes()` 里
  有没有那个 Goal 要读的属性。

### 1.1.57 — 2026-10-08

**新增 · EasyNPC 武器商（配合已装的 Easy NPC 模组）**

- 仓库里加了一份 **EasyNPC 的 NPC 预设**：
  `src/main/resources/data/easy_npc/api/preset/apocalypse_zombies/weapon_merchant.npc.snbt`。
  随 jar 分发，装进游戏后在 EasyNPC 的预设列表里能找到「武器商 Weapon Merchant」，摆下去
  **右键直接开交易界面**。外观是武器匠（大师级），并设了 `Invulnerable` + 掉率 0 ——
  末日里不至于被打死、也不掉一地东西。
- **商品与价格不在这个文件里**，而是存在 NPC 实体上（EasyNPC 的 `TradingDataSet` + 交易表），
  所以配商品是在**游戏内的 EasyNPC 配置界面**里做的，改完还能存成自己的预设复用。
  换句话说这个文件只是起点，真正"可自行修改"的部分在游戏里。
- 配套文档 [`docs/EasyNPC-武器商.md`](docs/EasyNPC-武器商.md)：怎么加商品与改价格、
  本模组六个可卖物品 ID、预设里各字段的含义，以及**本模组没有弹药物品可卖**这件事
  （弹量与弹种都在物品 NBT 里、靠 `R` 键轮盘切换，不消耗背包）。
- **诚实标注**：这份预设是按 EasyNPC 7.14.0 的类结构反推写的（NBT 键取自
  `data.trading.TradingDataSet` 的常量），**没有实机验证**。文档末尾列了两个待确认点。

### 1.1.56 — 2026-10-08

**新增 · 僵尸/骷髅「必中」、武装村民、更强的铁傀儡与敌对生物**

- **僵尸与骷髅 35% 必中**：攻击前按概率把目标的**受击无敌帧清掉**，这一下就不可能被吃掉。
  口径说清楚：原版近战几乎不会真的挥空，"打了没伤害"绝大多数是受击冷却造成的（目标刚挨过一下、
  `invulnerableTime > 10`），所以必中做成"先清冷却"而不是"无视距离硬打"—— 后者会让僵尸隔空揍人。
  判定按 `sure_hit_interval`（默认 10 tick）节流，否则无敌帧等于不存在；且只在骷髅 24 格 /
  其他 6 格内生效，免得远处一只骷髅把玩家的冷却一直清零。
  配置：`sure_hit_chance` 0.35 / `sure_hit_interval` 10。
- **村民 15% 手持武器**：出生时拿到铁剑（掉率设 0，否则村庄会变成剑的产地），并补上原版那套
  `MeleeAttackGoal` + `NearestAttackableTargetGoal` —— 村民本体走 Brain 系统、没有攻击能力，
  所以只能从 Goal 侧补。**持械的村民不再进入 PANIC 逃跑，改为迎战**（`onLivingTick` 里按
  "手里是不是剑"分流）。配置：`villager_arm_chance` 0.15，设 0 即整个功能关闭、村民恢复原样。
- **铁傀儡增强**：移动速度 0.25 → **0.28**、攻击伤害 15 → **18**（另有既有的守卫目标、
  跟随范围 48、击退 2.0）。配置：`golem_speed` / `golem_damage`。
- **敌对生物增强**：追击速度 **×1.1**（`hostile_speed`）。写的是"原版基值 × 倍率"而不是绝对值，
  所以僵尸、骷髅、蜘蛛各自原本的快慢差别还在，只是一起变快。

### 1.1.55 — 2026-10-08

**调整 · S686 换弹提速 25% ＋ 修复爆炸弹「有粒子有声音却掉不了血」**

- **换弹提速 25%**：`reload_tactical` 2.6 s → **1.95 s**、`reload_empty` 3.3 s → **2.475 s**。
  这是**三处同步**改的 —— 动画关键帧（`s686.animation.json`）、动作时长（`RELOAD_*_TICKS`
  52 / 66 → **39 / 50**）、音效时刻表（`RELOAD_*_SOUNDS` 的 tick 全部 ×0.75）。只动其中一处，
  要么片段播到一半被切回 idle（看着像换弹没做完），要么声音与画面错开。契约门禁会**动态对比**
  json 与 Java 常量，所以"三者一致"这次是它验出来的，不是我看的。
  动画的源头脚本 `tools/s686_anim.js` 也补了同一个倍率（`RELOAD_SPEED = 0.75`），否则重新生成动画
  会把加速覆盖回去。
- **修复 · 爆炸弹没有伤害**：根因是**无限递归**。爆炸拿 `player` 当伤害来源（击杀才算在玩家头上），
  于是那一发爆炸伤害又走进同一个 `LivingHurtEvent`、又满足「手里是爆炸弹」、又引爆一次；而
  `detonate` 为了穿透受击冷却会把受害者的 `invulnerableTime` 清 0 —— 恰好把原版靠受击冷却形成的
  那道递归屏障也拆了。栈溢出之后那一发伤害整个作废，表现出来正是玩家报的**有粒子、有爆炸声，
  但目标一点血都不掉**。修法是在 `AmmoEffects` 加一道 `detonating` 闸（服务端单线程，一个静态
  布尔就够），爆炸自身的伤害不再回头触发弹种效果。

### 1.1.54 — 2026-10-08

**调整 · 独头弹爆头倍率单列一档（×4）**

- 普通弹的爆头倍率是 ×2（一片 8 颗小弹丸里有一颗蒙到头顶），独头弹现在**单独一档 ×4**：
  `34 × 4 = 136`，一枪能把绝大多数目标从满血带走，精英和 Boss 也扛不住几发。
- 依据是物理上本来就不是一回事：独头弹是**一颗大铅弹整个打进头里**，普通弹只是"蒙中一颗"。
- 代价不变 —— 独头弹只有这一颗弹丸：打偏是零，打身上只有 34。高风险高回报正是它的定位。
  铝热弹与爆炸弹仍用 ×2。

### 1.1.53 — 2026-10-08

**新增 · 爆炸弹（第四种弹种）+ 轮盘交互修复**

- **爆炸弹**：命中敌对生物时在它身上炸开一小片 —— 半径 **2.5 格**、中心 14 点、向外线性衰减到 0，
  范围内的敌对生物一起挨伤害。**不破坏方块、不点火**（一颗子弹不该改变地形）。直接命中那一下
  刻意做得比普通弹的单颗还轻（**6 点**）：它是**引信**不是弹头，价值全在范围 —— 打僵尸群用它，
  打单个硬目标不如铝热弹划算。
- 与铝热弹同一套路：`GunItem` 的默认弹种列表里多一项（五把枪自动都有），效果落在**一处**
  `LivingHurtEvent`（`event/AmmoEffects`，原来的 `ThermiteRounds` 并了进去）。玩家自己永远不在
  伤害范围内。
- **轮盘交互修复**（三处）：
  1. **打开任意界面 = 放弃，不再误装填** —— 原来按 Esc 想取消，反而会把弹装进去（`screen != null`
     被当成了"松开 R"）。现在只有真的在游戏界面上松手才发包。
  2. **选弹时左键不再走火、右键不再抬镜** —— 轮盘开着的时候鼠标是拿来选弹的。
  3. **死区 10 → 20 像素** —— 小幅抖动不该把选项切走。
- 弹种列表现为：普通 / 独头 / 铝热 / 爆炸（S686 四种，其余枪三种）。

### 1.1.52 — 2026-10-08

**修复 · Q 弹「压扁回弹不明显」—— 是旧配置键把幅度砍到了 1/4**

- 症状：所有生物确实在做果冻律动，但幅度小到几乎看不出压扁。
- 根因：`[squash_stretch]` 的幅度键原来叫 `intensity`，**旧语义是「压扁 25%」的绝对值**，而老配置文件里
  存着 `0.25`；Forge 对**已存在的键会原样保留**，于是它在新语义（幅度倍率）下变成了「只有 1/4 幅度」
  —— 压扁只剩 12.5%，难怪看不出来。曲线与几何量算都没有问题。
- 修法：键名改成 `sway`（默认 1.0），等于让老配置取回新默认值。旧 `intensity` 键留着无害
  （Forge 保留但不读）。默认 `compression` / `width` 本来就是 50 / 50，所以修好后是**压到一半高度、
  涨到一倍半宽**。
- 顺带补上参考实现的第三档「逆时针绕圈」：新键 `orbit_radius`（默认 0.25 格），身体沿一个小圆周走，
  一圈与律动周期同步。它用自己的相位，所以把自转关掉绕圈照样转；位置只作用在渲染矩阵上，
  实体碰撞箱不动。

**新增 · 弹种系统 + R 键轮盘（普通 / 独头 / 铝热）**

- **按住 R 弹轮盘、松开装填**：选项从正上方顺时针排开，光标指哪个高亮哪个；光标移回中心则保持当前
  高亮 —— 所以「按住 R 直接松」装的就是枪上原本那种弹，也就是这次改动之前 R 键的行为，习惯不用改。
  轮盘打开时会**释放鼠标**：不释放的话光标被锁在准心上，玩家根本指不了方向；代价是这几百毫秒转不了
  视角，而那正好是选弹时不该做的事。
- **弹种只记在枪自己的 NBT 里**（`Shell`），**不消耗背包物品** —— 与这套枪原本的弹量设计一致
  （`Ammo` 也是 NBT 计数）。老存档没有这个键，退回普通弹，射击手感不变。
- **普通弹**：S686 上是 12 号鹿弹（8 颗弹丸，近 4 / 中 3 / 远 2），也就是原来那一种。
- **独头弹**（只有霰弹枪有）：1 颗大弹丸，**近 34 / 中 26 / 远 18**，散布收到鹿弹的四分之一。
  贴脸比鹿弹八颗全中的 32 略高，中远距离更耐打（同距离鹿弹是 24 / 16）—— 代价是**只有一次命中
  判定**，打偏就是零。
- **铝热弹（通用，五把枪都能装）**：命中**敌对生物**就把它点着 5 秒（`event/ThermiteRounds`）。
  伤害数值不动，价值在持续灼烧 —— 对高血量目标比多打几发划算。只烧 `Enemy`：打中自己的狗、村民
  或队友都不会点火。
- **「给所有武器加铝热弹」是零逐枪实现的**：弹种读写走 `GunItem` 的三个 default 方法（五把枪共用
  同一个 NBT 键），而「命中点燃」落在**一处** `LivingHurtEvent` 上 —— 五把枪的命中逻辑各不相同
  （S686 逐颗弹丸判定、栓动枪单发 hitscan），但它们最终都会落到一次 `hurt()`，所以那一处就覆盖了
  全部武器，将来新增的枪也自动生效。

**待验证 · S686 右键瞄准时枪与双手整层不显示（未结案，探针已在原位）**

- 现象：**腰射一切正常**，按住右键瞄准时枪和双手都不画，画面只剩原版准心（有实机截图）。
- 已排除：ADS 数值 —— 几何量算给出瞄准时珠心 NDC = (0.00, 0.00)、握把离眼 0.34 格
  （远小于 `GunFrame` 的 SANITY 4.0）；崩溃 —— 日志里没有本模组的堆栈；`WeaponHandGrip.apply`
  的 vanilla 分支 —— `S686Item.use` 只 `pass`，不会进入 using 状态；`GunPose.matrix` 四个重载 ——
  4 参数版只是转发给 5 参数版，位移 / 反向旋转 / hip 旋转各项与量算链条逐条吻合。
- "腰射正常"这一条已经排除掉"渲染链根本没跑"，所以只剩两种可能：链子被某个分支掐断，或矩阵把枪
  推出了画面。为此在 `ClientEvents.onRenderHand` 留了探针 `DIAG_AIM`（**默认 false**，与
  `WeaponArms` 的 `ARMSDBG` 同一条规矩：留在原地备用、平时不写日志）。打开后每秒打一行
  `[瞄准调试] …`，看 `gripApplied` 就能一次分开这两种病因。

**工程**：`mod_version` `1.1.51` → `1.1.52`。本版的三批改动是在 1.1.51 的包发出去之后才陆续进 jar 的
（Q 弹幅度修复 → 弹种系统与轮盘 → 瞄准的防御修复），所以按历史归到这个版本段下；1.1.51 段只留尸潮那一条。
新增 4 个类（`item/AmmoType`、`event/ThermiteRounds`、`client/weapon/AmmoWheel`，以及 `GunItem` 的三个
default 方法），替换 `F:\.minecraft\versions\1.20.1-Forge_47.4.26\mods\` 里的旧包。

### 1.1.50 — 2026-10-08

**新增枪械 · 金板 S686（折开式双管霰弹枪）＋ 全生物 Q 弹（压扁回弹旋转）**

**新增枪械 · 注册名 `s686`：上下双管折开式，2 发 × 每发 8 颗弹丸、1 秒一发、铁瞄**

- **几何 / 贴图 / 动画**（本次到货，非代码改动）：25 骨 / 281 块 / 512² 贴图，8 条片段全裸名
  （`static_idle` / `draw` / `shoot` / `bolt` / `reload_tactical` / `reload_empty` / `ADS_up` / `ADS_down`）。
  **没有 `shoot_auto`** —— 折开式双管没有全自动，Java 侧也就不声明连发那一组常量。
- **接线**（照 `uzi` 的全套结构）：新增 `S686Item` / `S686GeoModel` / `S686ItemRenderer` /
  `models/item/s686.json` / `damage_type/s686_bullet.json`；`ModItems` 注册并进战斗页签；`WeaponArms`
  加渲染分支与 `forgetFrames` 回收（漏后者的表现是「枪能动但没手」）；两套 lang、枪械表同步。
  音效走 AWM 那套 id（`ModSounds` 与 `sounds.json` 零改动，不新增音效键）。
- **量算，不是眼估**：本机没有 python，`tools/pose_measure.py` 与 `tools/uzi_tp_solve.py` 两条链在
  `build/s686_pose_solve.js` 里做了 Node 逐行移植并先过标定 —— Uzi 的 `ADS` 复现到 1.1e-5、第三人称
  四常量复现到 4.3e-4，M1 的 `ADS` 复现到 4.4e-4（它源码只存到 3 位小数），对得上才允许拿它算新枪。
  瞄具线取**前准星珠心**（`fs_bead` 圆心 y=0.300 / z=−9.60；**折开式没有后照门**，全枪唯一的瞄具就是
  这颗珠，所以锚点必须是它 —— 初版误用了肋条顶面 y=0.175，珠子会浮在屏幕中心上方）：
  `ADS_X = −0.4749` / `ADS_Y = +0.3533`，抵消 display 旋转后夹角 **0.00°**、残差 4.2e-5；
  第三人称 `TP_X_RIGHT / TP_X_LEFT / TP_Y / TP_Z = −0.608 / −0.392 / 0.618 / −0.591`，
  自检 `TP_X_RIGHT − TP_X_LEFT = 2·(1/16)/S` 差为 0。
- **display 块按长度插值**：19.50u 夹在 M1（17.63u）与莫辛（22.90u）之间，各 scale 取两者的线性混合
  （第一人称 0.80、第三人称 0.58、GUI **0.36** / 地面 0.27 / 物品框 0.37 / 头盔 0.53）；第一人称
  `translation` 的 y 由量算定（+0.6px）—— 那是把腰射握把 NDC 从 −1.61（出画）抬进画面的值。
  GUI 缩放发布前从 0.31 上调到 0.36：物品栏里的显示长度 = 枪长 × scale，0.31 只有 6.10u 偏小，
  0.36 是 7.08u，落在 AWM（7.20）与莫辛（6.87）之间，与其它长枪的栏内观感齐平。
- **机制**：每扣一次扳机消耗 1 发、射出 8 颗弹丸（锥面内均匀采样，每颗独立判定、独立分级伤害、
  都不穿透身体）；射击间隔 20 ticks。潜行扣扳机 = 双管齐射（2 发 / 16 颗），沿用同一条 `shoot` 片段，
  **不新增动画**。空膛扣扳机跑 `bolt`（折开检查再合上，26 ticks）。换弹按膛内还有没有实弹分流：
  `reload_tactical` 52t / `reload_empty` 66t，都在片段结束时补满 2 发。
- **手的目标**：右手始终握枪颈（开膛的上顶杆就在这只手拇指下，开枪的手不离开枪）；
  左手扶着前护木，而护木是 `barrel` 骨的孩子 ⇒ **折开由活骨带着手走**（`GunFrame.partChain`，
  与 1.1.49 的拉栓手柄同一条规矩），Java 里不复刻折叠曲线；上弹那一段手挂在上弹壳骨上被带着入膛。
- **验收**：编译 **0 错误 0 警告**（132 个 class，含 `S686Item` / `S686GeoModel` / `S686ItemRenderer`）。
  口径说明：本会话的文件沙箱不让 Gradle 起 build daemon（fork JVM 走管道被拒，`gradlew compileJava` 一律
  停在 `A problem occurred starting process 'Gradle build daemon'`），所以改用**同一份 sourceSet**
  （`build.gradle:118` 排除 `**/*_bytes.java`）+ **同一套依赖 jar** 直接 `javac`，脚本与日志留在
  `build/run_javac_s686.bat` / `build/javac_s686.log`；放宽沙箱后仍应补跑一次真正的 `gradlew build`。
  `tools/check_gun_resources.py` 会卡的那几条硬契约（本机无 python 跑不了该脚本）由
  `build/check_s686_contract.js` 逐条等价复刻核对 —— ANIM_/TRIGGER_ 常量 ↔ 8 条片段名、
  5 个 `*_TICKS` ↔ `ceil(animation_length × 20)`、`DISPLAY_PITCH/YAW` ↔ `models/item/s686.json` 的
  `firstperson_righthand.rotation`（且 roll = 0、左右手同值）、`ADS_X/ADS_Y` 区间且与量算值一致
  （残差 8e-6）、伤害类型 id 与 `message_id`、贴图 512²、`WeaponArms` 里确有 S686 分支、
  音效未新增键 —— 15 组检查全过。

**同时新增 · 全生物 Q 弹（压扁 → 回弹 → 绕竖直轴自转），纯客户端**

**曲线与幅度是照「朋友的酒」(friendswine) 的果冻效果做的** —— 拆开那个 jar 读了它的
`JellyAnimation` 与 `DollRenderer.applyAnimation` 才把下面三点定下来，而不是凭空调参：

- **它是怎么做的**：`squash = smoothstep 关键帧`（周期 **0.91667 s**，一个周期里压扁量走
  `0 → 1 → 0 → 1 → 0`，每段用 `3t² − 2t³` 插值 —— 所以每一下都是「弹到位再停住」，不是匀速晃）；
  形变是 `scale(1 + width·s, 1 − compression·s, **1**)`；自转绕 **Y 轴**、一个周期 −360°。
- **Z 轴不缩放**：只压宽度与高度。这是**正面压扁**，不是体积守恒的压扁；配合自转，形变方向跟着转，
  正面看始终是标准的卡通 squash。照抄这一条（而不是 XZ 一起鼓）是观感对上的关键。
- **锚点在脚底**：钩子触发时 PoseStack 的原点正落在脚底，所以直接 `scale` 就是绕脚底压 ——
  不需要「抬到身体中心再落回」那层三明治，也不会把怪压进地里。
- **两层叠加**：主体是**持续律动**（所有生物一直踩着同一个节拍做果冻）；在这之上，受伤 / 落地 /
  被击退再叠一次更狠的冲击（阻尼余弦，t=0 必定压到最深），**谁更狠听谁的**。
- **两条渲染钩子，少一条就静默漏一半**：`RenderLivingEvent.Pre/Post` 覆盖原版与本模组内走人形
  渲染器的生物，`GeoRenderEvent.Entity.Pre/Post` 覆盖 GeckoLib 生物 —— `GeoEntityRenderer` 自己重写
  `render` 且不调 `super`，**根本不发布** `RenderLivingEvent`，只挂一条会漏掉骸骨射手 / 美女僵尸 /
  士兵僵尸 / 尸潮之主四只（而且不报错）。两条链的实体集合不相交，不会双重形变。
  （参考实现是 mixin 到 `EntityRenderDispatcher.render`；本仓库零 mixin 配置，用这两条 Forge 事件
  拿到同样的时机。）
- **受伤信号用血量，不用 `hurtTime`（踩过的坑）**：初版读的是 `LivingEntity.hurtTime`，结果**一次都没
  触发**。翻 1.20.1 源码才看清：受伤动画走 `ClientboundHurtAnimationPacket`，而构造那个包的地方
  **只有 `ServerPlayer` 一处**（它只把「自己被打」发给自己）—— 除玩家本人，**任何生物的 `hurtTime`
  在客户端永远是 0**。血量走 `SynchedEntityData`，才是对所有生物同步的那个量。
- **玩家显式排除**：`PlayerRenderer.render` 会先 post `RenderPlayerEvent` 再调 `super.render`
  （内部又 post `RenderLivingEvent`），两边都做就是双倍形变；本需求只说「生物」。
- **push/pop 严格配对**：`RenderLivingEvent.Pre` 可被别的模组取消，而官方注释明确「Pre 被取消则
  Post 不触发」—— 所以用「本帧确实 push 过」的集合兜底，而不是带条件的 push 配无条件 pop。
- **配置**：`config/apocalypse_zombies-common.toml` 的 `[squash_stretch]` 段 —— `enabled`（默认开）/
  `intensity`（律动幅度倍率，1.0）/ `compression` 50 / `width` 50 / `rotate`（默认开）/
  `spin_speed` 1.0 / `wobble_frequency` 13 / `damping` 3。只在客户端读，与 `AI_GIANT_ARROW_SCALE`
  同一条先例，不需要同步包。
- **增删**：新增 `client/anim/SquashStretch.java`、`client/SquashStretchEvents.java`，改 `Config.java`。
**顺手修 · 双手持枪时不再画副手物品（第一人称）**

- 六把枪都是双手握持，而左手是 `WeaponArms` 自己画的那一只 —— 原版副手那一路再画一次，物品就会从
  **同一只手的中间**穿出来（火把 / 盾牌斜插在护木上）。现在只要主手是我们任意一把枪，
  `RenderHandEvent` 的**副手整层**（物品连同手臂）都被取消。
- 原逻辑只在「光学瞄具抬镜过半、镜头占满画面」时取消副手；那条规则保留，因为对 AWM 那类枪它更极端。
- 只动 `ClientEvents.onRenderHand` 里的一处判断。第三人称不受影响 —— 那里的副手物品由原版的手持层画，
  与枪的骨骼模型不共享手部，不会穿模。

**新增 · S686 与莫辛纳甘的「回身取弹」手部动作**

- 这两把是**非弹匣**装填：S686 折开后往膛里塞两发霰弹，莫辛往固定五发弹仓里压弹。原来手虽然会移到
  弹膛 / 机匣上，却是**从枪上直接过去**的 —— 全程没离开枪，弹药看起来像凭空出现。
- 现在换弹时序里多了一段**回身取弹**：手先离开枪、下探到腰间的弹带 / 弹袋（新锚点 `AMMO`），
  停一拍表示抓住弹药，再带它回到枪上装填，最后回护木 / 枪颈。
- `AMMO` 是这两把枪里**唯一不挂部件链**的手部目标：手伸向的是**玩家自己的身体**，不是折开的枪管
  （S686）也不是枪机（莫辛），跟着部件转就错了。它只走枪的整体姿态链，所以人晃动时弹带跟着晃。
- S686 让**左手**去取（右手始终握着枪颈 —— 开膛的上顶杆就在这只手的拇指下）；
  莫辛让**右手**去取（枪夹在肩上、左手扶着护木，这本来就是莫辛装填的样子）。
- 时间窗按各自 clip 的关键帧排：S686 是「折开之后、新弹入膛之前」，莫辛是 `BOLT_PICKUP_*`（0.86 / 0.88）之前。
- 只改 `client/model/S686GeoModel.java` 与 `MosinNagantGeoModel.java` 的手部目标与两段 ramp；
  其余四把（弹匣类：AWM / M1 / Uzi / 十字弩）不动 —— 它们的手本来就跟着弹匣骨走。

**同时新增 · 「朋友的酒」常驻背景音乐（客户端）**

- **就是循环放**：进世界起一首、一直放到离开世界。不挑场景（白天 / 夜晚 / 血月 / 洞穴都一样）。
  循环**不交给 OpenAL**：音频是 `stream: true` 的流式音源，而 `AL_LOOPING` 只对「整段一次性入队」
  的缓冲有效，流式音源是边解边喂 buffer，到曲末那条路不一定接得上。所以改用原版 `MusicManager`
  用了几十年的办法 —— 每 tick 查一次 `SoundManager#isActive`，播放结束就重新起一首。
  代价只是曲末到重播之间最多一个 tick（50 ms），换来的是「一定会循环」。
- **音频**：`assets/apocalypse_zombies/sounds/music/friends_wine.ogg` —— Ogg Vorbis、44.1 kHz 立体声、
  128 kbps、约 5.7 分钟；`sounds.json` 里标 `"stream": true`。长音频必须流式解码，否则整曲一次性进内存。
- **怎么接管原版音乐**：Forge 1.20.1 **没有** `SelectMusicEvent`（那是更高版本才有的 API），
  没有「把场景音乐换成我的」这条正规途径，于是反过来做 —— 只要我们的音乐在放，就每 tick 调一次
  `MusicManager#stopPlaying()` 让原版让位。这个调用是幂等的（没有正在播的音乐时什么都不做），
  原版自己在没有音乐时也一直在做同一件事，所以反复调用无副作用。开关 `suppress_vanilla`，
  关掉就会听到两首叠在一起。
- **尊重玩家设置**：音源用 `SoundSource.MUSIC`，玩家的「音乐」滑块照常生效；mod 侧的 `volume`
  是**乘子**而不是替代（滑块拉到 0 时直接停播，省掉流式解码）。
- **配置**：`config/apocalypse_zombies-common.toml` 的 `[friends_wine_music]` 段 ——
  `enabled`（默认开）/ `volume`（1.0）/ `suppress_vanilla`（true）。纯客户端，服务端不读。
- **增删**：新增 `client/music/FriendsWineMusic.java`；`ModSounds` 加一个 `MUSIC_FRIENDS_WINE`；
  `sounds.json` 加第一条 `"category": "music"` 的条目。
- **分发口径（重要）**：`build.gradle` 的 `borrowedEntries` 目前是**整目录**排除
  `assets/apocalypse_zombies/sounds/**` 与 `sounds.json`（为了剥掉 TaCZ 的 AWM 录音），
  所以 `cleanJar` 出来的纯净包里**也没有**这首音乐 —— 连 `ammo_clip_pop` 那类原创音效同样没有，
  它们共用同一个 `sounds.json`。它随开发/自用包分发。要让纯净包也带上原创音频，得把排除项收窄成
  `sounds/awm/**`，并把 `sounds.json` 按来源拆成两份。

- **工程**：`mod_version` `1.1.49` → `1.1.50`；根 `mod.toml` 顺带补上（它此前停在 `1.1.45`）；
  三个新类（S686 三件套 + Q 弹两件套 + 音乐控制器）、S686 资源与这首音乐一并进 jar，
  替换 `F:\.minecraft\versions\1.20.1-Forge_47.4.26\mods\` 里的旧包。

### 1.1.49 — 2026-09-30

**修复 · 莫辛-纳甘与 AWM 拉栓穿模：栓柄改成往上抬，手改为随活骨柄心**

- **根因（几何，不是手感）**：栓柄在模型的 **−X 侧**（莫辛 handle 三块在 x −0.68…−0.30；AWM 球头 x −1.50…−1.26），
  而第一人称相机在 +Z 侧朝 −Z 看 ⇒ 屏幕右 = 模型 +X。绕 +Z **正向**旋转把 −X 侧的点往下压
  （`y' = x·sinθ < 0`）—— 柄被压进枪托/机匣里就是看到的穿模，而 Java 给手的目标还在柄的原位上方，
  于是手也「没握住」。生成器里原来的注释写着「手柄在 +X，正向旋转抬柄」，前提就是错的。
  真机提柄是**上抬**，所以 `bolt.rotation.z` 必须取负。
- **改动**：莫辛 4 段（`bolt` 80° / `inspect` 42° / 两段换弹 80°）与 AWM 5 段（`bolt` / `inspect` /
  `inspect_empty` / `reload_empty` / `static_bolt_caught`，均 60°）的提柄角全部取负；角度、后拉行程
  （莫辛 1.55px / AWM 1.932px）与时长一字未动，`art/` 与 `src/` 两份同步，生成器（`mosin_nagant_bb_anim.js`
  / `awm_bb_anim.js`）里的字面量与错误注释一并改掉。工具：`tools/bolt_lift_sign.py`（`--check` 已成门禁）。
- **手改为「读活的栓骨矩阵」**：原来 Java 在 `rightHand` 里复刻剪辑曲线（莫辛用 `BOLT_TRAVEL` 常量推、
  AWM 的目标点比柄头还靠后 0.6px），曲线一改手就飘。现在 `GunFrame` 记录栓骨本帧的链路
  （`GunFrame.partChain`，从 `bolt` 到 `move` 之前）+ 它的旋转/后拉，手的目标 = **柄头原点经这条链变换后的位置**
  （`frame.boltGrip(BOLT_KNOB, …)`）⇒ 手和柄是同一份数据，构造上不可能对不上。
  `BOLT_KNOB` 取 geo 里柄头方块的中心（莫辛 `{-0.62,1.93,-2.05}`、AWM `{-1.36,1.80,0.84}`），门禁逐条比对。
- **什么时候上手**：`handleHold` 读**活栓**的偏移量（`boltActivity`：转角/行程相对片段的极值取大者），
  栓离位就一直握着（值恰为 1），回位自然松手；只有两端用 `HandMotion.ease`（τ=0.06 s，按客户端帧时间
  推进，与帧率无关）做过渡。换弹片段在剪辑自己开始收栓的前一拍（莫辛 0.88 / 0.86、AWM 0.64）交棒 ——
  这些常数由 `check_bolt_grip.py` 对着剪辑的键复核。
- **实测证据**（`tools/check_bolt_grip.py`，按 GeckoLib 4.8.4 的真实约定逐帧算几何）：

  | | 修复前 | 修复后 |
  |---|---|---|
  | 莫辛 `bolt` 柄心抬升 | **−0.759 px**（压下去） | **+0.462 px**（上抬） |
  | AWM `bolt` 柄心抬升 | **−0.789 px** | **+0.839 px** |
  | 莫辛 柄头 vs 枪托（全片段最大互嵌） | **16.42 mm** | **0.00 mm** |
  | AWM 柄头（全片段最大互嵌） | 6.87 mm | **0.00 mm** |
  | `BOLT_KNOB` ↔ geo 柄头中心 | — | 差 0.004 px（莫辛）/ 0.060 px（AWM） |

  整根柄（含插进机匣侧壁的柄杆根部，焊接式建模、画面上看不见）另有 ≤1.7 mm（莫辛）/ 10.0 mm（AWM，
  低于它静止姿态本身就有的 14.4 mm 底噪）的互嵌，属 1.1.48 之前就有的建模取舍，本版未改几何。
- **工程**：`mod_version` `1.1.48` → `1.1.49`；改动前的剪辑留档 `art/*/x.animation.pre-lift.bak.json`
  （门禁用它做「修复前/后」对照）。三个新工具：`tools/bolt_lift_sign.py`（矫正 + 门禁）、
  `tools/check_bolt_grip.py`（几何门禁）、`tools/_deploy_149.py`（出货，内含前两者的自检）。
  AWM 的 `inspect` / `inspect_empty` / `static_bolt_caught` 三段只在 bbmodel 里（`art/awm/awm.bbmodel`
  没有动画数据、`awm_anim_export.py` 是纯转换器）⇒ **重新导出后必须再跑一次 `bolt_lift_sign.py`**，
  详见 `art/awm/README.md`。

### 1.1.48 — 2026-09-30

**替换 · AWM 几何与贴图换代（源：`F:/apt/9217/awm.geo.bbmodel`）**

- **几何**：从 Blockbench 现工程导出（bedrock 1.12.0，identifier `geometry.awm`），**417 方块 / 25 骨**（旧 435 / 25）。
  **逐骨包围盒与 pivot 与旧版逐条相同**（root `(0,-1.07,1.3)`、bolt `(-0.42,1.85,1.45)`、scope `(0,3.15,-1.2)`、
  magazine `(0,1,-1.45)`、枪口仍在 `z=-18.02`）—— 变的是**内部分块与 UV 划分**，不是枪的尺寸。
  所以 10 段动画、Java 挂点（`BOLT_TRAVEL` / `MAG_DROP` / 第一人称四个锚点）与姿态链**全部不动**。
- **去掉模型里烘焙的手 / 臂网格**：`lefthand` 7 块 → 0、`righthand` 8 块 → 1。这两根骨 Java 从不驱动、
  动画也不涉及（动画只动 `mag_spare`），旧版是 TaCZ 原模型自带的手，删掉后画面里不再有"模型自己的手"
  与玩家手臂同时出现。`mag_spare`（枪托上的备用匣）由 6 块整匣改为 2 块薄片，跟随动画照常。
- **贴图**：512² 图集重画（与旧图 **50.9% 像素不同**）。2502 个面 UV 全部落在涂绘区（空白 **0**，
  `check_gun_resources.py` 核），**不需要**再跑 `awm_tex_fill.py`（旧图的 1549 个空白面问题在新图里不存在）。
- **工程**：`mod_version` `1.1.47` → `1.1.48`；旧几何 / 贴图 / 工程留档
  `art/awm/awm.geo.pre-9217.bak.json`、`awm.pre-9217.bak.png`、`awm.pre-9217.bak.bbmodel`。
  **几何真相源改为 `art/awm/awm.bbmodel`（9217 工程）**，`tools/awm_bb_gen.js` 退为历史 —— 理由与取舍见 `art/awm/README.md` 的「换代」一节。
- 门禁：`check_gun_resources.py`（5 把枪全绿）、`check_awm_anim.py`（契约 / Java 契约 / 保真 / 落点 / 音效 / 纯净版契约 六项全绿）**未改一行**即通过。

**调整 · M1 加兰德末发与「井盖」按真机重做（甲：手部 + 剪辑；乙：动几何）**

真机依据 FM 23-5《M1 步枪操作手册》+ 美陆军 TACOM 2013 换弹教学 + 真机拆件表（详见
`art/m1garand/README.md` 的「v7（2026-09-30）甲 + 乙」一节）：

- **末发单独成一拍（甲）**：新增 `shoot_last`（1.2 s）—— 导气杆退到底即被挂机爪咬住**不回位**、
  空漏夹在**这一拍当场**被抛夹弹簧顶出井口（那声「叮」）。原来这两件事都塞在按 R 之后的
  `reload_empty` 里（真机上它们发生在最后一发击发的瞬间）。`reload_empty` 因此改成**起手即挂机**
  （不再重复拉一次到底），只把新夹压下去、让枪机自行前冲闭锁。Java 侧 `tryFire` 在最后一发改排
  `ACTION_SHOOT_LAST`（独立锁窗 24 ticks 与音效表 `SHOOT_LAST_SOUNDS`），自动换弹的判据从
  「动作已清空」改为 `shotLapsed()`：射击剪辑一播完**同一 tick**交棒 —— 否则闲置姿态会把导气杆
  收回闭锁位，枪机在两次剪辑之间会闪一下闭锁再开。
- **删掉漏夹井盖（乙）**：真机机匣顶部没有这件东西（手册："place a full clip … press the clip
  straight down into the receiver until it catches"，全程没有"打开盖"这一步；拆件表里也查不到）。
  旧几何里那两条轨把井口从 |x| < 0.190 收窄到 |x| < 0.100，而漏夹宽 ±0.167 ⇒ 旧动画必须抬盖
  **0.55u（34mm）** 才塞得进夹，且"盖合"时轨的内面正好扎进漏夹里（穿模）。现由
  `tools/m1_cover_removal_geo.py` 删掉 `cover` 骨（3 方块：两条轨 + 一根横在井口正中的提手）
  并同步清掉 8 个剪辑里的 `cover` 通道：骨 15 → 14、方块 347 → 344，井口净宽 0.190u
  （漏夹两侧余量 1.4mm）、压夹通道无遮挡。
- **双手（第一人称）**：空仓换弹右手**不再去拉导气杆**（枪机已挂住），直接取新夹压下、落位（0.4306）
  后向右上甩开让开枪机再收回握把；战术换弹左手离开护木、掌根贴机匣左侧、**拇指在 0.112 同步按下
  卡榫销**并按住到销子回位（TACOM："Place the palm of the left hand over the receiver and depress
  the clip latch with the left thumb"）。
- **门禁**：`check_m1_reload.py` 新增末发（挂机不回位 / 空夹当场飞走 / 先挂机再抛夹 / 1.2 s 时长契约）、
  乙案（无 `cover` 骨、机匣顶面以上井口通道无遮挡、所有剪辑无 `cover` 通道）与甲案（左手按销时刻
  对齐 `clip_latch`、右手压夹后甩开、末发接线、同一 tick 接上自动换弹）共 16 条断言，全绿；
  `check_gun_resources.py` 与 `check_awm_anim.py` **未改一行**即通过。

### 1.1.47 — 2026-09-30

**调整 · M1 加兰德换弹按真机重做（抽手空档 / 卡榫 / 全行程 / 单发补弹）**

- **空仓换弹**：新漏夹压到位后枪机不再立刻前冲，留 4 帧给手撤离（原来落位后只隔 2 帧就释放），
  掌根拍到位随之到 1.75 s；「叮」对齐**空漏夹脱离井口、起飞那一瞬**（0.55 s），
  不是它飞到最高点的时候（0.96 s）。
- **战术换弹（半满）**：补上膛内那颗活弹被抛出（原来只有拉栓、没有抛壳）；按真机机构做 ——
  拉到底并**保持按住**（松手残夹会掉），左手按机匣**左侧**的漏夹卡榫销（新增骨骼 `clip_latch`），
  残夹脱出之后才压新夹。
- **行程**：枪机 / 导气杆 69 mm → **85 mm**（= .30-06 全弹长），要退过漏夹里最后一发的底缘；
  几何不用改（实测余量 0.85u），第一人称的手跟着手柄一起走。
- **新增单发补弹**（手册 "To load a single round"，**Shift + R**）：拉到底抛掉膛内活弹 → 手送一发射入 →
  扶着机柄可控闭锁（不是自由前冲）；**余弹 +1**，不动漏夹 —— 半满漏夹下唯一能补弹的办法。
- **工程**：`mod_version` `1.1.46` → `1.1.47`；真源 `_anim_raw.json` 与生成器同步改（导出链**逐字节同构**，
  diff 只剩真实改动）；门禁 `check_m1_reload.py` 新增几何余量 / 卡榫机构 / `single_load` 三组断言。

### 1.1.46 — 2026-09-30

**修复 · 尸潮之主「没有第 3 阶段」—— 是技能轮转被一个死槽位锁死，不是阶段机坏了；顺带追加 4 个技能**

- **症状**：把 Boss 打进第 3 阶段（血量 ≤ 1400）后，它**站在原地一招不放**，跟第 1 阶段判若两怪；
  退出重进、换武器、远近都试过，依旧不动 —— 看起来像「第 3 阶段根本没实现」。
- **根因**：阶段机没问题，`ROTATION_PHASE_3` 的第 4 格是 `BONE_VOLLEY`（骨矢齐射），起手门槛是
  「目标 ≥ 4 格」；而打近战 Boss 的唯一办法就是贴脸 ⇒ 这一格永远起不了手。轮转索引**只在技能结束时**
  才前进，于是整张表停在这个槽位上永久空转。实测：无甲铁傀儡 3604 血、贴到 1.5 格，Boss 停在
  `rot=3/5 cast=NONE` 空转 10 秒以上，之后 60 秒再没出过任何一招（旧缺陷 8~12 秒且**永不恢复**）。
- **修法**（三处，都在共享层，别的精英跟着受益）：
  1. `EliteAbilityDriver` 新增「干等上限 → 换槽」兜底：累积「空闲且起不了手」的 tick，到上限回调
     `Hooks.onStarved()`（默认 40t = 2s），子类在这一步把够不着的槽位跳过去，而不是死等它。
  2. `onEnd()` 改为把**刚播完的那一招**传进来（`onEnd(finished)`）：原来只看 `entryAbility != NONE`
     就清空，会吞掉「挂起等机会」的入场技（血怒可能整段消失）。
  3. `HordeOverlord.ability()` 只在入场技真的起手时才插队（否则它自己挡住轮转）；`castDeathWail()` 的
     `removeAllEffects()` 改成**只清负面效果** —— 亡语在第 3 阶段是可轮转槽位，每轮一次会把血怒的
     4 条 buff 抹光（玩家看到的就是「第 3 阶段打着打着变回一只大僵尸」）。
- **追加 4 个技能**（`EliteAbility` 只能末尾追加，`byId` 走 ordinal）：

  | 技能 | 阶段 | 效果 |
  |---|---|---|
  | `CAGE_SLAM` 尸笼坠击 | 2+ | 正前方 9×5 格直线 18 伤害 + 减速 + 沿直线钉 6 根骨刺 |
  | `PLAGUE_MIST` 疫雾 | 2+ | 脚下铺一团 8 秒毒雾 —— 僵尸对中毒免疫 ⇒ 只伤活人 |
  | `SOUL_DRAIN` 汲魂 | 3 | 10 格内每个活体抽 7 点 + 虚弱，按 1.5× 反哺自身（单次上限 240） |
  | `HORDE_SCREECH` 尸潮尖啸 | 3 | 16 格击退 + 8 秒失明 + 当场再召 3 只 |

  轮转表 Phase 2 由 4 槽 → **5 槽**，Phase 3 由 5 槽 → **9 槽**；Boss 动画 8 段 → **12 段**
  （全部骨骼驱动、零 scale 通道）。
- **实测**（headless 专用服务端 + RCON，铁证探针 `tools/rcon_boss_probe.py`）：贴脸第 3 阶段采样 90 秒，
  **8 招全部放出**；`starved` 涨到 3 ⇒ 换槽这条路真的走过；最长空窗 3.5 秒 = 「技能间隔 24t + 干等上限 40t +
  采样 0.5s」的理论最坏值。副作用逐条对表：傀儡依次吃到 weakness / blindness / poison / slowness / wither，
  骨刺 6 根、雾团 1 个、僵尸数涨到 11，**Boss 血量在无外因下三次自增**（汲魂 1.5× 反哺）。
  跨 630 亡语线：`wail=true` → `entry=DEATH_WAIL` 被消费 → 傀儡吃 wither，**血怒 4 条 buff 仍在**。
  回归：`tools/rcon_marksman_test.py` **5/5 PASS**（共享驱动器的改动没伤到射手线）。
- **调试出口**：`/apocalypse boss` 念出阶段机私有状态（`phase / cast@tick / entry / rot / rage / wail /
  starved`）—— 这些全是服务端私有状态、没有 NBT 可读，headless 探针只能靠它取证。
- **工程**：`mod_version` `1.1.45` → `1.1.46`；`geo` 与贴图逐字节未变（本版不碰模型，只改动画与 AI）。

### 1.1.45 — 2026-09-30

**新增 · 远程怪可 opt-in「看得见就能打」——骸骨射手不再对柱顶/塔上的目标一箭不放**

- **症状**：目标只要比射手高一格以上（柱顶、塔上、城墙边），射手**45 秒一箭不放** —— 不举弓、不移动，
  看起来像 AI 卡死。
- **根因**：`MobAiEnhanced` 是全局事件钩子，给所有 `Monster` 挂了 `PreyTargetGoal`；它只在「走得到」时
  （`PreyJudge.canPathTo`，高度容差 1 格）才认这个猎物，够不着的猎物让它空转占住 TARGET 标志 ⇒
  排在后面的玩家/铁傀儡目标永远起不来，`getTarget()` 恒 null。远程怪本不需要走过去 —— 有视线就该开火。
- **修法**：新增实体级 opt-in 接口 `SightFiring`（`double sightFiringRange()`，≤0 = 不启用）；
  `PreyJudge.usable` 判序改为 `inRange` → 贴脸(3 格) → **看得见就能打** → `reachable`。
  只有实现了该接口的怪才放宽，近战怪零影响（爆炸半径 = 「谁实现谁才算」）。
- **同源约束**：`MarksmanSkeleton.sightFiringRange()` 取三件武器射程的最大值
  （`GIANT_ARROW_MAX_RANGE=32` / `LOCK_MAX_RANGE=26` / `BOW_RANGE=24`），**必须与武器入参同一批常量** ——
  报小了退回死锁、报大了锁上打不到的目标。`check_marksman.py` 的 c6 钉住四条不变量
  （实现接口 / 接口存在 / 判序带 `instanceof` 守卫 / 射程同源），并做了负向双向验证（抠守卫、颠倒判序都必红）。
- **实测**（headless 专用服务端 + RCON，同一条判据**先红后绿**）：柱高 3 格、柱顶站无甲铁傀儡 ——
  修前 **45 秒一箭不放**，修后 **1.8 秒**射出骨矢；`tools/rcon_marksman_test.py` **5/5 PASS**（原 4 条 + 柱顶靶一条）。
- **工程**：`mod_version` `1.1.44` → `1.1.45`（`gradle.properties` 仍是唯一来源，`mod.toml` 与 README 跟着走）。

### 1.1.44 — 2026-09-30

**骸骨射手换 GeckoLib 真骨骼 + 新技能「骨矢锁定」**（本版更新日志当时漏记，在此补上）

- **模型**：`marksman_skeleton` 从原版 `SkeletonModel` 换成 GeckoLib 真骨骼 —— 27 骨 / 33 体块 / 198 面，
  贴图 128×128（斗篷 + 骨弓 + 箭袋），总高 32 u = **2.0 格**（与原版骷髅一致 ⇒ 命中箱不漂移）。
  渲染换成 `MarksmanGeoModel` / `MarksmanGeoRenderer`，原版那对已删。
- **技能「骨矢锁定」**：`EliteAbility` **末尾追加** `BONE_LOCK(42, 34)`（`byId` 走 ordinal，插中间会让所有
  精英的施法状态错位）；前摇 26 tick 站定 + 粒子，命中瞬发追踪骨矢，伤害 = **目标最大血量 × 25%**
  且无视护甲 / 附魔 / 抗性 / 盾牌。
- **无敌帧**：1.20.1 的 `LivingEntity.hurt()` 在 `invulnerableTime > 10` 时只结算「本次 − 上次」的差额，
  这个分支没有任何 `DamageTypeTags` 能跳过（`bypasses_invulnerability` 管的是实体标志，
  `bypasses_cooldown` 是 1.20.5+ 才有）。修法：`BoneLockArrow.onHitEntity` 先 `target.invulnerableTime = 0;`
  再结算，实测单发由 24.0 变成 **25.0**。
- **实测**（headless + RCON，**4/4 PASS**）：满防具 + 抗性 V 的铁傀儡打 25 点 `bone_lock` 掉 **25.0**；
  对照组同样 25 点 `minecraft:generic` 掉 **0.0**；目标 10 格外射手自行起手并射出骨矢。
- 发布件仍是 `-clean.jar`（动画为完全原创的手工版，不含借用资产）。

### 1.1.43 — 2026-09-30

**修复 · 刷怪蛋召出的尸潮领主「满血却是第 2 阶段」，并把血量/护甲抬上去**（同日 1.1.42 的方框修复一并记在此）

- **根因**：原版 `Attributes.MAX_HEALTH` 的上限硬编码 1024
  （`RangedAttribute("attribute.name.generic.max_health", 20.0d, 1.0d, 1024.0d)`），且
  `AttributeInstance.calculateValue()` 结尾是 `attribute.sanitizeValue(total)` ——
  **修饰符叠加完还要再夹一次上限**，所以 1.1.41 起写的 2500 一直是 1024；而当时的阶段阈值是绝对数，
  `phaseFor(1024)` → `1024 > 833` → **Phase 2**。「满血 + 第 2 阶段」就是这么来的。
- **修法**：`ModEntities.liftHealthCap()` 反射抬 `RangedAttribute.maxValue`（按**值** 1024.0 认字段 ——
  开发是 Mojang 名、出货包是 SRG 名，写死名字会在另一侧静默失效）；三个阈值改为由 `BOSS_MAX_HEALTH` 推导、
  `phaseFor()` 比**运行时上限的比例**；`finalizeSpawn()` 把出生状态钉死（满血 + 按满血重算阶段 + 计数清零），
  刷怪蛋 / `/summon` / 刷怪笼 / 尸潮第 5 波结构上同构；阶段推进逐级，一击跨两级不再吞掉中间段的入场技与标题。
- **数值**：血量 2500 → **4200**（阈值 2800 / 1400 / 亡语 630）；护甲 5 → **15**、韧性 8 → **12**。
  护甲 5 在 1.20.1 公式下对 15 点伤害只有 **5%** 减伤（等于没穿甲），15/12 是 **−48%**。
- **实测**（headless 专用服务端 + RCON）：`attribute … max_health get` = **4200.0**、`Health` = **4200.0f**、
  `armor` = **15.0**、`armor_toughness` = **12.0**（修前同样是这两个命令量出 1024.0，才定位到上限夹取）。
- 1.1.42（同日）：修掉 `horde_overlord.animation.json` 的 per-axis 关键帧形状 —— 它在 GeckoLib 资源重载里抛
  `JsonParseException`，让客户端清空 `resourcePacks` 并导致全屏文字变方框。

### 1.1.41 — 2026-09-28

**调整 · 手持姿态摆正 + 枪械往画面中间收（五把枪共用）**

腰射时枪身原本是斜的：`GunPose` 的 4° 偏航加在物品模型自带的 4° `display` 偏航**外侧**，两者叠成真实的 8°（`tools/hip_square_probe.py` 量得枪管偏离视轴 4.31°，方向余弦 `(+0.0698, −0.0279, −0.9972)`），屏幕上表现为整把枪歪着摆、右手压在最右下角。

| 对象 | 内容 |
|---|---|
| `GunPose.HIP_YAW/HIP_PITCH/HIP_ROLL` | `4.0 / 1.6 / −3.0` → **`0 / 0 / 0`**。枪管轴线与视轴**严格平行**（`(0, 0, −1)`，0.00°），腰射态也横平竖直；跑步姿态不受影响，仍是刻意的斜持（`SPRINT_*` 未动） |
| `GunPose.HIP_DX/HIP_DY` | `−0.30 / +0.30` → **`−0.38 / +0.27`**。握把屏幕落点 NDC x 由 `+0.54`（Uzi `+0.69`）收到 `+0.30 ~ +0.40`，进入画面下方中段——「右手往中间靠」 |
| 不动的东西 | `ADS_X/ADS_Y`、`DISPLAY_PITCH/YAW`、`FIRST_PERSON_SCALE` 全部原样。抬镜的 `display` 共轭抵消本来就与 hip 角度无关，量算残差仍是 `+0.0004 / +0.0004` 格，**开镜瞄具线零回归** |
| 取值依据 | 新增 `tools/hip_square_probe.py`（复用 `pose_measure.py` 的同一变换链）：输出摆正前/后枪管方向余弦，以及 `HIP_DX/HIP_DY` 六档候选下的握把 / 枪口 / 后照门 NDC 落点 |
| 副作用核对 | 手到肩距离 0.983 → 1.048 格（`WeaponArms` 按此拉伸手臂骨，约 +6.6%），仍在 `美术规范.md` 认可范围内；右键举镜、跑步姿态、`SPRINT_BOB_*` 摇摆均不受影响 |
| 验收 | `gradlew compileJava` 通过；`tools/check_gun_resources.py` 全过（5 枪 + 6 刷怪蛋 + 23 音效）；`pose_measure.py` 对 M1/AWM/Uzi 三把枪开镜残差仍在 0.001 格容差内 |

**注**：`mod_version` 仍是 `1.1.40`（本次未改 `gradle.properties`）；要在游戏里看到效果需重新构建并替换 jar。

### 1.1.40 — 2026-09-28

**新增 · 跑步持枪姿态（五把枪共用）**

停下来是「端着」，跑起来是「拎着」。这一版把两者分开：跑动时枪从瞄准线上下到身侧（偏航 22°、
俯仰 −20°、翻滚 20°，`GunPose.SPRINT_*`），并叠一层随步频起伏的轻微摇摆。

| 对象 | 内容 |
|---|---|
| `GunPose` | 新增跑步混合：位移与旋转都在「站立腰射 ↔ 跑步持枪」之间按 sprint 权重插值，再整体由抬镜权重收回。抬镜满值时 `s = sprint·(1−aim) = 0`，**瞄准态结构上零回归** |
| `GunAimState` | 新增 `sprinting` / `sprintProgress`，0.18 秒渐变进出 —— 与抬镜共用同一套「tick 累加 + 渲染插值」机制 |
| `WeaponHandGrip` | 摇摆相位取自 `walkDistO → walkDist` 的插值（按走过的地面算，不按墙钟），停步即停摆 |
| 取值依据 | 用 `tools/pose_measure.py` 的同一变换链离线解算（FOV 70，即 `onRenderHand` 实际使用的投影）：相对站立腰射，五把枪**枪口一致下压 0.47~0.54 NDC**，双手全在画面内（右手 y −0.61~−0.89） |
| 验收 | `tools/_deploy_140.py`：相对 1.1.39 变化的字节**恰为** 4 个 class + 构建元数据，资产条目零变化；`GunPose.class` 内 8 个跑步常量在、6 个腰射常量原样；`UziItem.class` 逐字节未变（ADS 是残差 0 的已验证量） |

**清理**：`WeaponArms` 里的一次性诊断（每秒一行 `ARMSDBG`）总开关关闭，不再写日志；探针留在原地备用。

### 1.1.37 → 1.1.39 — 2026-09-28（Uzi 冲锋枪）

程序化建模 → Blockbench 精修 → Java 全量接线 → 编译替换测试，三轮收口，逐版取证见
`art/uzi/DELIVERY.md`。

| 版本 | 内容 |
|---|---|
| 1.1.37 | 立项到可玩：几何 / 贴图 / 动画三份产物与 Java 注册一次做完，编译替换测试通过 |
| 1.1.38 | 铁瞄归零：前柱穿出护环，**2.34° 的偏差由几何唯一确定**（不是审美调参），前柱收到 3.26u → 0.00°；`ADS_Y` 0.3118 → 0.3015 |
| 1.1.39 | 腰射基准位抬高 + 手臂入场改造（对标 TaCZ 的持枪位：抬高 `HIP_DX/DY`、肩点外移、`ADS_SHOULDER_PUSH` 1.55 → 1.15）；**五枪打完自动换弹**（打空即换 + 空匣扣扳机也触发） |

1.1.39 的量算口径：原先腰射时枪与双臂整体落在画面下缘以下 —— 抬位后腰射握把 NDC 从 −1.56 到
−0.593，五把枪右手 y 全部进画面（−0.39 ~ −0.75）；瞄准态 `ADS_X −0.4746` / `ADS_Y +0.3015` 残差 −0.0000。

### 1.1.6 → 1.1.36 — 2026-09-26 → 09-28

这一段跨了 31 个版本，逐版的取证、失败与验收留在各功能的交付台账里。下面按功能归并，只记
「改了什么、证据在哪」，细节以台账为准。

**十字弩（1.1.26 → 1.1.36，`art/crossbow/DELIVERY.md`）**

左右凸轮 / 弓臂精确镜像（修「模型不完整、错位」）→ 弓臂几何重定 + 解算器换成「双不变量」版 →
现代复合重构（牙总成搬到弦的落点，重做成「爪座 + 上下颚 + 轴销」的现代勾爪；`check_crossbow_anim.py`
新增长弦道走廊零越界、爪前脸 ↔ 弦后脸 ≤0.05u 两条硬断言）→ **1.1.36 右键 = 透明十字瞄准镜**
（方案 B，`GunItem.SightStyle` 契约，只动 Java）。

**美女僵尸（1.1.6 → 1.1.34，`art/bride/`）**

128 重绘 → PHASE2（1.1.11–1.1.18：四条扩充技能 + 行走重做 + 面部 / 体表重画 + 面纱 / 长发 / 鬓发 /
拖尾 / 裙摆真骨骼）→ 头纱下摆波浪扇贝边（1.1.25）→ 全身位移复标定（1.1.30–1.1.32）→
手臂攻击变明显（1.1.33）→ **目标死锁修复**（1.1.34：`ScentTargetGoal` → `PreyTargetGoal` + `PreyJudge`，
此前她不会攻击村民 / 铁傀儡 / 玩家）。

**士兵僵尸与 AI 强化（1.1.21、1.1.24、1.1.29、1.1.33，`art/soldier/`、`art/ai_enhance/`）**

士兵僵尸交付（1.1.21，md5 `87d93825505d91cdd21a657f24b5edf1`）与四轮 AI 行为强化。

**工程**

- 1.1.7–1.1.8：`mods/` 里的 jar 被外部进程持久持有（禁删 / 改名，但允许写入）→ **升版号换文件名**
  绕过；此后所有出货脚本都按「先验 md5 身份，再当基线」来做。
- 没有 git 仓库：改代码没有回退网，出货一律走 `tools/_deploy_<ver>.py`，并把「量算锚点随几何更新」
  「几何重跑会重掷骨骼 UUID，动画必须跟着重建」写成硬约束。

### 1.1.5 — 2026-09-24

**新增 · 莫辛-纳甘 M91/30：第三把枪，全链路接入**

木/钢结构的栓动步枪，从 Blockbench 脚本到 Java 注册一次做完：22 骨骼 / 170 方块 / 1020 面，
成品 1.43 格（22.9u，真机 1232 mm 按本工程 53.8 mm per unit 折算），512² 逐面 UV 图集，
骨骼一根不带旋转（`美术规范.md` 铁律）。贴图、几何、动画三份产物与 `art/mosin_nagant/` 留档一份哈希一致。

| 对象 | 内容 |
|---|---|
| `MosinNagantItem` | 栓动机构：每次扣扳机只出一发，`shoot`（12t 后坐）之后隔 `SHOOT_TICKS` 再放 `bolt`（22t 拉栓抛壳），闭锁前扳机失效 —— 与 AWM 同构 |
| 弹仓 | **固定 5 发盒式弹仓**。`reload_empty`（88t）开栓 → 一发一发压入 5 发（关键帧 24.2/36.7/48.3/60.0/72.5t）→ 末发闭栓；`reload_tactical`（72t）半仓补 3 发 |
| 瞄具 | 铁瞄：柱式准星 + 切线表尺。`hasScopeOverlay()=false`、`hidesModelWhileAimed()=false` —— 照门就是瞄准点，枪必须留在画面里 |
| 双手 | `MosinNagantGeoModel` 给出手部目标：右手握把 / 直拉机柄 / 弹仓上方压弹，左手托护木；`WeaponArms.renderMosinNagant` 按动作与进度驱动 |
| 音效 | 借 `sounds/awm/` 一套（CC BY-NC-ND 4.0，见 `NOTICE.md`）。**不用弹匣装卸声**——这把枪没有可拆弹匣，用错的声音比没有声音更糟。时刻表按 `mosin_nagant.animation.json` 的关键帧定，不是估的 |
| 弹道 | 7.62×54R：17/14/10 伤害跨 50/140 格，穿 3 个目标，射程 200 —— 介于 M1 的 .30-06 与 AWM 的 .338 之间 |
| 验收 | `tools/check_gun_resources.py`（三把枪全过）+ `check_mosin_art.py` / `check_mosin_anim.py` 均 0 错误 |

**修复 · 按 `logs/` 里的实机报错收口**

| 报错（`logs/`） | 根因 | 处理 |
|---|---|---|
| `Unable to load model: apocalypse_zombies:{screamer_zombie,crusher_zombie,corroder_zombie,marksman_skeleton}_spawn_egg` | `ModItems` 的注释以为"Forge 按 `_spawn_egg` 后缀自动套模型"——查 `ForgeSpawnEggItem` 源码：Forge 只自动注册**染色**（`ItemColors`），模型从来不自动生成。四个刷怪蛋没有 `models/item/*.json`，物品栏里是紫黑 missing 方块 | 补 4 份 `models/item/<id>.json`（`parent: minecraft:item/template_spawn_egg`，与原版刷怪蛋同构），改掉那条误导性注释 |
| `Missing sound for event: apocalypse_zombies:ammo_clip_pop` | `AMMO_CLIP_POP` 在 `ModSounds` 注册了，`sounds.json` 里却没有同名键；旁边的 `src/main/resources/main/assets/.../sound/events/*.json`（1.19 时代的 `sound/events` 写法）路径不合法，是两片打不进命名空间的死文件 | `sounds.json` 补 `ammo_clip_pop` → `awm/awp_reload_empty_mag_drop`（弹夹脱出的金属碰撞，与事件意图一致），删掉 `resources/main/` 整棵死目录 |
| `游戏日志 - 1.20.1-Forge_47.4.23-2.log`（17:26 启动即崩）里的 `ZipException: invalid CEN header (bad signature)` | `mods/` 里有一个中央目录损坏的 jar；现存唯一损坏件是 `hexalunar_calamity-1.0.0-r109.jar.broken`（1,176,823 字节，最后字节停在 `.../mtx.obj` 半截条目，`zipfile` 直接拒绝打开），它当时还叫 `.jar` 所以被 Forge 扫到，事后已改名 | 逐个校验 `mods/*.jar` 的 EOCD 签名：21 个全带 `50 4b 05 06`，当前无损坏件、无需处理。**教训：jar 没下全就重启 = 启动即崩，且崩溃栈不含文件名** |

**自检**：`tools/check_gun_resources.py` 加两段 —— 8. 音效接线（`ModSounds` 每个事件都要有 `sounds.json` 键、反向不许有死键、引用的 `.ogg` 必须真在磁盘）；9. 非枪物品（刷怪蛋）也要有 `models/item/<id>.json`（parent 必须是原版 `template_spawn_egg`）与两套 lang。三把枪 + 4 个刷怪蛋 + 23 个音效全过。

**工程**：`mod_version` `1.1.4` → `1.1.5`（`gradle.properties` 仍是唯一来源，`mod.toml` 与 README 跟着走）。

### 1.1.4 — 2026-09-23

**修复 · AWM 开镜时枪身与双臂挡住镜筒（右键只开镜）**

镜筒在屏幕上是一扇窗：摆在窗前的东西就是玩家"透过"它看到的东西。而抬镜到位时，整枪正好被
`ADS_X/ADS_Y` 拉到屏幕正中、对准目镜 —— 于是枪身和双臂全落在镜筒里。真实的狙击镜此时什么也看不见枪，
你看到的是目镜里的像。

| 对象 | 改动 |
|---|---|
| `GunItem` | 新增 `hidesModelWhileAimed()`：这条规则**问枪自己**，不写死在渲染层 |
| `AWMItem` | `true` —— 镜片即视场 |
| `M1GarandItem` | `false` —— 照门就是瞄准点，枪必须留在画面里 |
| `ClientEvents.sightOwnsFrame()` | 抬镜进度越过 `SCOPE_HIDE_MODEL_AT = 0.5` 后整枪与双臂不再绘制；同一帧一并取消副手（免得火把挂进镜筒） |

交接时机是量出来的、不是拍的：黑色遮罩的浓度是 `SCOPE_DARKNESS × progress`，过半时为 **0.47** ——
枪是在半黑画面下退场的，看不到凭空消失；`RenderHandEvent` 的取消照旧保留，否则原版那只单臂会顺着空档回来。
铁瞄的 M1 之所以不能一起隐藏，是因为它的瞄准点就是枪上的照门。

**修复 · M1 加兰德两段换弹与拉栓按真机机构重做**

旧版把枪机留在闭锁位、只让漏夹下压 —— 真机上此时井口被枪机挡死，漏夹物理上压不进去。动作顺序改为
野战手册的四步：**① 导气杆拉到底并挂住 → ② 漏夹垂直压入弹夹井 → ③ 松手，枪机被漏夹自动释放前冲 →
④ 掌根拍拉机柄后端闭锁**。`reload_empty`（3.0s）与 `reload_tactical`（2.6s）都走这套顺序，第 ④ 步做成
前冲末端的减速节拍（`0.88 → 0.5 → 0.2 → 0.06 → 0`）；`shoot` 的半自动枪机循环补到与 `bolt` 相同的
**1.10u** 全行程（原来只有一半，越不过漏夹末弹底缘）。枪机后退量沿用 `bolt` 段的既有值，真机行程
6.6 cm ≈ 1.06u，差异已记录在 `art/m1garand/README.md`。

**新增 · 确定性导出链（M1 动画）**

MCP 的 `geckolib_*` 导出工具在本机工程状态下被禁用，改为：
`tools/m1_garand_bb_anim.js`（生成器顺手把原始关键帧写成 `art/m1garand/_anim_raw.json`）→
`tools/m1_anim_export.py`（raw dump → GeckoLib JSON，复刻插件的导出规则：24 fps 半点进位吸附、
单键通道静态缩写、多键 `post` + `lerp_mode`、左右手系翻转 position `[−x,y,z]` / rotation `[−x,−y,z]`）。
**转换器的正确性用"未改动的动画必须逐字节重现出厂文件"验**：`static_idle` / `draw` / `bolt` 三段与改动前
逐字节一致，`shoot` 只差枪机通道，两段换弹是预期重写 —— 差异全部能解释才写盘。

**新增 · 机构自检**：`tools/check_m1_reload.py` —— 起手枪机在闭锁位、0.35s 内拉到底、漏夹出现与卡住时
枪机仍在后退位、之后才自动前冲、前冲末端有拍击分级、半自动走全行程、`scale` 只出现 0/1（禁止整体缩放）。
以后改动画破坏机构会立刻变红。

**修复 · 关键帧撞帧（漏夹"永不消失"）**

关键帧在**导出时**才按 24 fps 吸附，相隔 < 1/24 s 的两个键会并到同一帧而丢掉一个：旧漏夹"消失"与新漏夹
"出现"那对 `scale` 键（0.98 / 1.02）双双落到第 24 帧，表现为旧夹永不消失、位置从"飞走"插值回"压入"划弧。
现在生成器**写入时就吸附并检测撞帧**（撞帧打 `KEYFRAME COLLISION`），这对键直接写成帧对齐的 `1.0` / `25/24`。

**工程**：版本号 `1.1.3` → `1.1.4`（`gradle.properties` 的 `mod_version` 仍是唯一来源，`build.gradle` 与
`mods.toml` 由占位符展开；根 `mod.toml` 同步）。

### 1.1.3 — 2026-09-23

**修复 · M1 Garand 漏夹井整体偏前一个井长（82mm）**

井在模型里落在机匣前缘（旧值 519…618mm，枪口起算），而真机漏夹是压进**机匣上方紧挨闭锁面**的井：
枪管 24″ = 610mm ⇒ 闭锁面在枪口后 610mm ⇒ 井前壁就压在这个面上，井长取漏夹（85mm）加余量 ⇒ **601…700mm**。
后壁 700mm 恰好落在模型里已有的 `Z(700)`（拉机柄 / 后照门座前沿），两个独立来源互证。
旧值的成因是 v3 把参考图里“木护木 / 木托颈”的边界当成了机匣前缘 —— 真机机匣 221mm，模型 280mm，
这段偏差一直没动，于是井被钉在了错误的一端。

| 对象 | 改动 |
|---|---|
| 漏夹井（5 方块） | Δz **+1.312u（+82mm）** → z −3.984…−2.400 |
| 机匣桥面 `brg_top` | 起端 Z(652) → **Z(700)**（井口让开） |
| 漏夹盖 / 漏夹 | Δz +1.312u；盖 pivot 留在 Z(799)（纯平移，固定基准） |
| 弹壳 `casing` | Δz **−0.752u** → 静止位从抛壳窗外（795mm）移到窗内中心（748mm） |
| `clip_in` 动画两段 | 旋转全清零、位移 x 归零（装填 = 平移合上，不再翻转），垂直压入保留 |
| `M1GarandGeoModel.CLIP` | z −4.60 → **−3.29** |
| `bolt_chan` 枪机通道 | 不动（首版工具按 bbox 把井内腔与它一起搬走，已回填并加断言） |

**新增 · 标定工具**

- `tools/m1_well_shift.py`：几何 + 动画 + Java 常量同批改动，**幂等**（定位同时接受新旧两种外框，
  出现“半新半旧”直接拒绝写盘），`--check` 预演不落盘，末尾跑一遍不变量断言。
- `tools/m1_well_overlay.py`：把新旧井位叠加到真机侧视参考图上（`art/m1garand/well_fix_overlay.png`），
  逐幅标定 —— 参考图是上下两幅方向相反的照片合成图，取并集算剪影会把比例和方向都算错。

**文档**

- `art/m1garand/README.md`：补真机标定表、井位判据（画的是**闭锁面**，不是机匣前缘）与本次改动清单。

**工程**

- 版本号 `1.1.2` → `1.1.3`（`gradle.properties` 的 `mod_version` 是唯一来源，`build.gradle` 与 `mods.toml` 由占位符展开；根 `mod.toml` 同步）。

### 1.1.2 — 2026-09-23

**修复 · 右键开镜时照门与准星不共线（缺的是一项旋转，不是常量没调好）**

`models/item/*.json` 的 `display` 里除缩放外还有 **rotation**（两把枪同为俯仰 2° / 偏航 4°），
它绕在姿态链**内侧**。把 hip 姿态的偏航/俯仰归零只让枪“不再歪”，前后照门仍差 **4.47°** ——
这是**平行但偏轴**，`ADS_X / ADS_Y` 无论怎么调都消不掉（只会随距离放大）。
修法是在 `GunPose` 里再乘这个旋转的**精确共轭**：用与 vanilla `ItemTransform.apply` 同一个
`Quaternionf.rotationXYZ` 构造再取共轭 ⇒ 构造性精确，不依赖 JOML 内部的结合次序。
角度由 `GunItem#adsPitch() / adsYaw()` 逐枪下发，两把枪的瞄具线与视轴夹角 **4.47° → 0.00°**。

**修复 · 开镜抬枪位移改为量算值**（原先是从 hip 姿态的偏移反推的估值）

| | 改前 | 改后（量算） | 与量算残差 |
|---|---|---|---|
| M1 Garand `ADS_X / ADS_Y` | −0.06 / +0.28 | **−0.475 / +0.346** | 0.0004 格 |
| AWM `ADS_X / ADS_Y` | −0.12 / +0.25 | **−0.475 / +0.346** | 0.0004 格 |

**调整 · 手持位置更靠画面内侧**（`GunPose.HIP_DX / HIP_DY`：−0.06 / +0.04 → **−0.10 / +0.08**）

握把（也就是右手抓握处）的屏幕落点从 NDC `(+1.24, −1.14)`（在画面外 14%）移到 `(+1.12, −1.02)`，
刚好压在下缘上 —— 腰射时能隐约看见右手，换弹动作不再被裁掉大半。画面右缘为 `+1.78`、下缘为 `−1.00`。

**新增 · 姿态量算工具** `tools/pose_measure.py`

走完整条变换链（手基座 → 姿态 → `display` → 几何）量算“把瞄具线送到视轴上”所需的位移与旋转，
并**自校验** Java 常量（与量算不符直接报 ✗）；另打印若干档 `HIP_DX / HIP_DY` 的 NDC 落点供取舍。
`tools/check_gun_resources.py` 相应增加两条断言：`adsPitch() / adsYaw()` 必须与物品模型 JSON 的
`display` rotation 逐字一致（且 roll 必须为 0）、`ADS_*` 必须落在量算区间 —— 两项都先拿旧值跑出过失败。

**文档**

- 根 README 与两把枪的 `art/<武器>/README.md`：补上 `display` 旋转这一环，以及“位移消不掉旋转误差”的判据。
- README「构建」一节记录本机构建在配置阶段被 ForgeGradle 联网探测阻塞的现象与解法。

**工程**

- 版本号 `1.1.1` → `1.1.2`（`gradle.properties` 的 `mod_version` 是唯一来源，`build.gradle` 与 `mods.toml` 由占位符展开；根 `mod.toml` 同步）。

### 1.1.1 — 2026-09-23

**修复 · 两把枪的贴图集与几何“脱代”（游戏里表现为枪身大片发黑）**

两把枪的图集都有一块**没画到模型 UV 用到的范围**，采到全透明像素 → 渲染成纯黑。
几何 / 动画 / UV / 贴图尺寸检查全绿，只有**逐面覆盖率**能看出来。同一类缺陷的两种形态：

- **M1 Garand**：生成器产物只写进 `art/`，资源目录那份是**更早的截断导出**（图只画到 V=237，UV 用到 V=322）。
  已装回 `art/m1garand/m1_garand_geo.png` 权威产物，并让生成器同时写 `art/` 与资源目录两处。
- **AWM**：图集本身与几何**不同代** —— 生成器的贴图段只把图集画进 Blockbench 的**内部贴图**、**不写文件**，
  PNG 靠手工导出，漏导一次就停在 V=388（UV 用到 V=453）。已按生成器自己的色板与绘制公式**逐像素回填**
  （`tools/awm_tex_fill.py`）：2562 面 / 50604 像素，只写原本全透明的像素，**已涂绘像素零改动**（脚本内断言）。

**新增 · 资源接线自检** `tools/check_gun_resources.py`

从注册表读出枪的清单逐把校验：资源路径、驱动骨与 clip 名对齐、`ANIM_*` / `TRIGGER_*` 与动画文件逐条匹配、
动作时长常量（按向上取整比对）、贴图 512²，以及新增的**逐面 UV 覆盖率** ——
旧图对 M1 报 1514/2076 面空白、对 AWM 报 1549/2610，修好后两把枪均为 **0**。
检查器自身做过变异测试（故意改错值必须报错），避免“永远绿的检查器”。

**文档**

- `美术规范.md` 增加“图集必须画满模型用到的 UV”硬要求与对应的检查手段（只看尺寸拦不住它）。
- 两把枪的 `art/<武器>/README.md` 记录故障现象、根因与修法；修复前的图集留档为 `*.pre-fill.bak.png` / `*.old-resource.bak.png`。

**工程**

- 版本号 `1.1.0` → `1.1.1`（`gradle.properties` 的 `mod_version` 是唯一来源，`build.gradle` 与 `mods.toml` 由占位符展开；根 `mod.toml` 同步）。

### 1.1.0 — 2026-09-23

**新增 · 特殊敌对生物**

- 四只特殊敌对生物：`screamer_zombie`、`crusher_zombie`、`corroder_zombie`、`marksman_skeleton`，
  及其投射物 `acid_projectile` 与四个刷怪蛋。
- 每只一格技能槽（`SCREAM` / `SLAM` / `SPIT` / `SNIPE`），前摇—命中—收招三段齐备。
- 姿态为 Java 侧程序化骨骼动画（`ElitePose` + `CastPoseBlender`），不依赖 GeckoLib 关键帧文件；
  收招插值回原版姿态，不硬切。
- 技能状态经 `SynchedEntityData` 同步，服务端权威。

**新增 · 生成与控制**

- 自定义 biome modifier（`apocalypse_zombies:elite_spawns`）+ `SpawnPlacements` 登记，两件套缺一不可。
- 权重实时读配置，默认 3（约每 170 只怪出一只精英）。
- 精英随尸潮登场（默认第 3 波起、每两波 +1、封顶 3），计入 boss bar 总数与波次完成判定。
- 新增 `[specials]` 配置段。

**修复**

- **蘑菇岛不再刷精英**：`#minecraft:is_overworld` 含 `minecraft:mushroom_fields`，
  会把原版唯一的安全屋破掉，已在生成判定里显式否决。
- 精英不再随机持铁剑出场：原版僵尸 1%~5% 会带武器生成，与精英模型自带的武器重复，已堵掉装备槽随机。

**调整 · 枪械第一人称尺寸**

- 两把枪在第一人称整体放大 25%（`AWMItem.FIRST_PERSON_SCALE` / `M1GarandItem.FIRST_PERSON_SCALE`，
  经 `GunItem#firstPersonScale()` 下发）；第三人称、GUI、掉落物与展示框的尺寸不变。
- 放大加在**姿态链上游**（`WeaponHandGrip` 里手基座与 `GunPose` 之间的 `pose.scale`），而不是改物品模型的
  `display`：`display` 位于姿态链下游，只放大枪体而不放大抬枪位移，开镜时镜轴会被顶偏；
  加在上游则 `ADS_X / ADS_Y` 随之等比放大，镜轴仍落在屏幕中心，**调放大系数不必重测**这两个常量。
  手的锚点取自 GeckoLib 渲染矩阵（`GunFrame`），自动跟随，无需另配。
- 物品模型的 `display` 里还有**旋转**（逐枪 2° 俯仰 / 4° 偏航），它同样绕在姿态链**内侧**：
  只把 hip 角度归零并不足以让瞄具线与视轴平行，会残留 4.47° 的"平行但偏轴"，而**位移消不掉旋转误差**。
  瞄准时 `GunPose` 额外乘上该旋转的**精确共轭**（用与 vanilla `ItemTransform` 同一个
  `Quaternionf.rotationXYZ` 构造再取共轭 ⇒ 构造性精确，与 JOML 内部次序无关），角度由
  `GunItem#adsPitch()/adsYaw()` 下发，接线检查器逐字核验两者一致。
- 放大系数是逐枪的常量，进游戏按观感微调（`1.0` = 关闭）。

**工程**

- 版本号 `1.0.0` → `1.1.0`（`gradle.properties` 的 `mod_version` 是唯一来源，
  `build.gradle` 与 `mods.toml` 都由占位符展开；根目录 `mod.toml` 同步）。
- 全量重编（`--no-build-cache --rerun-tasks`）通过：**0 错误 / 21 警告**，
  警告全部是 `new ResourceLocation(String, String)` 的 `[removal]` 弃用（Forge 为 1.21 提前标记，
  1.20.1 下无害），共 19 处调用点，待后续统一迁移到 `ResourceLocation.fromNamespaceAndPath` / `parse`。

**待验证**

- 特殊敌对生物**已通过编译与部署校验**，但技能与动画的游戏内观感（三段姿态是否连贯、
  收招是否平滑、特效与命中是否对齐）**尚待客户端实测**。
- 枪械第一人称放大 25% 是起始值，观感同样**尚待客户端实测**（`display` 的基础尺寸 0.78 / 0.82 未动）。
- 1.1.0 发布后发现的**两把枪贴图集缺陷**见上方 1.1.1（游戏内表现为枪身大片发黑）。

### 1.0.0 — 初始版本

- 僵尸六阶进化系统与全局等级。
- 七种月相事件及其世界效果（锁床 / 催熟 / 幸运与额外掉落）。
- 四波随机化尸潮与 boss bar 进度条。
- GeckoLib 枪械：`awm`、`m1_garand`，服务端权威判定、NBT 状态机、战术 / 空仓换弹分流。

---

## 许可与署名

- **本项目代码**：GPL-3.0-or-later，全文见 [`LICENSE`](LICENSE)。
- **借用的第三方内容**（22 个音效 + 转录动画，来源 Timeless & Classics Guns: Zero / Serene Wave Studio）
  **只存在于开发自用包**，受 CC BY-NC-ND 4.0 约束：不得商用、不得公开分发、不得发布改编版。
  分发请用 `-clean.jar`。详见 [`NOTICE.md`](NOTICE.md)。
- **GeckoLib**（MIT）为硬依赖，不随本模组分发。
- Not affiliated with Mojang or Microsoft. 本模组不含任何 Minecraft 官方资源，使用需正版游戏。

### 版权行

> Copyright (C) `<年份>` `<著作权人>` —— **待项目所有者填写**。
> `NOTICE.md` 已把它列为发布前待办项；模组元数据里 `mod_authors` 目前是 `Hermes`。
