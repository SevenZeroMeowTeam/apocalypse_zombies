package com.apocalypse.zombies.entity;

import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import com.apocalypse.zombies.moon.MoonEventManager;
import com.apocalypse.zombies.registry.ModEntities;
import com.apocalypse.zombies.zombie.EvolutionTier;
import com.apocalypse.zombies.zombie.ZombieEvolution;

import javax.annotation.Nullable;

/**
 * 尸潮之主 —— 三阶段 Boss，4200 点生命。
 *
 * <p>和其余精英的差别只在「数量级」和「阶段」两件事上：</p>
 * <ul>
 *   <li><b>4200 HP 分三段</b>：2800（2/3）以上是 Phase 1，1400（1/3）以上是 Phase 2，
 *       之下是 Phase 3。阶段不是纯数值墙 —— 每跨一段都会当场放一个<b>入场技</b>，
 *       并把后续的技能轮转换成更长的表（Phase 1 两招，Phase 2 四招，Phase 3 五招 + 亡语）。</li>
 *   <li><b>技能全部走 {@link EliteAbility} 的三段切分</b>（前摇 → 命中 → 收招），
 *       模型侧不做任何数值推算：{@code impactTick} 就是结算那一 tick，也是动画的收放点。</li>
 * </ul>
 *
 * <p><b>下面这组常量与 {@code tools/boss_v1.py} 双向同步</b>：生成器写完 geo/anim 之后会回来读这几行，
 * 对不上就报 FAIL。改血量分段必须同时改生成器，否则自校验会拦住。</p>
 *
 * <p><b>血量必须配 {@link com.apocalypse.zombies.registry.ModEntities} 的「抬上限」</b>：原版
 * {@code Attributes.MAX_HEALTH} 的上限硬编码 1024（{@code RangedAttribute(..., 20.0, 1.0, 1024.0)}），
 * 而 {@code AttributeInstance.calculateValue()} 的最后一句是 {@code attribute.sanitizeValue(total)} ——
 * <b>所有修饰符叠完还要再夹一次上限</b>，所以「写大常量」和「挂 ADDITION 修饰符」两条路都逃不过 1024
 * （实测：Base 1024 + Amount 3176 时 {@code /attribute get max_health} 仍返回 1024.0）。
 * 上限由 {@code META-INF/accesstransformer.cfg} 打开 {@code RangedAttribute.maxValue} 后抬到
 * {@code ModEntities.RAISED_HEALTH_CAP}；缺任何一环，Boss 的实际上限就只有 1024 ——
 * 满血 {@code phaseFor(1024)} 判成 Phase 2，玩家看到的就是「刷怪蛋召出来的领主一出生就是 2 阶段、
 * 血条却是满的」（1.1.42 实测缺陷）。</p>
 *
 * <p>两条不变量（门禁按它们断言）：① 分段阈值一律由 {@link #BOSS_MAX_HEALTH} 推导；
 * ② 出生时按「满血」重算阶段（{@link #finalizeSpawn}），刷怪蛋/指令/尸潮各路径同构。</p>
 */
public class HordeOverlord extends AbstractEliteZombie implements GeoEntity {

    // ---------------------------------------------------------------- 阶段阈值（生成器回读）

    /** Boss 总生命。 */
    public static final float BOSS_MAX_HEALTH = 4200.0F;
    /**
     * 原版 {@code Attributes.MAX_HEALTH} 的硬上限（{@code RangedAttribute} 的 {@code maxValue}）。
     * 本模组的**实际**上限由 {@code ModEntities.RAISED_HEALTH_CAP} + AT 抬高；这个常量是「为什么必须抬」的依据。
     */
    public static final float VANILLA_HEALTH_CAP = 1024.0F;
    /** Phase 1 → Phase 2 的分界：总生命的 2/3（4200 → 2800）。 */
    public static final float PHASE2_HP = BOSS_MAX_HEALTH * 2.0F / 3.0F;
    /** Phase 2 → Phase 3 的分界：总生命的 1/3（4200 → 1400）。 */
    public static final float PHASE3_HP = BOSS_MAX_HEALTH / 3.0F;
    /** 「垂死崩解」的触发线：跌破总生命的 15%（4200 → 630）。 */
    public static final float DEATH_WAIL_HP = BOSS_MAX_HEALTH * 0.15F;

    /** 阶段数。三阶段的技能表见 {@link #ROTATION_PHASE_1} / 2 / 3。 */
    public static final int PHASE_COUNT = 3;

    // ---------------------------------------------------------------- 剪辑名（生成器回读）
    // 剪辑本身住在 assets/apocalypse_zombies/animations/horde_overlord.animation.json，
    // 由 tools/boss_v1.py 生成；下面这几行字符串是两边的接口约定。

    /** 静置（呼吸 + 尸笼慢转 + 披风轻摆）。 */
    public static final String ANIM_IDLE = "idle";
    /** 行走（基础循环：迈步 + 摆臂 + 斧头拖拽）。 */
    public static final String ANIM_WALK = "walk";
    /** 巨斧横扫（近战，1.1s，命中 0.55s）。 */
    public static final String ANIM_MELEE = "attack_melee";
    /** 骨刺齐射（远程，1.3s，命中 0.85s）。 */
    public static final String ANIM_RANGED = "attack_ranged";
    /** 召唤尸群（1.8s，命中 1.1s）。 */
    public static final String ANIM_SUMMON = "summon";
    /** 踏地冲击波（1.4s，命中 0.7s）。 */
    public static final String ANIM_QUAKE = "skill_quake";
    /** 血怒（Phase 3 入场，2.0s，命中 0.9s）。 */
    public static final String ANIM_RAGE = "skill_rage";
    /** 垂死崩解（1.6s，命中 0.9s）。 */
    public static final String ANIM_DEATH = "skill_death";
    /** 尸笼坠击（2.2s，命中 1.1s）。 */
    public static final String ANIM_CAGE = "skill_cage";
    /** 汲魂（2.6s，命中 1.3s）。 */
    public static final String ANIM_DRAIN = "skill_drain";
    /** 疫雾（1.9s，命中 1.0s）。 */
    public static final String ANIM_MIST = "skill_mist";
    /** 尸潮尖啸（2.3s，命中 1.15s）。 */
    public static final String ANIM_SCREECH = "skill_screech";

    // ---------------------------------------------------------------- 技能轮转表

    /** Phase 1（> 上限的 2/3，4200 → >2800）：只有近战与远程两招 —— 让玩家先学会躲斧头。 */
    private static final EliteAbility[] ROTATION_PHASE_1 = {
            EliteAbility.BOSS_SWEEP, EliteAbility.BONE_VOLLEY,
    };
    /** Phase 2（≤ 2/3，4200 → ≤2800）：加上踏地、坠击、疫雾与召唤，进场先来一记踏地。 */
    private static final EliteAbility[] ROTATION_PHASE_2 = {
            EliteAbility.BOSS_SWEEP, EliteAbility.GROUND_QUAKE, EliteAbility.CAGE_SLAM,
            EliteAbility.PLAGUE_MIST, EliteAbility.RAISE_HORDE, EliteAbility.BONE_VOLLEY,
    };
    /**
     * Phase 3（≤ 1/3，4200 → ≤1400）：九招齐全；进场放血怒。
     *
     * <p>表长 9 意味着「打完一圈」要一分多钟 —— 故意的：最后三分之一的血量里，
     * 玩家要同时应付招架近战（横扫 / 坠击）、拉不开的远程（骨刺 / 汲魂）、
     * 清不完的增援（召唤 / 尖啸）与地面控制（踏地 / 疫雾），
     * 而不是「记住两招的节奏」。亡语排在末尾，它同时也是一个可轮转到的招。</p>
     */
    private static final EliteAbility[] ROTATION_PHASE_3 = {
            EliteAbility.BOSS_SWEEP, EliteAbility.CAGE_SLAM, EliteAbility.SOUL_DRAIN,
            EliteAbility.PLAGUE_MIST, EliteAbility.HORDE_SCREECH, EliteAbility.GROUND_QUAKE,
            EliteAbility.RAISE_HORDE, EliteAbility.BONE_VOLLEY, EliteAbility.DEATH_WAIL,
    };

    /** 骨刺齐射的最小距离（格）：比这更近就该用斧头，而不是「拉弓射贴脸的人」。 */
    private static final double VOLLEY_MIN_RANGE = 4.0D;

    /** 两招之间的间隔（tick）。剪辑普遍 22~40 tick，留 24 就给玩家一个换位/回血的窗口。 */
    private static final int ABILITY_GAP = 24;

    /**
     * 防御 15 / 韧性 12 / 攻击 15 —— 设计给定值，改数值只改这几行
     * （{@link #createAttributes()} 直接引用，别在属性表里写回字面量）。
     *
     * <p>1.20.1 的护甲公式是 {@code min(20, max(armor/5, armor - damage/(2 + toughness/4)))}：
     * 5 点护甲对 15 点伤害只有 <b>5%</b> 减伤（等于没穿甲，这才是「护甲要加」的真实理由）；
     * 15 点护甲 + 12 韧性对剑系 −48%、对 30 点 −36%、对 50 点重击 −20%。
     * 原版上限是护甲 30 / 韧性 20，都还没顶格。</p>
     */
    public static final double ARMOR_POINTS = 15.0D;
    public static final double ARMOR_TOUGHNESS = 12.0D;
    public static final float ATTACK_POWER = 15.0F;

    /** 巨斧横扫：扇面半角（度）、半径（格）、伤害、击退。 */
    private static final double SWEEP_HALF_ANGLE = 60.0D;
    private static final double SWEEP_RADIUS = 5.0D;
    /** 横扫与基础攻击同一口径（15），免得同一个 Boss 身上挂着两套对不上的「攻击力」。 */
    private static final float SWEEP_DAMAGE = ATTACK_POWER;
    /** 踏地冲击波：半径（格）、伤害、上抛量。 */
    private static final double QUAKE_RADIUS = 7.0D;
    private static final float QUAKE_DAMAGE = 9.0F;
    /** 骨刺齐射：根数、单发伤害、初速、散布。 */
    private static final int VOLLEY_COUNT = 5;
    private static final float VOLLEY_DAMAGE = 5.0F;
    private static final float VOLLEY_SPEED = 2.4F;
    private static final float VOLLEY_SPREAD = 0.06F;
    /** 召唤：一次几只（设计给定 5）、场上最多留几只。 */
    private static final int SUMMON_COUNT = 5;
    /** 场上留存上限 —— 不是平衡数值，是防「召唤把自己埋掉」的粗暴围栏。 */
    private static final int SUMMON_CAP = 12;
    private static final double SUMMON_RADIUS = 5.0D;
    /** 垂死崩解：半径（格）、伤害、召唤数。 */
    private static final double WAIL_RADIUS = 8.0D;
    private static final float WAIL_DAMAGE = 12.0F;

    // ---- 1.1.46 追加的四招（Phase 2 / 3 的扩充） ----

    /** 尸笼坠击：正前方直线（格）× 半宽（格）、伤害、骨刺根数。 */
    private static final double CAGE_LINE_LENGTH = 9.0D;
    private static final double CAGE_LINE_HALF_WIDTH = 2.5D;
    private static final float CAGE_DAMAGE = 18.0F;
    private static final int CAGE_SPIKES = 6;
    /** 汲魂：半径（格）、单次伤害、按伤害换算的治疗系数、单次治疗上限。 */
    private static final double DRAIN_RADIUS = 10.0D;
    private static final float DRAIN_DAMAGE = 7.0F;
    private static final float DRAIN_HEAL_RATIO = 1.5F;
    private static final float DRAIN_HEAL_CAP = 240.0F;
    /** 疫雾：半径（格）、雾团持续时间（tick）、命中瞬间的直接伤害、中毒时长（tick）。
     *  <p>只用中毒作为持续伤害：僵尸系对中毒免疫，所以这团雾伤活人不伤自家尸群。</p> */
    private static final double MIST_RADIUS = 8.0D;
    private static final int MIST_DURATION = 160;
    private static final float MIST_DAMAGE = 5.0F;
    private static final int MIST_POISON_TICKS = 120;
    /** 尸潮尖啸：半径（格）、击退力度、失明时长、额外召唤数。 */
    private static final double SCREECH_RADIUS = 16.0D;
    private static final double SCREECH_KNOCKBACK = 2.2D;
    private static final int SCREECH_BLIND_TICKS = 80;
    private static final int SCREECH_SUMMON = 3;
    private static final float SCREECH_DAMAGE = 9.0F;

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    /** Boss 血条：只在有玩家看着的时候挂着，走原版的 {@code ServerBossEvent} 同步。 */
    private final ServerBossEvent bossBar = new ServerBossEvent(
            this.getDisplayName(), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);

    /** 环境音 / 阶段宣告的节流计数。 */
    private int phaseAnnounceCooldown;

    /** 当前阶段（1..3）。只存在服务端：客户端读的是技能状态，不需要知道阶段。 */
    private int phase = 1;

    /** 阶段入场技 / 亡语这种「一次性插队技能」，非 NONE 时优先于轮转表。 */
    private EliteAbility entryAbility = EliteAbility.NONE;

    /** 血怒是否已挂过（Phase 3 只挂一次，重挂会把增益叠成永动机）。 */
    private boolean rageApplied;

    /** 亡语是否已放（一只 Boss 只放一次）。 */
    private boolean deathWailFired;

    private int rotationIndex;

    /** 累计「这一槽等不到起手、被跳过」的次数 —— 只给调试指令看，用来判断轮转是不是在空转。 */
    private int starvedSlots;

    public HordeOverlord(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setCanPickUpLoot(false);
        this.setPersistenceRequired();
    }

    /**
     * 出生状态一律钉死：补满生命池 → 回满血 → 阶段按「满血」重算 → 轮转 / 入场技 / 亡语计数清零。
     *
     * <p>刷怪蛋（{@code SPAWN_EGG}）、{@code /summon}（{@code COMMAND}）、刷怪笼与尸潮第 5 波
     * （{@code EVENT}）因此完全同构 —— 不存在「哪条路径召出来的 Boss 数值不一样」这种事。</p>
     */
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag dataTag) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
        this.setHealth(this.getMaxHealth());
        this.phase = this.phaseFor(this.getHealth());
        this.rotationIndex = 0;
        this.starvedSlots = 0;
        this.entryAbility = EliteAbility.NONE;
        this.rageApplied = false;
        this.deathWailFired = false;
        this.phaseAnnounceCooldown = 0;
        return data;
    }

    /**
     * Boss 的数值。移速故意压得比普通僵尸低（0.21 < 0.23）：一个 4200 血的怪如果还能追着人跑，
     * 玩家就没有「拉开距离打工」这个解法了。
     *
     * <p>防御 15 / 韧性 12 / 攻击 15 是设计给定值（减伤换算见 {@link #ARMOR_POINTS}）：
     * 4200 血配 15/12 甲才让三段阶段真正打得完；攻击仍压在 15，避免「两下带走玩家」把走位解删掉。</p>
     */
    public static AttributeSupplier.Builder createAttributes() {
        return eliteAttributes()
                // 上限已由 ModEntities 的 AT 抬到 1e9，这里直接写总量即可（原版 1024 会静默夹取）。
                .add(Attributes.MAX_HEALTH, BOSS_MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.21D)
                .add(Attributes.ATTACK_DAMAGE, ATTACK_POWER)
                .add(Attributes.ARMOR, ARMOR_POINTS)
                .add(Attributes.ARMOR_TOUGHNESS, ARMOR_TOUGHNESS)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    // ------------------------------------------------------------------ 动画

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }

    /**
     * 两条控制器：{@code movement} 管静置 / 行走，{@code cast} 管技能。
     *
     * <p>整套技能一次只放一个，所以不需要「并行叠一层」那种第三控制器 ——
     * 每段剪辑首尾都归零，切进切出都不会跳变（生成器逐通道验过）。</p>
     */
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement", 4, HordeOverlord::movementAnimation));
        controllers.add(new AnimationController<>(this, "cast", 1, HordeOverlord::castAnimation));
    }

    /** 静置 / 行走：步子按实际位移缩放，三格高的腿不会打滑。 */
    private static PlayState movementAnimation(AnimationState<HordeOverlord> state) {
        if (state.getAnimatable().isCasting()) {
            return PlayState.STOP;
        }
        state.setControllerSpeed(Mth.clamp(0.6F + 0.9F * state.getLimbSwingAmount(), 0.55F, 2.0F));
        return state.setAndContinue(state.isMoving()
                ? RawAnimation.begin().thenLoop(ANIM_WALK)
                : RawAnimation.begin().thenLoop(ANIM_IDLE));
    }

    /** 施法：轮到哪一套就播哪一段。 */
    private static PlayState castAnimation(AnimationState<HordeOverlord> state) {
        String clip = switch (state.getAnimatable().getAbility()) {
            case BOSS_SWEEP -> ANIM_MELEE;
            case BONE_VOLLEY -> ANIM_RANGED;
            case RAISE_HORDE -> ANIM_SUMMON;
            case GROUND_QUAKE -> ANIM_QUAKE;
            case BLOOD_RAGE -> ANIM_RAGE;
            case DEATH_WAIL -> ANIM_DEATH;
            case CAGE_SLAM -> ANIM_CAGE;
            case SOUL_DRAIN -> ANIM_DRAIN;
            case PLAGUE_MIST -> ANIM_MIST;
            case HORDE_SCREECH -> ANIM_SCREECH;
            default -> null;
        };
        if (clip == null) {
            return PlayState.STOP;
        }
        return state.setAndContinue(RawAnimation.begin().thenPlay(clip));
    }

    // ------------------------------------------------------------------ 阶段与轮转

    /** 当前阶段。 */
    public int getPhase() {
        return this.phase;
    }

    /**
     * 按血量算阶段：≥ 上限的 2/3 → 1，≥ 1/3 → 2，否则 3。
     *
     * <p>比的是<b>运行时上限的比例</b>，不是写死的绝对数：上限一旦被任何东西改动（属性修饰符、
     * 别的模组、以后改平衡），分段跟着走 —— 满血永远判 Phase 1。绝对数只作为设计文档保留在
     * {@link #PHASE2_HP} / {@link #PHASE3_HP}，供生成器回读与调试指令打印。</p>
     */
    private int phaseFor(float health) {
        float max = Math.max(1.0F, this.getMaxHealth());
        if (health > max * 2.0F / 3.0F) {
            return 1;
        }
        return health > max / 3.0F ? 2 : 3;
    }

    private static EliteAbility[] rotationFor(int phase) {
        return switch (phase) {
            case 2 -> ROTATION_PHASE_2;
            case 3 -> ROTATION_PHASE_3;
            default -> ROTATION_PHASE_1;
        };
    }

    /**
     * 驱动器的「当前技能」= <b>此刻真能起手</b>的入场技优先，否则轮转表里的这一招。
     *
     * <p>入场技必须先过 {@link #canCast} 再插队：入场技是「等玩家进圈才放」的，
     * 如果它无条件占住 {@code ability()} 的返回值，玩家不靠近就永远只剩它在等着 ——
     * 轮转表一招也轮不到（Boss 变成站着不动的靶子）。够不着就让它挂着等机会，
     * 让位给现在放得出来的招。</p>
     */
    @Override
    protected EliteAbility ability() {
        if (this.entryAbility != EliteAbility.NONE && this.canCast(this.entryAbility)) {
            return this.entryAbility;
        }
        EliteAbility[] table = rotationFor(this.phase);
        return table[this.rotationIndex % table.length];
    }

    @Override
    protected int abilityCooldownTicks() {
        return ABILITY_GAP;
    }

    @Override
    protected boolean canStartAbility() {
        EliteAbility wanted = this.ability();
        return wanted != EliteAbility.NONE && this.canCast(wanted);
    }

    /**
     * 单独问一句「这一招现在能不能起手」。
     *
     * <p>拆出来是给 {@link #ability()} 用的：它得先知道入场技够不够得着，才知道该不该让位。
     * 轮转到的这一招够不着时不像美女僵尸那样「数够 tick 就跳过」——Boss 的三阶段本来就是
     * 按距离分层的（近战 / 远程 / 范围），够不着就原地等一会儿；但等满了
     * {@link EliteAbilityDriver.Hooks#starvationTicks()} 就由 {@link #onAbilityStarved()}
     * 换到下一槽，绝不会把整张轮转表卡死。</p>
     */
    private boolean canCast(EliteAbility wanted) {
        return switch (wanted) {
            // 近战：贴到 5 格以内才有意义
            case BOSS_SWEEP -> this.hasTargetInRange(1.0D, SWEEP_RADIUS + 1.0D);
            // 远程：4 格内用斧头更划算，40 格外开始收不到
            case BONE_VOLLEY -> this.hasTargetInRange(VOLLEY_MIN_RANGE, 40.0D);
            // 踏地：等玩家进圈
            case GROUND_QUAKE -> this.hasTargetInRange(1.0D, QUAKE_RADIUS + 1.5D);
            // 召唤：身边有人就放，不要求贴脸
            case RAISE_HORDE -> this.hasTargetInRange(1.0D, 24.0D);
            // 亡语：崩解要有意义，范围比踏地大一格
            case DEATH_WAIL -> this.hasTargetInRange(1.0D, WAIL_RADIUS + 1.0D);
            // 坠击：直线 9 格，够到就打，不要求贴脸
            case CAGE_SLAM -> this.hasTargetInRange(1.0D, CAGE_LINE_LENGTH + 1.0D);
            // 汲魂：汲取范围就是判定范围
            case SOUL_DRAIN -> this.hasTargetInRange(1.0D, DRAIN_RADIUS);
            // 疫雾：铺在脚下，等玩家进圈；半径外一点也算，免得「刚出圈就放空」
            case PLAGUE_MIST -> this.hasTargetInRange(1.0D, MIST_RADIUS + 2.0D);
            // 尖啸：范围最大的一招，靠它把贴脸的人推开
            case HORDE_SCREECH -> this.hasTargetInRange(1.0D, SCREECH_RADIUS);
            // 血怒是变身，有人看得见就放
            case BLOOD_RAGE -> true;
            default -> false;
        };
    }

    @Override
    protected void onAbilityStart() {
        switch (this.getAbility()) {
            case BOSS_SWEEP -> this.playSound(SoundEvents.RAVAGER_ATTACK, 1.6F, 0.7F);
            case BONE_VOLLEY -> this.playSound(SoundEvents.WITHER_SHOOT, 1.4F, 1.3F);
            case RAISE_HORDE -> {
                this.playSound(SoundEvents.EVOKER_PREPARE_SUMMON, 1.5F, 0.8F);
                this.ringParticles(ParticleTypes.SOUL, 1.2D, 24);
            }
            case GROUND_QUAKE -> this.playSound(SoundEvents.RAVAGER_ROAR, 1.6F, 0.6F);
            case BLOOD_RAGE -> {
                this.playSound(SoundEvents.WARDEN_ROAR, 2.0F, 0.8F);
                this.ringParticles(ParticleTypes.SOUL_FIRE_FLAME, 2.0D, 40);
            }
            case DEATH_WAIL -> {
                this.playSound(SoundEvents.WITHER_DEATH, 1.8F, 0.7F);
                this.ringParticles(ParticleTypes.SCULK_SOUL, 2.0D, 36);
            }
            case CAGE_SLAM -> {
                this.playSound(SoundEvents.RAVAGER_ATTACK, 1.8F, 0.6F);
                this.ringParticles(ParticleTypes.SOUL_FIRE_FLAME, 1.6D, 20);
            }
            case SOUL_DRAIN -> {
                this.playSound(SoundEvents.WITHER_HURT, 1.6F, 0.5F);
                this.ringParticles(ParticleTypes.SOUL, 1.8D, 28);
            }
            case PLAGUE_MIST -> {
                this.playSound(SoundEvents.SLIME_SQUISH, 1.6F, 0.6F);
                this.ringParticles(ParticleTypes.SNEEZE, 2.2D, 32);
            }
            case HORDE_SCREECH -> {
                this.playSound(SoundEvents.WARDEN_SONIC_CHARGE, 2.2F, 0.7F);
                this.ringParticles(ParticleTypes.SCULK_SOUL, 2.4D, 44);
            }
            default -> {
            }
        }
    }

    @Override
    protected void onAbilityImpact() {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        switch (this.getAbility()) {
            case BOSS_SWEEP -> this.castSweep(level);
            case BONE_VOLLEY -> this.castBoneVolley(level);
            case RAISE_HORDE -> this.castRaiseHorde(level, SUMMON_COUNT);
            case GROUND_QUAKE -> this.castQuake(level);
            case BLOOD_RAGE -> this.castBloodRage(level);
            case DEATH_WAIL -> this.castDeathWail(level);
            case CAGE_SLAM -> this.castCageSlam(level);
            case SOUL_DRAIN -> this.castSoulDrain(level);
            case PLAGUE_MIST -> this.castPlagueMist(level);
            case HORDE_SCREECH -> this.castHordeScreech(level);
            default -> {
            }
        }
    }

    @Override
    protected void onAbilityEnd(EliteAbility finished) {
        // 插队技能用掉就还回去；只有「刚刚播完的确实是它」才算用掉。
        // 不能只看 entryAbility != NONE：入场技够不着时会挂着等机会，
        // 这段时间里播的是轮转技，把入场技顺手清掉就等于把入场技吞了（第 3 阶段的血怒会整段消失）。
        if (this.entryAbility != EliteAbility.NONE && finished == this.entryAbility) {
            this.entryAbility = EliteAbility.NONE;
            return;
        }
        this.advanceRotation();
    }

    /**
     * 当前槽位干等到上限还是起不了手 —— 换下一槽，见 {@link EliteAbilityDriver#tickIdle()}。
     *
     * <p>触发场景就是「玩家贴脸」：骨刺齐射要求目标 ≥ 4 格，而打近战 Boss 的唯一打法就是贴脸，
     * 这一槽能连着几分钟起不了手。以前它会把整张轮转表一起锁死（Boss 站着不动、一招不放），
     * 现在跳过它继续往下轮。</p>
     */
    @Override
    protected void onAbilityStarved() {
        this.starvedSlots++;
        this.advanceRotation();
    }

    /** 轮转往前走一格；入场技与亡语不占用轮转的节奏，所以只在这里移动索引。 */
    private void advanceRotation() {
        EliteAbility[] table = rotationFor(this.phase);
        this.rotationIndex = (this.rotationIndex + 1) % table.length;
    }

    /**
     * 阶段推进 + 亡语判定 + 血条。挂在 {@code customServerAiStep} 上：
     * 这里排在 goalSelector 之后、{@code travel()} 之前，改完当 tick 就生效。
     */
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }

        float health = this.getHealth();
        int next = this.phaseFor(health);
        // 逐级推进 + 等当前这一招收完：一击跨两级（创造模式拿强武器测试就是这样）时会先走完
        // 中间那一段，否则中间段的入场技与「第 N/3 阶段」标题会被整个吞掉。
        if (next > this.phase && !this.isCasting()) {
            this.enterPhase(level, this.phase + 1);
        }

        // 垂死崩解：Phase 3 里跌破总生命 15% 时插队一次，之后不再触发
        if (!this.deathWailFired && this.phase == 3 && health <= this.getMaxHealth() * 0.15F
                && !this.isCasting()) {
            this.deathWailFired = true;
            this.entryAbility = EliteAbility.DEATH_WAIL;
        }

        this.updateBossBar(level);
    }

    /** 进入新阶段：换轮转表、插一张入场技、给看得见的玩家放标题与音效。 */
    private void enterPhase(ServerLevel level, int next) {
        this.phase = next;
        this.rotationIndex = 0;
        this.bossBar.setColor(switch (next) {
            case 2 -> BossEvent.BossBarColor.YELLOW;
            case 3 -> BossEvent.BossBarColor.PURPLE;
            default -> BossEvent.BossBarColor.RED;
        });

        if (next == 2) {
            this.entryAbility = EliteAbility.GROUND_QUAKE;
        } else if (next == 3 && !this.rageApplied) {
            this.entryAbility = EliteAbility.BLOOD_RAGE;
        }

        for (ServerPlayer player : level.players()) {
            player.connection.send(new ClientboundSetTitleTextPacket(
                    Component.translatable("horde.apocalypse_zombies.boss.phase.title", next, PHASE_COUNT)));
            player.connection.send(new ClientboundSetSubtitleTextPacket(
                    Component.translatable("horde.apocalypse_zombies.boss.phase.subtitle")));
            player.playNotifySound(SoundEvents.WARDEN_ROAR, SoundSource.HOSTILE, 1.4F, 0.7F);
        }
        this.phaseAnnounceCooldown = 60;
    }

    /** 血条：名字带阶段与血量，进度条就是血量。每 5 tick 推一次，不必每 tick 发包。 */
    private void updateBossBar(ServerLevel level) {
        // 名单每 2 秒重挂一次就够了：新看到的玩家由 startSeenByPlayer 立刻补上，
        // 每 tick 遍历玩家列表只是白花钱（战斗时这一段在服务端主线程上）。
        if (this.phaseAnnounceCooldown > 0) {
            this.phaseAnnounceCooldown--;
        }
        if (this.phaseAnnounceCooldown <= 0) {
            this.phaseAnnounceCooldown = 40;
            for (ServerPlayer player : level.players()) {
                this.bossBar.addPlayer(player);
            }
        }
        if (this.tickCount % 5 != 0) {
            return;
        }
        this.bossBar.setName(Component.translatable("horde.apocalypse_zombies.boss.bar",
                this.phase, Math.max(0, Math.round(this.getHealth()))));
        this.bossBar.setProgress(Mth.clamp(this.getHealth() / this.getMaxHealth(), 0.0F, 1.0F));
    }

    /** 被玩家看到就挂上血条；第一次被看到时吼一声，让玩家知道碰上的是什么。 */
    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossBar.addPlayer(player);
        player.playNotifySound(SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.0F, 0.6F);
        player.connection.send(new ClientboundSetTitleTextPacket(
                Component.translatable("horde.apocalypse_zombies.boss.spawn.title")));
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public void remove(RemovalReason reason) {
        this.bossBar.removeAllPlayers();
        super.remove(reason);
    }

    // ------------------------------------------------------------------ 技能结算

    /**
     * 巨斧横扫：身前 ±60° / 5 格的扇面重击。
     *
     * <p>角度判定用视线方向与「从自己指向目标」的水平夹角，不做方块射线 ——
     * 三格高的怪站在石头上打脚下的玩家时，射线会被自己的碰撞箱挡住。</p>
     */
    private void castSweep(ServerLevel level) {
        Vec3 look = this.getLookAngle();
        AABB box = this.getBoundingBox().inflate(SWEEP_RADIUS);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (victim == this || victim instanceof Zombie) {
                continue;
            }
            Vec3 toVictim = victim.position().subtract(this.position());
            double flat = Math.sqrt(toVictim.x * toVictim.x + toVictim.z * toVictim.z);
            if (flat > SWEEP_RADIUS) {
                continue;
            }
            double dot = (toVictim.x * look.x + toVictim.z * look.z) / Math.max(1.0E-4D, flat);
            if (Math.toDegrees(Math.acos(Mth.clamp(dot, -1.0D, 1.0D))) > SWEEP_HALF_ANGLE) {
                continue;
            }
            victim.hurt(this.damageSources().mobAttack(this), SWEEP_DAMAGE);
            victim.knockback(1.4D, -toVictim.x, -toVictim.z);
        }
        // 斧刃扫过的弧线：沿扇面撒一圈 SWEEP_ATTACK
        for (int i = -3; i <= 3; i++) {
            double angle = this.getYRot() + i * (SWEEP_HALF_ANGLE / 3.5D);
            double radians = Math.toRadians(angle);
            double x = this.getX() - Math.sin(radians) * 2.6D;
            double z = this.getZ() + Math.cos(radians) * 2.6D;
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, x, this.getY() + 1.4D, z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        this.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.8F, 0.6F);
    }

    /** 骨刺齐射：朝目标甩出 5 根带轻微制导的骨刺（复用重箭实体，只是不再放大命中点）。 */
    private void castBoneVolley(ServerLevel level) {
        LivingEntity target = this.getTarget();
        if (target == null) {
            return;
        }
        Vec3 eye = this.getEyePosition();
        Vec3 aim = new Vec3(target.getX(), target.getY(0.5D), target.getZ()).subtract(eye).normalize();
        for (int i = 0; i < VOLLEY_COUNT; i++) {
            double offset = (i - (VOLLEY_COUNT - 1) / 2.0D) * VOLLEY_SPREAD;
            Vec3 direction = aim.yRot((float) offset);
            GiantArrow spike = new GiantArrow(ModEntities.GIANT_ARROW.get(), level);
            spike.setOwner(this);
            spike.setBaseDamage(VOLLEY_DAMAGE);
            spike.setKnockback(1);
            spike.setPos(eye.x, eye.y - 0.4D, eye.z);
            spike.shoot(direction.x, direction.y, direction.z, VOLLEY_SPEED, 0.4F);
            level.addFreshEntity(spike);
        }
        this.playSound(SoundEvents.ARROW_SHOOT, 1.8F, 0.6F);
    }

    /** 召唤尸群：从脚下环状位置召来僵尸，环绕自己的目标冲锋。 */
    private void castRaiseHorde(ServerLevel level, int requested) {
        int alive = this.countNearbyZombies(level);
        int count = Math.max(0, Math.min(requested, SUMMON_CAP - alive));
        LivingEntity target = this.getTarget();
        int tier = Math.min(EvolutionTier.MAX_TIER,
                Math.max(0, MoonEventManager.getEvolutionLevel(level)));
        for (int i = 0; i < count; i++) {
            double angle = 2.0D * Math.PI * i / Math.max(1, count);
            BlockPos pos = BlockPos.containing(this.getX() + Math.cos(angle) * SUMMON_RADIUS,
                    this.getY(), this.getZ() + Math.sin(angle) * SUMMON_RADIUS);
            Zombie minion = EntityType.ZOMBIE.create(level);
            if (minion == null) {
                continue;
            }
            minion.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D,
                    this.random.nextFloat() * 360.0F, 0.0F);
            minion.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.MOB_SUMMONED, null, null);
            minion.setPersistenceRequired();
            ZombieEvolution.setTier(minion, tier, false);
            if (target != null) {
                minion.setTarget(target);
            }
            if (level.addFreshEntity(minion)) {
                level.sendParticles(ParticleTypes.SOUL, minion.getX(), minion.getY() + 1.0D, minion.getZ(),
                        12, 0.3D, 0.5D, 0.3D, 0.02D);
            }
        }
        this.ringParticles(ParticleTypes.SOUL, SUMMON_RADIUS, 32);
        this.playSound(SoundEvents.EVOKER_CAST_SPELL, 1.6F, 0.7F);
    }

    private int countNearbyZombies(ServerLevel level) {
        return level.getEntitiesOfClass(Zombie.class,
                this.getBoundingBox().inflate(SUMMON_RADIUS + 2.0D)).size();
    }

    /** 踏地冲击波：7 格内全部震起 + 重击；玩家还会被短暂减速（腿软）。 */
    private void castQuake(ServerLevel level) {
        AABB box = this.getBoundingBox().inflate(QUAKE_RADIUS);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (victim == this || victim instanceof Zombie) {
                continue;
            }
            double distance = Math.max(1.0D, victim.position().distanceTo(this.position()));
            double falloff = 1.0D - Mth.clamp((distance - 1.0D) / QUAKE_RADIUS, 0.0D, 0.75D);
            victim.hurt(this.damageSources().mobAttack(this), (float) (QUAKE_DAMAGE * falloff));
            victim.push(0.0D, 0.85D * falloff, 0.0D);
            victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
            victim.hurtMarked = true;
        }
        // 冲击环：贴地撒一圈 EXPLOSION，脚感更重
        for (int i = 0; i < 48; i++) {
            double angle = 2.0D * Math.PI * i / 48.0D;
            level.sendParticles(ParticleTypes.EXPLOSION,
                    this.getX() + Math.cos(angle) * QUAKE_RADIUS, this.getY() + 0.2D,
                    this.getZ() + Math.sin(angle) * QUAKE_RADIUS, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        this.playSound(SoundEvents.GENERIC_EXPLODE, 1.8F, 0.6F);
    }

    /** 血怒（Phase 3 入场）：给自己挂力量 / 迅捷 / 抗性，并把周围推开。 */
    private void castBloodRage(ServerLevel level) {
        this.rageApplied = true;
        this.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 12000, 1));
        this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 12000, 0));
        this.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 12000, 0));
        this.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 12000, 0));
        this.ringParticles(ParticleTypes.SOUL_FIRE_FLAME, 3.0D, 60);
        AABB box = this.getBoundingBox().inflate(QUAKE_RADIUS);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (victim == this || victim instanceof Zombie) {
                continue;
            }
            Vec3 push = victim.position().subtract(this.position());
            victim.knockback(1.2D, -push.x, -push.z);
        }
        this.playSound(SoundEvents.WARDEN_ROAR, 2.0F, 1.2F);
    }

    /** 垂死崩解：8 格范围重击 + 上抛 + 再召一波僵尸，顺便清掉自身的负面效果。 */
    private void castDeathWail(ServerLevel level) {
        AABB box = this.getBoundingBox().inflate(WAIL_RADIUS);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (victim == this || victim instanceof Zombie) {
                continue;
            }
            victim.hurt(this.damageSources().mobAttack(this), WAIL_DAMAGE);
            victim.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
            Vec3 push = victim.position().subtract(this.position()).normalize().scale(1.6D);
            victim.push(push.x, 0.7D, push.z);
            victim.hurtMarked = true;
        }
        this.castRaiseHorde(level, SUMMON_COUNT);
        // 只清负面效果。原来这里是 removeAllEffects()：亡语在 Phase 3 里是一个可轮转到的槽位，
        // 每轮一次就把血怒那四条增益一起抹掉 —— 玩家看到的是「第 3 阶段打着打着又变回一只大僵尸」。
        for (MobEffectInstance active : List.copyOf(this.getActiveEffects())) {
            if (!active.getEffect().isBeneficial()) {
                this.removeEffect(active.getEffect());
            }
        }
        this.ringParticles(ParticleTypes.SCULK_SOUL, WAIL_RADIUS, 64);
        this.playSound(SoundEvents.WITHER_DEATH, 2.0F, 0.6F);
    }

    /**
     * 尸笼坠击：正前方 9 格长、±2.5 格宽的直线重击，再沿这条线钉下一排骨刺。
     *
     * <p>判定用「视线方向的水平投影」而不是射线，理由和横扫一样：
     * 射线会被自己三格高的碰撞箱吃掉大半。骨刺从高处垂直落下，
     * 落点在身前 1.3 格以外，不会砸到自己。</p>
     */
    private void castCageSlam(ServerLevel level) {
        Vec3 look = this.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0D, look.z);
        if (flat.lengthSqr() < 1.0E-6D) {
            flat = Vec3.directionFromRotation(0.0F, this.getYRot());
        }
        flat = flat.normalize();
        Vec3 origin = this.position();
        AABB box = this.getBoundingBox().inflate(CAGE_LINE_LENGTH + 1.0D);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (victim == this || victim instanceof Zombie) {
                continue;
            }
            Vec3 delta = victim.position().subtract(origin);
            double forward = delta.x * flat.x + delta.z * flat.z;
            if (forward < 0.5D || forward > CAGE_LINE_LENGTH) {
                continue;
            }
            double lateral = Math.sqrt(Math.max(0.0D, delta.x * delta.x + delta.z * delta.z - forward * forward));
            if (lateral > CAGE_LINE_HALF_WIDTH) {
                continue;
            }
            victim.hurt(this.damageSources().mobAttack(this), CAGE_DAMAGE);
            victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
            victim.push(flat.x * 1.6D, 0.5D, flat.z * 1.6D);
            victim.hurtMarked = true;
        }
        for (int i = 1; i <= CAGE_SPIKES; i++) {
            Vec3 at = origin.add(flat.scale(CAGE_LINE_LENGTH * i / (CAGE_SPIKES + 1.0D)));
            GiantArrow spike = new GiantArrow(ModEntities.GIANT_ARROW.get(), level);
            spike.setOwner(this);
            spike.setBaseDamage(VOLLEY_DAMAGE);
            spike.setPos(at.x, this.getY() + 4.0D, at.z);
            spike.shoot(0.0D, -1.0D, 0.0D, 1.4F, 0.0F);
            level.addFreshEntity(spike);
        }
        this.playSound(SoundEvents.RAVAGER_ATTACK, 1.8F, 0.5F);
    }

    /**
     * 汲魂：把 10 格内所有活体各抽一口，按抽取总量反哺自己（单次有上限）。
     *
     * <p>Phase 3 的续航手段。血怒之后 Boss 打得又疼又快，但只剩三分之一的血，
     * 没有这一口的话「换血」是稳赢的打法 —— 现在贴着它打就得先想想自己那点血够不够抽。</p>
     */
    private void castSoulDrain(ServerLevel level) {
        AABB box = this.getBoundingBox().inflate(DRAIN_RADIUS);
        float healed = 0.0F;
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (victim == this || victim instanceof Zombie) {
                continue;
            }
            victim.hurt(this.damageSources().mobAttack(this), DRAIN_DAMAGE);
            victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
            healed += DRAIN_DAMAGE * DRAIN_HEAL_RATIO;
            // 抽取的手感靠「魂丝」：从受害者身上拉一条 SOUL 粒子链到自己胸口
            Vec3 from = victim.position().add(0.0D, victim.getBbHeight() * 0.6D, 0.0D);
            Vec3 to = this.position().add(0.0D, 1.8D, 0.0D);
            for (int i = 1; i <= 8; i++) {
                Vec3 point = from.lerp(to, i / 9.0D);
                level.sendParticles(ParticleTypes.SOUL, point.x, point.y, point.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
        if (healed > 0.0F) {
            this.heal(Math.min(healed, DRAIN_HEAL_CAP));
        }
        this.ringParticles(ParticleTypes.SOUL, DRAIN_RADIUS * 0.6D, 40);
        this.playSound(SoundEvents.WITHER_HURT, 1.6F, 0.6F);
    }

    /**
     * 疫雾：脚下铺一团 8 格半径的毒雾，命中瞬间先震一下圈内的人。
     *
     * <p>用原版 {@link AreaEffectCloud} 而不是自己维护「雾团表」：它自带粒子、逐 tick 结算、
     * 自动同步给客户端，还会在消失时清理；静态表是跨世界的可变状态，重载时会漏。
     * 效果只给中毒 —— 僵尸系对中毒免疫，所以这团雾伤活人、不伤自家尸群。</p>
     */
    private void castPlagueMist(ServerLevel level) {
        AABB box = this.getBoundingBox().inflate(MIST_RADIUS);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (victim == this || victim instanceof Zombie) {
                continue;
            }
            victim.hurt(this.damageSources().mobAttack(this), MIST_DAMAGE);
        }
        AreaEffectCloud cloud = new AreaEffectCloud(level, this.getX(), this.getY() + 0.4D, this.getZ());
        cloud.setOwner(this);
        cloud.setRadius(2.5F);
        cloud.setRadiusPerTick((float) ((MIST_RADIUS - 2.5D) / MIST_DURATION));
        cloud.setDuration(MIST_DURATION);
        cloud.setWaitTime(10);
        cloud.setRadiusOnUse(-0.05F);
        cloud.setParticle(ParticleTypes.SNEEZE);
        cloud.addEffect(new MobEffectInstance(MobEffects.POISON, MIST_POISON_TICKS, 1));
        level.addFreshEntity(cloud);
        this.playSound(SoundEvents.SLIME_SQUISH, 1.6F, 0.5F);
    }

    /**
     * 尸潮尖啸：16 格范围的尖啸，把活人炸开 + 短暂失明，并当场再拉几只僵尸。
     *
     * <p>专门对付「贴脸换血」：它把围上来的人推开，同时用失明切断对方的视野，
     * 给轮转表里那两招远程（骨刺 / 汲魂）腾出施放空间。</p>
     */
    private void castHordeScreech(ServerLevel level) {
        AABB box = this.getBoundingBox().inflate(SCREECH_RADIUS);
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (victim == this || victim instanceof Zombie) {
                continue;
            }
            Vec3 push = victim.position().subtract(this.position());
            double distance = Math.max(1.0D, push.length());
            double falloff = 1.0D - Mth.clamp((distance - 1.0D) / SCREECH_RADIUS, 0.0D, 0.85D);
            victim.hurt(this.damageSources().mobAttack(this), (float) (SCREECH_DAMAGE * falloff));
            victim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, SCREECH_BLIND_TICKS, 0));
            double strength = SCREECH_KNOCKBACK * falloff;
            victim.push(push.x / distance * strength, 0.45D * falloff, push.z / distance * strength);
            victim.hurtMarked = true;
        }
        this.castRaiseHorde(level, SCREECH_SUMMON);
        for (int i = 0; i < 64; i++) {
            double angle = 2.0D * Math.PI * i / 64.0D;
            level.sendParticles(ParticleTypes.SONIC_BOOM,
                    this.getX() + Math.cos(angle) * 2.0D, this.getY() + 2.2D,
                    this.getZ() + Math.sin(angle) * 2.0D, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        this.playSound(SoundEvents.WARDEN_SONIC_BOOM, 2.0F, 0.7F);
    }

    /** 环绕自己撒一圈粒子（起手 / 命中都用得上）。 */
    private void ringParticles(net.minecraft.core.particles.SimpleParticleType type, double radius, int count) {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        for (int i = 0; i < count; i++) {
            double angle = 2.0D * Math.PI * i / count;
            level.sendParticles(type, this.getX() + Math.cos(angle) * radius, this.getY() + 1.6D,
                    this.getZ() + Math.sin(angle) * radius, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    // ------------------------------------------------------------------ 通用性质

    /** Boss 不会被晒成焦炭：2500 血的怪在白天自己烧死，谁都没法打。 */
    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    /** 也不该被水变成溺尸。 */
    @Override
    protected boolean convertsInWater() {
        return false;
    }

    /** 死后掉落 500 经验（{@code xpReward} 已设），并清掉血条。 */
    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        this.bossBar.removeAllPlayers();
        super.die(source);
    }

    /** 三阶段 Boss 的血条不该因为玩家走远而消失（离得远也看得见进度）。 */
    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    /** 供外部（尸潮管理器 / 指令）查询：这只 Boss 现在还能召几只增援。 */
    public int summonHeadroom() {
        if (!(this.level() instanceof ServerLevel level)) {
            return 0;
        }
        return Math.max(0, SUMMON_CAP - this.countNearbyZombies(level));
    }

    /**
     * 阶段机的实时快照，一行一字段 —— {@code /apocalypse boss} 直接打印它。
     *
     * <p>阶段推进只有副作用（buff / 标题 / 轮转表），没有任何可读的 NBT 字段：
     * 排查「没有第 3 阶段」这种问题时，与其靠 buff 猜，不如把服务端眼里的这几个值念出来。</p>
     */
    public String debugStatus() {
        EliteAbility[] table = rotationFor(this.phase);
        return String.format(
                "overlord phase=%d/%d hp=%.1f/%.1f cast=%s@%d entry=%s rot=%d/%d rage=%s wail=%s starved=%d",
                this.phase, PHASE_COUNT, this.getHealth(), this.getMaxHealth(),
                this.getAbility(), this.getAbilityTick(), this.entryAbility,
                this.rotationIndex, table.length, this.rageApplied, this.deathWailFired,
                this.starvedSlots);
    }

    /** 阶段标题用得到：把阶段阈值暴露给测试与调试指令。 */
    public static float[] phaseThresholds() {
        return new float[] {PHASE2_HP, PHASE3_HP};
    }

    /** 轮转表快照：自检脚本与日志用得到。 */
    public static List<EliteAbility> rotationSnapshot(int phase) {
        return List.of(rotationFor(phase));
    }
}
