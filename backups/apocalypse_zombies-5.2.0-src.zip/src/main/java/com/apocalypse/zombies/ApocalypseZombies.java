package com.apocalypse.zombies;

import com.apocalypse.zombies.command.ApocalypseCommand;
import com.apocalypse.zombies.event.CommonEvents;
import com.apocalypse.zombies.network.NetworkHandler;
import com.apocalypse.zombies.registry.ModBiomeModifiers;
import com.apocalypse.zombies.registry.ModBlockEntities;
import com.apocalypse.zombies.registry.ModBlocks;
import com.apocalypse.zombies.registry.ModEffects;
import com.apocalypse.zombies.registry.ModEntities;
import com.apocalypse.zombies.registry.ModItems;
import com.apocalypse.zombies.registry.ModMenus;
import com.apocalypse.zombies.registry.ModParticles;
import com.apocalypse.zombies.registry.ModSounds;
import com.apocalypse.zombies.registry.ModSpawns;
import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.api.distmarker.Dist;
import org.slf4j.Logger;

/**
 * Apocalypse Zombies — a zombie apocalypse that escalates.
 *
 * <p>Zombies climb a six-step evolution ladder as the world ages and can evolve mid-fight; the night
 * sky rolls one of six lunar events that recolour the moon and sky while changing the rules of the
 * night; and blood moons (or unlucky ordinary ones) trigger a four-wave siege whose population is
 * rolled fresh every wave.</p>
 *
 * <p>On top of the vanilla lines sit four hand-tuned special hostiles — 尖啸者 / 碎颅者 / 腐蚀者 /
 * 骸骨射手 — each with its own telegraphed cast and payoff. They deliberately stay outside the
 * evolution ladder; see {@link com.apocalypse.zombies.entity.EliteAbility}.</p>
 */
@Mod(ApocalypseZombies.MOD_ID)
public class ApocalypseZombies {

    public static final String MOD_ID = "apocalypse_zombies";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ApocalypseZombies() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(modBus);
        ModEntities.register(modBus);
        ModMenus.register(modBus);
        ModEffects.register(modBus);
        ModParticles.register(modBus);
        ModSounds.register(modBus);
        ModBiomeModifiers.register(modBus);
        ModSpawns.register(modBus);
        // v4.0 第一次有自定义方块：方块 + 方块实体（顺序无所谓，DeferredRegister 各自在自己的
        // 注册事件里落地；方块实体的 supplier 在 BLOCK_ENTITY_TYPE 事件里才读 ModBlocks.SKYFALL_TERMINAL）。
        ModBlocks.register(modBus);
        ModBlockEntities.register(modBus);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC, "apocalypse_zombies-common.toml");
        // v4.0 P3-c：纯客户端配置（过场广播开关）。CLIENT 配置只在客户端存在，
        // 专用服务器上这个分支不会执行，ClientConfig 类也不会被加载。
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> com.apocalypse.zombies.client.ClientConfig::register);

        // 「模组列表 → 配置」按钮：注册的是客户端配置界面，纯客户端类，服务器上这个分支不会走
        // （DistExecutor 保证那个方法连类都不会被加载）。
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> com.apocalypse.zombies.client.ModConfigScreens::register);

        // 启动自检：配置枚举器（= 图形界面列的那几项）在真机上到底数出多少个。
        // 之所以要往日志里写一行：那枚举器是反射实现的，只在编译期断言「源码里有 223 个字段」
        // 证明不了运行期 —— 实机探针就是靠这行日志钉住这个数。
        LOGGER.info("Config registry: {} entries (exactly what the in-game config screen lists).",
                Config.values().size());

        // 运行期真值**不能在这里读** —— 构造阶段配置还没 load，读值会抛
        // `IllegalStateException: Cannot get config value before config is loaded.`，
        // 专用服务器直接起不来（1.1.79 第一版就踩了这个，改成读配置的回调里打）。
        modBus.addListener(this::onConfigLoaded);

        MinecraftForge.EVENT_BUS.register(CommonEvents.class);
        // 铜装备配方去重（兼容 [硬核生存] hcsurvival）：与 CommonEvents 同一条路，显式注册。
        com.apocalypse.zombies.compat.CopperGearRecipeCompat.register();
        // 登录即解锁本模组配方（doLimitedCrafting 世界里「产物槽空」的正解）。
        com.apocalypse.zombies.compat.RecipeUnlockCompat.register();
        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);

        NetworkHandler.register();
        // 轨道打击的服务器侧 tick 循环（CommonEvents 那条已够承担其它玩家/世界事件；这里另起一个类）
        com.apocalypse.zombies.event.OrbitalStrikeManager.register();
        // 天陨终端索引（按维度登记已加载的终端，供遥控器判定「附近有没有可用终端」；
        // 同时在 ServerStoppingEvent 里清表，避免旧世界坐标带到新世界）。
        com.apocalypse.zombies.orbital.terminal.SkyfallTerminalManager.register();

        LOGGER.info("Apocalypse Zombies loaded: the night is no longer yours.");
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        ApocalypseCommand.register(event.getDispatcher());
    }

    /**
     * 配置读进内存之后才读得出值 —— 这行日志是实机探针认的「上限到底是多少」的唯一口径：
     * Forge 在**读取时**校正越界值（日志里那句 {@code corrected from 256 to its default, 64}），
     * 所以配置文件里可能还写着越界的数，只有运行期真值算数。
     */
    private void onConfigLoaded(ModConfigEvent.Loading event) {
        // 老实例磁盘上还躺着 1.1.76~1.1.83 的 Ollama 端点和模型名（Forge 从不覆盖已存在的值），
        // 这里一次性换成 LM Studio 口径并让 Forge 重写文件；没改到东西时返回 null。
        if (event.getConfig().getSpec() == Config.SPEC) {
            String migrated = Config.migrateLegacyAiConfig();
            if (migrated != null) {
                LOGGER.info("Migrated legacy cat_girl.ai config: {} (Forge never overwrites existing values).",
                        migrated);
            }
            // 2.0.0：前摇默认值 80 → 140 tick。老实例文件里还写着 80，代码改默认值对它们无效。
            String orbital = Config.migrateLegacyOrbitalLock();
            if (orbital != null) {
                LOGGER.info("Migrated orbital_strike config: {} (Forge never overwrites existing values).",
                        orbital);
            }
        }
        LOGGER.info("Cat girl mining: mine_max_blocks={} (domain 1..64), mine_radius={} (domain 4..64).",
                Config.CAT_GIRL_MINE_MAX_BLOCKS.get(), Config.CAT_GIRL_MINE_RADIUS.get());
    }
}
