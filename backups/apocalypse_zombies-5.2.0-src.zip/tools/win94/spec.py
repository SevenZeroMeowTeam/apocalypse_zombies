# -*- coding: utf-8 -*-
"""win94（Winchester Model 1894）建模规范 —— 唯一的数字来源。

坐标与单位（项目铁律，见 docs/wiki/05-武器制作流程.md）
------------------------------------------------------
  16 u = 1 方块；1 u = 62.5 mm；1 in = 25.4 mm = 0.4064 u
  枪口 −Z、上 +Y、+X = 射手右侧（装填门与抛壳口都在 +X 侧）
  原点 = 机匣中心（膛线轴线 bore 在 y = 0）

真枪基准
--------
取 **Winchester Model 1894 Rifle，24 英寸枪管**（.30-30/.32 同族外形；本模组按 .45-70 设定弹道）。
长度换算以机匣长 7.2 in 为标尺：
  全长 OAL       43.6 in = 1108 mm = 17.72 u
  枪管（外露）   24 in = 610 mm，Ø 0.33 u = 20.6 mm
  机匣           7.2 × 1.4 in = 2.93 × 0.57 u（含顶部 tang 高 0.72 u）
  管状弹仓       Ø 15 mm = 0.24 u，位于枪管正下方，容量 5 发
  护木           230 mm 长、32 mm 宽 = 3.68 × 0.51 u
  枪托 LOP       13 in = 330 mm；托底 drop heel 75 / toe 194 mm；托底板高 4.8 in = 122 mm

机构几何（两张图交叉量取：用户参考图 = 3D 渲染图；wiki_17.jpg = 真枪棚拍侧视）
--------------------------------------------------------------------------------
标尺：机匣后端 z = +0.42、前端 z = −2.60、机匣底 y = −0.78；1 px = 0.01678 u。

  · **扳机护圈**（trigger guard）＝ 机匣的一部分，**固定不动**，包住扳机。
      原图 x 410…465、y 117…155 → 中心 (y −1.22, z −0.12)，半轴 (z 0.46, y 0.27)，管厚 0.09
      外径 0.92 × 0.54 u = 58 × 34 mm（真枪 ≈ 2.3 × 1.3 in ✓）
  · **杠杆环**（lever loop）＝ 可动件，手指勾的地方，横向拉长的椭圆。
      原图 x 325…425、y 155…192 → 中心 (y −1.85, z +0.92)，半轴 (z 0.84, y 0.32)，管厚 0.11
      外径 1.68 × 0.64 u = 105 × 40 mm（真枪 ≈ 4.2 × 1.6 in ✓）
      ⚠ 真枪是**两个环**：护圈在前（小、包扳机、固定），杠杆环在后下方（大、可动），
        关闭时上下相接，侧面看成"8"字 —— 只做一个环是不对的。
  · **杠杆**转轴在机匣**前下方** pivot (y −0.95, z −2.30)；杆贴机匣底向后到 z ≈ −0.55，
      再下斜到环前端。环在转轴**后方**（Δz > 0）⇒ 打开是绕 X 轴**正角度**、环向前下方摆。
      全开 55°：环位移 ≈ 193 mm，闭锁块行程 1.5 in = 38 mm ⇒ 增益 ≈ 5:1（与真枪手感同量级）。
  · **装填门**原图 x 482…527 → z −1.63…−0.88（机匣中后部），在机匣右壁 x = +0.29 的开口里。
  · **抛壳口**在机匣右壁上部 z −1.85…−0.72。
  · **倍镜**：M1894 顶抛壳，弹壳从机匣顶上向右上飞出 ⇒ 镜子必须架够高。本模型镜管中心
      高于 bore **0.80 u = 50 mm**，镜管底与机匣顶之间留 0.435 u ≈ 27 mm 抛壳净空。

契约（Java 侧按名字取，改名即崩）
----------------------------------
  骨骼见 CONTRACT_BONES（Win94ItemRenderer 还硬编码 "move" / "lever"）；
  动画见 CONTRACT_ANIMS（Win94Item 的 clip 表 + tick 契约 ceil(length × 20)）。
"""

U_MM = 62.5
U_IN = 25.4 / U_MM                      # 1 in = 0.4064 u

# Windows 控制台默认 GBK，中文/符号 print 会炸；统一把 stdout 切到 UTF-8。
import sys as _sys                       # noqa: E402
try:
    _sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

# ----------------------------------------------------------------- 机构常量
LEVER_PIVOT_Y = -0.95                   # 杠杆转轴（机匣前下方）
LEVER_PIVOT_Z = -2.30

GUARD_CY, GUARD_CZ = -1.22, -0.12       # 扳机护圈中心
GUARD_RZ, GUARD_RY = 0.46, 0.27         # 护圈半轴（z, y）
GUARD_THICK = 0.09                      # 护圈管厚

LOOP_CY, LOOP_CZ = -1.85, 0.92          # 杠杆环中心
LOOP_RZ, LOOP_RY = 0.84, 0.32           # 环半轴（z, y）
LOOP_THICK = 0.11                       # 环管厚

TRIGGER_Z = 0.06                        # 扳机（护圈内偏后）
GATE_Z = -1.25                          # 装填门中心
GATE_Z0, GATE_Z1 = -1.63, -0.88         # 装填门在机匣右壁的 z 跨度

RECEIVER_X = 0.29                       # 机匣半宽
RY_TOP, RY_BOT = 0.16, -0.78            # 机匣顶 / 底
RZ_F, RZ_B = -2.60, 0.42                # 机匣前 / 后端
PORT_Z0, PORT_Z1 = -1.85, -0.72         # 右壁抛壳口 z 跨度

SCOPE_CY = 0.80                         # 镜管中心高度（真枪顶装高架，见上文）
SCOPE_R = 0.205                         # 镜管半径（1" 管 = 0.41 u）
SCOPE_Z0, SCOPE_Z1 = -6.62, -0.36       # 镜身 z 跨度（总长 6.58 u ≈ 411 mm）

# 闭锁块后退行程：真枪必须 ≥ 弹壳长（.30-30 弹壳 2.04 in）才能把壳抽离膛口，
# 实测 M1894 约 2.4 in = 61 mm ⇒ 取 0.98 u。（早先按 1.5 in = 38 mm 做，太短，抽不出壳。）
BOLT_BACK = 0.98
LEVER_OPEN = 62.0                       # 杠杆全开角：连接点弧长要够 bolt 行程，真枪 60–70°

# 动画用的机构常量（anim.py 与 gate.py 共用，避免两边各写一份）
HAMMER_COCK = 32.0                      # 击锤待击角（绕 X 正角度 = 锤顶向后倒）
TRIGGER_PRESS = -16.0                   # 扳机扣动角（负角度 = 刀片下端向后）
CARRY_DROP = 0.09                       # carrier 下摆接弹的量
LIFT = 0.13                             # carrier 抬起送弹的量
GATE_OPEN = 0.030                       # 装填门被子弹顶开的位移
CHAMBER_Z = -0.95                       # 子弹"在膛内"相对 cartridge 骨骼原点的 z 偏移
FEED_Z = 0.16                           # 子弹在 carrier 上的 z 偏移
OUT_X = 0.86                            # 子弹在装填门外（机匣右侧）的 x 偏移
MAG_CY = -0.30                          # 管状弹仓中心（枪管正下方 0.30 u）

# ----------------------------------------------------------------- 骨骼树
GROUPS = [
    ('root',        None,       [0, 0, 0]),
    ('move',        'root',     [0, 0, 0]),
    ('body',        'move',     [0, -0.30, 0.50]),
    ('barrel',      'body',     [0, 0, -2.60]),
    ('forearm',     'body',     [0, -0.30, -4.40]),
    ('receiver',    'body',     [0, -0.30, -1.00]),
    ('stock',       'body',     [0, -1.00, 0.50]),
    ('bolt',        'receiver', [0, -0.10, -1.45]),
    ('hammer',      'receiver', [0, -0.25, 0.30]),
    ('lever',       'receiver', [0, LEVER_PIVOT_Y, LEVER_PIVOT_Z]),
    ('carrier',     'receiver', [0, -0.55, -1.35]),
    ('cartridge',   'receiver', [0, -0.35, -1.40]),
    ('spent_shell', 'receiver', [0, 0.05, -0.85]),
    ('trigger',     'receiver', [0, -0.74, TRIGGER_Z]),
    ('gate',        'receiver', [0, -0.55, GATE_Z]),
    ('scope',       'receiver', [0, SCOPE_CY, -3.50]),
]

# Java 契约（不许改）
CONTRACT_BONES = tuple(g[0] for g in GROUPS)
CONTRACT_ANIMS = ('static_idle', 'draw', 'shoot', 'bolt',
                  'reload_tactical', 'reload_empty', 'inspect')

# ----------------------------------------------------------------- 材质
# 逐面底色的材质键（贴图脚本按同一张表上色）。真枪是发蓝钢 + 胡桃木；
# 参考图那支是"展示枪"（黄铜机匣），所以 brass 只用在少量装饰件上。
MAT = {
    'blued': (46, 51, 58),          # 发蓝钢：枪管、机匣、杠杆、护圈
    'blued_dark': (28, 31, 36),     # 深发蓝：镜身、照门
    'steel': (128, 135, 144),       # 抛光钢：托底板、卡箍、背带环、螺丝
    'walnut': (100, 64, 36),        # 胡桃木：枪托、护木（参考图是深红棕）
    'walnut_dark': (74, 48, 24),
    'brass': (176, 141, 87),        # 黄铜：弹壳
    'brass_dark': (128, 96, 52),
    'copper': (156, 95, 51),        # 铜被甲弹头
    'lens': (72, 94, 118),          # 镜片
}

TEX_W = TEX_H = 512
UV_DENSITY = 20.0       # px per model unit（枪械薄件多，密度低了 0.05 u 的面只有 2 px；
                        # 239 方块 / 1434 面在 512² 上要留余量，20 px/u 用掉约 430 px 高）
UV_PAD = 2
NUDGE = 0.03            # 共面自愈的偏移量

# ----------------------------------------------------------------- 路径
from pathlib import Path as _Path   # noqa: E402

ROOT = _Path(__file__).resolve().parents[2]
ART = ROOT / 'art' / 'win94'
# 模型源归档在 art/<name>/（项目惯例，与 art/awm/awm.bbmodel 一致）；MCP 的 save_project 直接写这儿。
BBMODEL = ART / 'win94.bbmodel'
ASSETS = ROOT / 'src' / 'main' / 'resources' / 'assets' / 'apocalypse_zombies'
