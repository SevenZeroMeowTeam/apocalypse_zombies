#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P5 总门禁：天陨武库 4.0.0 的 jar / 资源 / 数据 / 文档一致性一次查完。

用法：
    python tools/check_skyfall.py                 # 查 build/libs 里当前版本的 jar
    python tools/check_skyfall.py --jar <path>    # 查指定 jar
    python tools/check_skyfall.py --skip-art      # 跳过两张贴图门禁（仅调试用）

退出码：0 = 全部通过；1 = 有失败。
不启游戏、不写工作区（只读 jar 与源码/文档）。
"""
import argparse
import hashlib
import json
import os
import re
import struct
import subprocess
import sys
import zipfile
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VER_RE = re.compile(r'^mod_version\s*=\s*([0-9][^\s#]*)', re.M)

A = 'assets/apocalypse_zombies/'
D = 'data/apocalypse_zombies/'

CORES = ['cinder', 'fault', 'quarantine', 'swarm', 'dawn', 'black_rain']
STRIKE_PROTOCOLS = ['cinder', 'fault', 'quarantine', 'swarm', 'dawn', 'black_rain']
CARRIERS = ['carrier_cannon', 'carrier_lance', 'carrier_singularity',
            'carrier_plasma', 'carrier_asteroid']
SPACE = ['earth', 'nebula', 'sat_body', 'sat_panel', 'sat_dish']
JAVA_CLASSES = [
    'com/apocalypse/zombies/block/SkyfallTerminalBlock.class',
    'com/apocalypse/zombies/block/SkyfallTerminalBlockEntity.class',
    'com/apocalypse/zombies/orbital/terminal/SkyfallTerminalManager.class',
    'com/apocalypse/zombies/orbital/terminal/ProtocolCoreItem.class',
    'com/apocalypse/zombies/network/TerminalSyncPacket.class',
    'com/apocalypse/zombies/network/TerminalActionPacket.class',
    'com/apocalypse/zombies/network/StrikePhasePacket.class',
    'com/apocalypse/zombies/network/StrikeCancelPacket.class',
    'com/apocalypse/zombies/client/gui/SkyfallTerminalScreen.class',
]
LANG_KEYS = [
    'block.apocalypse_zombies.skyfall_terminal',
    'item.apocalypse_zombies.skyfall_core_cinder',
    'skyfall.terminal.quick_charge',
    'skyfall.gui.title',
    'skyfall.strike.busy',
]

EXPECTED_CONFIGS = 224
FAILS = []


def report(ok, label, detail=None):
    print(('  OK   ' if ok else '  FAIL ') + label + (('  [' + str(detail) + ']') if detail is not None else ''))
    if not ok:
        FAILS.append(label)
    return ok


def project_version():
    with open(os.path.join(ROOT, 'gradle.properties'), encoding='utf-8') as fh:
        m = VER_RE.search(fh.read())
    return m.group(1) if m else '?'


def png_size(blob):
    if blob[:8] != b'\x89PNG\r\n\x1a\n':
        return None, None, None
    width, height = struct.unpack('>II', blob[16:24])
    bit_depth, color_type = blob[24], blob[25]
    mode = {(8, 2): 'RGB', (8, 6): 'RGBA', (8, 0): 'L'}.get((bit_depth, color_type), 'CT%d' % color_type)
    return width, height, mode


def jar_version(path):
    with zipfile.ZipFile(path) as z:
        txt = z.read('META-INF/mods.toml').decode('utf-8', 'replace')
    m = re.search(r'^version\s*=\s*"([^"]+)"', txt, re.M)
    return m.group(1) if m else '?'


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    os.environ.setdefault('PYTHONIOENCODING', 'utf-8')

    ap = argparse.ArgumentParser()
    ap.add_argument('--jar', default=None)
    ap.add_argument('--skip-art', action='store_true')
    args = ap.parse_args()

    ver = project_version()
    jar = args.jar or os.path.join(ROOT, 'build', 'libs', 'apocalypse_zombies-%s.jar' % ver)
    print('== skyfall gate: %s ==' % ver)
    print('jar: %s' % jar)
    if not report(os.path.isfile(jar), 'jar 存在'):
        return 1

    names = set()
    blobs = {}
    with zipfile.ZipFile(jar) as z:
        names = set(z.namelist())
        blobs['mods.toml'] = z.read('META-INF/mods.toml')

        def read(name):
            try:
                return z.read(name)
            except KeyError:
                return None

        blobs['zh'] = read(A + 'lang/zh_cn.json')
        blobs['en'] = read(A + 'lang/en_us.json')

    print('\n[1] 版本与元数据')
    report(jar_version(jar) == ver, 'jar 内 mods.toml 版本 == %s' % ver, jar_version(jar))
    template = os.path.join(ROOT, 'src', 'main', 'resources', 'META-INF', 'mods.toml')
    if os.path.isfile(template):
        with open(template, encoding='utf-8') as fh:
            tmpl = fh.read()
        report('${mod_version}' in tmpl, 'mods.toml 模板使用 ${mod_version} 占位')
        report('geckolib' in tmpl.lower(), 'mods.toml 声明 GeckoLib 依赖')

    print('\n[2] 终端与六核心资产链')
    blockstates = A + 'blockstates/skyfall_terminal.json'
    block_model = A + 'models/block/skyfall_terminal.json'
    block_tex = A + 'textures/block/skyfall_terminal.png'
    for name in (blockstates, block_model, block_tex, A + 'models/item/skyfall_terminal.json'):
        report(name in names, '存在 ' + name)
    if block_model in names:
        with zipfile.ZipFile(jar) as z:
            model = json.loads(z.read(block_model))
        texture_ref = model.get('textures', {}).get('all', '')
        report(texture_ref == 'apocalypse_zombies:block/skyfall_terminal',
               'block model 指向 skyfall_terminal 贴图', texture_ref)
    for core in CORES:
        item_model = A + 'models/item/skyfall_core_%s.json' % core
        core_tex = A + 'textures/item/skyfall_core_%s.png' % core
        report(item_model in names and core_tex in names, '核心 %s 模型+贴图齐全' % core)

    print('\n[3] 数据（配方 / 掉落 / 协议）')
    recipes = [D + 'recipes/skyfall_terminal.json', D + 'recipes/skyfall_core_cinder.json']
    for r in recipes:
        ok = r in names
        if ok:
            with zipfile.ZipFile(jar) as z:
                json.loads(z.read(r))
        report(ok, '配方存在且 JSON 合法 ' + r)
    loot = D + 'loot_tables/blocks/skyfall_terminal.json'
    report(loot in names, '终端掉落表存在')
    for proto in STRIKE_PROTOCOLS:
        path = A + 'strike/%s.xml' % proto
        ok = path in names
        if ok:
            with zipfile.ZipFile(jar) as z:
                ET.fromstring(z.read(path))
        report(ok, '协议 XML 存在且可解析 %s' % proto)

    print('\n[4] 语言键（zh/en 对齐）')
    try:
        zh = json.loads(blobs['zh'].decode('utf-8')) if blobs['zh'] else {}
        en = json.loads(blobs['en'].decode('utf-8')) if blobs['en'] else {}
    except Exception as exc:
        zh, en = {}, {}
        report(False, '语言文件 JSON 解析', exc)
    report(len(zh) > 0 and len(en) > 0, 'zh/en 均非空', '%d / %d' % (len(zh), len(en)))
    only_zh = sorted(set(zh) - set(en))
    only_en = sorted(set(en) - set(zh))
    report(not only_zh and not only_en, 'zh/en 键集合一致',
           ('zh-only=%s en-only=%s' % (only_zh[:3], only_en[:3])) if (only_zh or only_en) else '%d keys' % len(zh))
    missing = [k for k in LANG_KEYS if k not in zh or k not in en]
    report(not missing, '关键 skyfall 键齐全', missing[:5] if missing else 'ok')

    print('\n[5] 代码与配置')
    for cls in JAVA_CLASSES:
        report(cls in names, '类在包内 ' + cls.split('/')[-1])
    for shader in ('orbital.json', 'orbital.vsh', 'orbital.fsh',
                   'orbital_blit.json', 'orbital_blit.vsh', 'orbital_blit.fsh'):
        path = A + 'shaders/program/' + shader
        report(path in names, '后处理程序文件存在 ' + shader)
    for shader in ('orbit_sky.json', 'orbit_sky.vsh', 'orbit_sky.fsh'):
        report(A + 'shaders/core/' + shader in names, '天幕 shader 存在 ' + shader)
    # v5.2.0：共享代码改为内联进 orbital.fsh（program 着色器不支持 import），
    # 所以这里**不再**需要 orbit_grade.glsl 这个独立文件。
    report(A + 'shaders/program/orbit_grade.glsl' not in names,
           '合成器共享代码已内联（不再有独立 include 文件）')
    for beam in ('orbit_beam.json', 'orbit_beam.vsh', 'orbit_beam.fsh'):
        report(A + 'shaders/core/' + beam in names, '实体光柱 shader 存在 ' + beam)
    beam_json_path = A + 'shaders/core/orbit_beam.json'
    if beam_json_path in names:
        with zipfile.ZipFile(jar) as z:
            beam_json = json.loads(z.read(beam_json_path))
        beam_uniforms = {u.get('name') for u in beam_json.get('uniforms', [])}
        beam_required = {'ModelViewMat', 'ProjMat', 'ColorModulator', 'GameTime', 'Radius',
                         'Strength', 'Energy', 'Haze', 'Core', 'Body', 'Deep', 'Scanline'}
        missing_beam = sorted(beam_required - beam_uniforms)
        report(not missing_beam, '光柱声明全部 uniform', missing_beam[:4] if missing_beam else 'ok')
        report('Position' in (beam_json.get('attributes') or []), '光柱声明 Position 属性')
        report('UV0' in (beam_json.get('attributes') or []), '光柱声明 UV0 属性（径向坐标来源）')
    sky_json_path = A + 'shaders/core/orbit_sky.json'
    if sky_json_path in names:
        with zipfile.ZipFile(jar) as z:
            sky = json.loads(z.read(sky_json_path))
        sky_uniforms = {u.get('name') for u in sky.get('uniforms', [])}
        sky_required = {'CamForward', 'CamRight', 'CamUp', 'TanHalf', 'Aspect', 'Alpha', 'GameTime'}
        missing_sky = sorted(sky_required - sky_uniforms)
        report(not missing_sky, '天幕声明全部 uniform（含 GameTime 动画驱动）',
               missing_sky if missing_sky else 'ok')
    # v5.2.0：轨道炮特写（移植 star_gun）+ HUD 图形层（移植 white_space 的形状光栅器）
    for core_name, core_desc in (('orbit_gun', '轨道炮特写'), ('orbit_hud', 'HUD 图形层')):
        for ext in ('json', 'vsh', 'fsh'):
            report(A + 'shaders/core/%s.%s' % (core_name, ext) in names,
                   '%s shader 存在 %s.%s' % (core_desc, core_name, ext))
    if A + 'shaders/core/orbit_gun.json' in names:
        with zipfile.ZipFile(jar) as z:
            gun_json = json.loads(z.read(A + 'shaders/core/orbit_gun.json'))
        gun_declared = {u.get('name') for u in gun_json.get('uniforms', [])}
        gun_required = {'CamPos', 'CamForward', 'CamRight', 'CamUp', 'TanHalf', 'Aspect',
                        'PixelSize', 'Charge', 'Fired', 'GameTime', 'Alpha'}
        missing_gun = sorted(gun_required - gun_declared)
        report(not missing_gun, '轨道炮声明全部 uniform', missing_gun[:4] if missing_gun else 'ok')
    if A + 'shaders/core/orbit_hud.json' in names:
        with zipfile.ZipFile(jar) as z:
            hud_json = json.loads(z.read(A + 'shaders/core/orbit_hud.json'))
        hud_declared = {u.get('name') for u in hud_json.get('uniforms', [])}
        hud_required = {'ModelViewMat', 'ProjMat', 'ColorModulator', 'ScreenSize'}
        missing_hud = sorted(hud_required - hud_declared)
        report(not missing_hud, 'HUD 图形层声明全部 uniform', missing_hud[:4] if missing_hud else 'ok')
        report(hud_json.get('attributes') == ['Position', 'UV0', 'Color'],
               'HUD 图形层声明 Position/UV0/Color 属性')
    # v5.2.0：并行算形引擎（服务端）
    report(os.path.isfile(os.path.join(ROOT, 'src', 'main', 'java', 'com', 'apocalypse',
                                       'zombies', 'event', 'OrbitalCarveEngine.java')),
           '并行算形引擎存在 OrbitalCarveEngine.java')
    report(os.path.isfile(os.path.join(ROOT, 'src', 'main', 'java', 'com', 'apocalypse',
                                       'zombies', 'client', 'renderer', 'OrbitalGunStage.java')),
           '轨道炮特写渲染器存在 OrbitalGunStage.java')
    report(os.path.isfile(os.path.join(ROOT, 'src', 'main', 'java', 'com', 'apocalypse',
                                       'zombies', 'client', 'gui', 'OrbitHudShapes.java')),
           'HUD 图形层 Java API 存在 OrbitHudShapes.java')
    # v5.2.0：离线 GLSL 校验器 + 预览渲染器
    report(os.path.isfile(os.path.join(ROOT, 'tools', 'glsl_check.py')),
           'GLSL 真编译校验器存在 tools/glsl_check.py')
    report(os.path.isfile(os.path.join(ROOT, 'tools', 'shader_preview.py')),
           '着色器离线预览器存在 tools/shader_preview.py')
    # v4.1.0：轨道卫星 GeckoLib 模型（生成器 tools/facility_model.py）
    report(A + 'geo/satellite.geo.json' in names, '卫星 geo 存在')
    report(A + 'textures/entity/facility/satellite.png' in names, '卫星贴图存在')
    report(A + 'animations/satellite.animation.json' in names, '卫星动画存在')
    if A + 'geo/satellite.geo.json' in names:
        with zipfile.ZipFile(jar) as z:
            sat = json.loads(z.read(A + 'geo/satellite.geo.json'))
        d0 = sat['minecraft:geometry'][0]['description']
        report(d0.get('texture_width') == 512 and d0.get('texture_height') == 512,
               '卫星贴图尺寸声明 512²', f"{d0.get('texture_width')}x{d0.get('texture_height')}")
        bones = sat['minecraft:geometry'][0]['bones']
        report(len(bones) <= 40, '卫星骨骼数 ≤ 40', len(bones))
        cubes = sum(len(b.get('cubes', [])) for b in bones)
        report(cubes <= 600, '卫星方块数 ≤ 600', cubes)
    for facility in ('facility_hull', 'facility_gold', 'facility_panel', 'facility_solar',
                     'facility_dish', 'facility_glow_cyan', 'facility_glow_orange', 'facility_dark'):
        report(A + 'textures/block/' + facility + '.png' in names, '设施贴图存在 ' + facility)
        report(A + 'blockstates/' + facility + '.json' in names, '设施 blockstate 存在 ' + facility)
        report(A + 'models/block/' + facility + '.json' in names, '设施模型存在 ' + facility)
    program = A + 'shaders/program/orbital.json'
    if program in names:
        with zipfile.ZipFile(jar) as z:
            shader_json = json.loads(z.read(program))
        declared = {u.get('name') for u in shader_json.get('uniforms', [])}
        required = {'Strength', 'Radial', 'Chroma', 'Impact', 'Flash', 'Vignette', 'Grade',
                    'ProjMat', 'InSize', 'OutSize', 'Time',
                    'ZoomBlur', 'Bloom', 'Desaturate', 'Contrast', 'Grain',
                    'ImpactMode', 'ImpactStrength', 'ImpactCenter', 'Exposure', 'Accent',
                    'ShaftPos', 'ShaftStrength'}
        missing_u = sorted(required - declared)
        report(not missing_u, 'orbital 程序声明全部 uniform', missing_u[:4] if missing_u else 'ok')
        report(shader_json.get('attributes') == ['Position'], 'orbital 程序声明 Position 属性')
        fsh_path = A + 'shaders/program/orbital.fsh'
        if fsh_path in names:
            with zipfile.ZipFile(jar) as z:
                fsh = z.read(fsh_path).decode('utf-8', 'replace')
            # Minecraft 的 program 着色器**不支持 import**（EffectProgram 会报
            # "#error Import statement not supported"），共享代码必须内联。
            # 只看真正的指令行，注释里提到 #include 不算。
            code = re.sub(r'//[^\n]*', '', fsh)
            code = re.sub(r'/\*.*?\*/', '', code, flags=re.S)
            report('#include' not in code and '#moj_import' not in code,
                   'orbital.fsh 不用 import（program 着色器不支持 import）')
            report('impactFrame' in fsh, 'orbital.fsh 调用冲击帧')
            # 三目配平：'?' 多于 ':' 会让整个 program 编译失败（MC 静默不画）
            q = code.count('?')
            c = code.count(':')
            report(q <= c, 'orbital.fsh 三目 ?/: 配平', '%d vs %d' % (q, c))
    config_java = os.path.join(ROOT, 'src', 'main', 'java', 'com', 'apocalypse', 'zombies', 'Config.java')
    with open(config_java, encoding='utf-8') as fh:
        source = fh.read()
    count = len(re.findall(r'public static final ForgeConfigSpec\.(?:BooleanValue|IntValue|LongValue|DoubleValue|ConfigValue)', source))
    report(count == EXPECTED_CONFIGS, '配置项数量 == %d' % EXPECTED_CONFIGS, count)

    print('\n[6] P4 资产原创性')
    for name in CARRIERS:
        path = A + 'textures/environment/%s.png' % name
        if path not in names:
            report(False, '载体板存在 ' + name)
            continue
        with zipfile.ZipFile(jar) as z:
            w, h, mode = png_size(z.read(path))
        report((w, h, mode) == (1408, 768, 'RGB'), '载体板 %s 1408x768 RGB' % name, '%sx%s %s' % (w, h, mode))
    cut = A + 'textures/environment/carrier_asteroid_cutout.png'
    if cut in names:
        with zipfile.ZipFile(jar) as z:
            w, h, mode = png_size(z.read(cut))
        report((w, h, mode) == (600, 600, 'RGBA'), '小行星抠图 600x600 RGBA', '%sx%s %s' % (w, h, mode))
    else:
        report(False, '小行星抠图存在')
    for name in SPACE:
        path = A + 'textures/environment/%s.png' % name
        report(path in names, '太空舞台贴图存在 ' + name)

    if args.skip_art:
        print('\n[7] 贴图门禁（--skip-art 跳过）')
    else:
        print('\n[7] 贴图门禁')
        for script in ('tools/check_orbital_art.py', 'tools/check_carrier_art.py'):
            path = os.path.join(ROOT, script)
            if not os.path.isfile(path):
                report(False, '门禁脚本存在 ' + script)
                continue
            out = subprocess.run([sys.executable, script], cwd=ROOT,
                                 capture_output=True, text=True, encoding='utf-8', errors='replace')
            tail = (out.stdout or '').strip().splitlines()[-1:] or ['(no output)']
            report(out.returncode == 0, '门禁通过 ' + script, tail[0][:80])

    print('\n[8] 文档 / 四处版本')
    with open(os.path.join(ROOT, 'readme.md'), encoding='utf-8') as fh:
        readme = fh.read()
    m = re.search(r'\|\s*\*\*当前版本\*\*\s*\|\s*`([^`]+)`', readme)
    report(bool(m) and m.group(1) == ver, 'readme 头表版本 == %s' % ver, m.group(1) if m else 'missing')
    report(('### %s —' % ver) in readme, 'readme 有 %s 更新日志段' % ver)
    with open(os.path.join(ROOT, 'mod.toml'), encoding='utf-8') as fh:
        root_toml = fh.read()
    m2 = re.search(r'^mod_version\s*=\s*"([^"]+)"', root_toml, re.M)
    report(bool(m2) and m2.group(1) == ver, '根 mod.toml 版本 == %s' % ver, m2.group(1) if m2 else 'missing')
    probe = os.path.join(ROOT, 'tools', 'skyfall_probe.py')
    report(os.path.isfile(probe), '专服探针脚本存在 tools/skyfall_probe.py')

    print('\n[9] GLSL 真编译（用本机 OpenGL 3.3 上下文）')
    # 这一关卡是 5.2.0 加的：v5.0.0/v5.1.0 的三个 shader 从来没在玩家机器上
    # 编译成功过（orbit_sky.fsh 有一个三目不配平），但因为没有任何离线编译手段，
    # 本地构建、专服冒烟、门禁全绿就出货了，玩家那边只是「特效没出现」。
    # 现在每个出货包都必须在本机真编译一遍，且 uniform 必须在链接后的 program 上查得到。
    glsl = os.path.join(ROOT, 'tools', 'glsl_check.py')
    report(os.path.isfile(glsl), 'GLSL 校验器存在 tools/glsl_check.py')
    if os.path.isfile(glsl):
        env = dict(os.environ)
        env['PYTHONIOENCODING'] = 'utf-8'
        try:
            proc = subprocess.run([sys.executable, glsl], capture_output=True, text=True,
                                  env=env, timeout=300)
        except Exception as exc:
            report(False, 'GLSL 真编译', str(exc)[:120])
        else:
            out = (proc.stdout or '') + (proc.stderr or '')
            for line in out.splitlines():
                if line.startswith(('compiled ', 'all shaders', 'FAILURES', 'STATIC')):
                    print('  ' + line)
            report(proc.returncode == 0, 'GLSL 全部编译通过（链接后 uniform 可查）',
                   out.strip().splitlines()[-1][:120] if out.strip() else 'no output')

    print('\n[10] 包体指纹')
    with open(jar, 'rb') as fh:
        digest = hashlib.sha256(fh.read()).hexdigest()
    print('  sha256 %s  (%d bytes)' % (digest, os.path.getsize(jar)))

    print()
    if FAILS:
        print('RESULT: FAIL (%d) — %s' % (len(FAILS), '; '.join(FAILS[:3])))
        return 1
    print('RESULT: PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
